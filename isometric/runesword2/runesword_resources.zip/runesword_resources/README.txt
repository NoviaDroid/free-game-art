author: CrossCut Games
license: Public Domain
origin: https://sourceforge.net/projects/runesword/

The creature miniatures were stripped, due to their origin being unknown.