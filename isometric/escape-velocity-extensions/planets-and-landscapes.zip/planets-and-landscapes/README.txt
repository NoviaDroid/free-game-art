author: AV Dezign (Andre Vandal)
license: CC-BY 3.0
source: http://opengameart.org/content/av-dezign-planets-and-landscapes

Old rendered space graphics originally designed for Escape Velocity, including planets and corresponding landscapes. Also a few really cool space stations.
