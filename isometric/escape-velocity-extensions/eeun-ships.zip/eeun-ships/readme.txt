author: Eeun
license: Public Domain
source: http://opengameart.org/content/eeuns-shipyard-spaceship-graphics

Another EV shipyard release. It contains 28 ships, each rendered at at a bird's eye almost-top-down angle (I'm not 100% sure if the angle is consistent between them.) The Masks (alpha channels) are in a seperate image named "mask." The ships, like Meowx's, are made for Escape Velocity mods so they also also contain a larger (usually 100x100) render, a side-render, and a head-on render, which I've named "icon", "scan", and "head" respectively.

The ships range from intimidating to wimsical. They are rendered in StrataStudio Pro (except for the Eldar which is rendered in Infini-D) around 1997 to about 2000.


Edit: Eeun also did a potentially copyright infringing Dalek which you can download at http://emr.sdf.org/opengameart.html