Welcome to GearHead Arena_R! This is an experimental remake of GH1 using Lua
scripting and the GearHead2 engine. There's not much to see yet, but you can
play around with things and hopefully add your own content.

The main lua scripts are located in the gamedata folder
The quests and scene content are in the series folder
The mecha and equipment are in the design folder

So far, only static content has been added- no plots or core story yet.
