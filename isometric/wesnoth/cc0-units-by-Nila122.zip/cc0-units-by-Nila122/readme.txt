author: Nila122
License: Public Domain (CC0)
origin: http://opengameart.org/content/49-units

I made these few years ago, when I wanted to make custom era to wesnoth, but I gave up on that project.

There is total of 49 images.

You are free to use them as you wish.

