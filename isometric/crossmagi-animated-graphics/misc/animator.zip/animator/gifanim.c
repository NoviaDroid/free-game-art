/*
    Angelion SDL client, a client program for the Angelion MMORPG.

	This file is code that was heavily borrowed from http://algif.sourceforge.net/
	which is Copyright (c) 2000-2004 algif contributors and is subject to
	the MIT licence: http://algif.sourceforge.net/#38

	Copyright (c) 2000-2004 algif contributors

	Permission is hereby granted, free of charge, to any person obtaining a
	copy of this software and associated documentation files (the "Software"),
	to deal in the Software without restriction, including without limitation
	the rights to use, copy, modify, merge, publish, distribute, sublicense,
	and/or sell copies of the Software, and to permit persons to whom the
	Software is furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in
	all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
	DEALINGS IN THE SOFTWARE.


	Any portions not covered by the original algif licence are subject to the
	following licence:

  Copyright (C) 2003 James Little

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    The author can be reached via e-mail to jlittle@sric.com
*/

#include <include.h>
#include <gifanim.h>
#include <lzw.h>
#include <neuquant.h>

#include <string.h>

#ifndef HAVE_STRICMP
#define stricmp strcasecmp
#endif

#ifndef HAVE_STRNICMP
#define strnicmp strncasecmp
#endif

/* The following defines are used to create the temporary surfaces used to
 * store the surfaces in a gif file
*/
#define CREATE_PARAM 0xff,0xff00,0xff0000,0
#define CREATE_FLAGS (SDL_HWSURFACE|SDL_SWSURFACE)

static GIF * head=NULL;		/* Head of active display list */
static GIF * tail=NULL;		/* Last animation on the active display list */
static uint32 StartTime;	/* SDL_Tick time for sequencing animations */
static Boolean reset=TRUE;	/* Reset all anims on next display */

#define SAME_COLOR(C1,C2) ((C1).r==(C2).r && (C1).g==(C2).g && (C1).b==(C2).b && (C1).unused==(C2).unused)
/* Color compare test. Must include alpha (".unused") in order to keep
 * transparent pixels unique from colors with the same rgb component
*/

/*----------------------------------------------------------------------------
 * FindColor
 * Returns the index if a match is found. Otherwise -1 is returned.
*/
static int FindColor(const SDL_Palette * pal,const SDL_Color * color)
{
	int i;
	for (i=0; i<pal->ncolors; ++i) if (SAME_COLOR(pal->colors[i],*color)) return i;

	return -1;
}

/*----------------------------------------------------------------------------
 * AddColor
 * Add color[index] to the palette (if there is room).
 * The routine checks for the color already being in the palette.
 * Returns -1 if the added color is in the same position in the dest palette.
 * Returns 1 if the added color is in a different position.
 * Returns 0 if the palette is already full (256 entries).
*/
static int AddColor(SDL_Palette * pal,const SDL_Color * color,int index)
{
	int i;

	color+=index; /* The color to test */

	i=FindColor(pal,color);

	if (i<0) {
		if (pal->ncolors==256) return 0; /* No match found. Table can not be increased */
		/* Not found but increasing the palette is ok if still <= 256 entries */
		i=pal->ncolors++;
		pal->colors[i]=*color;
	}

	return (i==index)?-1:1;
}

/*----------------------------------------------------------------------------
 * GetPalPow
 * Returns the first power of two that will contain n
 * The result is encoded as 1 less than the true value. ie: 2^(result+1)
 * ie: returns 3 for n=15 or n=16 but 4 for n=17 and returns 7 for 256
 * Another way of looking at it: return the bit position of the MSB.
 * Note: zero passed in will return a result of -1 (invalid)
*/
static int GetPalPow(int n)
{
	int i;
	int mask=1L<<(sizeof(n)*8-1);

	--n;

	for (i=sizeof(n)*8-1; i>=0 && !(n & mask); mask>>=1,--i) ;

	return i;
}

/*----------------------------------------------------------------------------
 * pack_igetw
 * Read in a 2 byte integer in lo-hi format.
*/
static uint16 pack_igetw(FILE * f)
{
	uint8 lo=fgetc(f);
	uint8 hi=fgetc(f);

	return (uint16)lo | ((uint16)hi<<8);
}

/*----------------------------------------------------------------------------
 * pack_iputw
 * Write out a 2 byte integer in lo-hi format.
*/
static void pack_iputw(uint16 w,FILE * f)
{
	fputc((uint8)w,f);
	fputc((uint8)(w>>8),f);
}

/*----------------------------------------------------------------------------
 * read_palette
 * The SDL_Palette field must have ncolors set to the number of colors read in
*/
static void read_palette(FILE * file,SDL_Palette * palette)
{
	int i;

	for (i = 0; i < palette->ncolors; i++) {
		/* The file stores the triplet in RGB order */
		palette->colors[i].r=(uint8)fgetc(file);
		palette->colors[i].g=(uint8)fgetc(file);
		palette->colors[i].b=(uint8)fgetc(file);
		/* We use the unused field to indicate a real color (unused=255) or
		 * if the color is the transparency color (unused=0)
		*/
		palette->colors[i].unused=255;
	}
}

/*----------------------------------------------------------------------------
 * deinterlace
 * Gif file routine to deinterlace the stored image upon read.
*/
static void deinterlace(SDL_Surface * surf)
{
	SDL_Surface * n=SDL_CreateRGBSurface(CREATE_FLAGS,surf->w,surf->h,surf->format->BitsPerPixel,CREATE_PARAM);
	SDL_Rect sr,dr;

	sr.x=dr.x=0;
	sr.w=dr.w=n->w;
	sr.h=dr.h=1;
	sr.y=0;

	for (dr.y = 0; dr.y < n->h; ++sr.y,dr.y += 8) SDL_BlitSurface(surf,&sr,n,&dr);
	for (dr.y = 4; dr.y < n->h; ++sr.y,dr.y += 8) SDL_BlitSurface(surf,&sr,n,&dr);
	for (dr.y = 2; dr.y < n->h; ++sr.y,dr.y += 4) SDL_BlitSurface(surf,&sr,n,&dr);
	for (dr.y = 1; dr.y < n->h; ++sr.y,dr.y += 2) SDL_BlitSurface(surf,&sr,n,&dr);

	sr.y=0;
	dr.y=0;
	sr.h=dr.h=n->h;

	SDL_BlitSurface(n,&sr,surf,&sr);

	SDL_FreeSurface(n);
}

/*----------------------------------------------------------------------------
 * algif_destroy_raw_animation
 * free any allocated memory for the entire animation.
 * The anim structure is also freed
*/
static void algif_destroy_raw_animation(GIF_ANIMATION * anim)
{
	if (anim && --anim->LoadCount<1) {
		int i;

		/* Go thru all frames and get rid of any allocated surfaces */
		for (i=0; i<anim->frames_count; ++i) {

			GIF_FRAME * frame=anim->frames+i;
			if (frame->bitmap_8_bit) SDL_FreeSurface(frame->bitmap_8_bit);
		}

		if (anim->store) SDL_FreeSurface(anim->store);
		free(anim->filename);
		free(anim->frames);
		free(anim);
	}
}

/*----------------------------------------------------------------------------
 * FindExistingAnim
 * Search the active display list for another animation with the same filename
*/
static GIF_ANIMATION * FindExistingAnim(const char * name)
{
	GIF * gif;

	for (gif=head; gif; gif=gif->next) {
		if (!stricmp(gif->anim->filename,name)) break;
	}

	return (gif)?gif->anim:NULL;
}

/*----------------------------------------------------------------------------
 * algif_load_raw_animation
 * Loads the gif file
*/
static GIF_ANIMATION * algif_load_raw_animation(const char * filename)
{
	FILE * file;
	int version;
	int i,j;
	GIF_ANIMATION * gif;
	GIF_FRAME frame;
	SDL_Palette pal;		/* The global palette (if any) */
	SDL_Color colors[256];	/* Holds the colors for the global palette */

	/* First check to see if there is one already with the same filename */
	gif=FindExistingAnim(filename);
	if (gif) {
		/* Already loaded. Use the loaded version instead. */
		++gif->LoadCount;
		return gif;
	}

	memset(&frame,0,sizeof frame);

	file=fopen(filename,"rb");
	if (!file) return NULL;

    gif=calloc(1,sizeof gif[0]);
	if (!gif) goto error;

	pal.colors=colors;		/* Init the pal.colors field to point to the array */

	gif->filename=strdup(filename);	/* Save the name before we forget */
	gif->LoadCount=1;

    /* is it really a GIF? */
	if ((uint8)fgetc(file)!='G')	goto error;
	if ((uint8)fgetc(file)!='I')	goto error;
	if ((uint8)fgetc(file)!='F')	goto error;
	if ((uint8)fgetc(file)!='8')	goto error;

	/* '7' or '9', for 87a or 89a. */
    version=(uint8)fgetc(file);
	if (version!='7' && version!='9')	goto error;
	if ((uint8)fgetc(file)!='a')		goto error;

	gif->width=pack_igetw(file);
	gif->height=pack_igetw(file);

	/* flags byte follows */
	i=(uint8)fgetc(file);

	/* Global color table? */
	if (i & 128)
		pal.ncolors=1<<((i&7)+1);
	else {
		pal.ncolors=0;
	}

	/* NOTE: Background color is only valid with a global palette. */
    gif->background_index=(uint8)fgetc(file);

	/* Skip aspect ratio. */
	fgetc(file);

	/* Global palette (if any) is next */
	read_palette(file,&pal);

	memset(&frame,0,sizeof frame); /* For first frame. */
	frame.transparent_index=-1;

	do {
		/* Next byte is an id */
		switch ((uint8)fgetc(file)) {

		case 0x2c:         /* Image Descriptor */
			{
				int w,h;
				Boolean interlaced;
				SDL_Palette * local;
				GIF_FRAME * NewFrames;

				frame.xoff=pack_igetw(file);
				frame.yoff=pack_igetw(file);

				w=pack_igetw(file);
				h=pack_igetw(file);

				frame.bitmap_8_bit=SDL_CreateRGBSurface(CREATE_FLAGS,w,h,8,CREATE_PARAM);
				if (!frame.bitmap_8_bit) goto error;

				/* flags */
				i=(uint8)fgetc(file);

				/* Local palette. */
				local=frame.bitmap_8_bit->format->palette;
				if (i & 0x80) {
					local->ncolors=1<<((i & 7)+1);
					read_palette(file,local);
					/* Mark the transparency color with a zero in the unused field */
					if (frame.transparent_index!=-1) local->colors[frame.transparent_index].unused=0;
				} else {
					/* Use global palette instead */
					local->ncolors=pal.ncolors;
					memcpy(local->colors,pal.colors,local->ncolors*sizeof local->colors[0]);
					/* Mark the transparency color */
					if (frame.transparent_index!=-1) {
						local->colors[frame.transparent_index].unused=0;
						SDL_SetColorKey(frame.bitmap_8_bit,SDL_SRCCOLORKEY,frame.transparent_index);
					}
				}

				interlaced=(i & 64)!=0;

				if (SDL_LockSurface(frame.bitmap_8_bit)) goto error;
				j=LZW_decode(file,frame.bitmap_8_bit);
				SDL_UnlockSurface(frame.bitmap_8_bit);
				if (j) goto error;

				if (interlaced) deinterlace(frame.bitmap_8_bit);

				NewFrames=realloc(gif->frames,(gif->frames_count+1)*sizeof gif->frames[0]);
				if (!NewFrames) goto error;
				gif->frames=NewFrames;
				gif->frames[gif->frames_count++]=frame;

				memset(&frame,0,sizeof frame); /* For next frame. */
				frame.transparent_index=-1;
			}
			break;

		case 0x21: /* Extension Introducer. */

			j=(uint8)fgetc(file); /* Extension Type. */
			i=(uint8)fgetc(file); /* Size. */

			switch (j) {

			case 0xf9: /* Graphic Control Extension. */
				/* size must be 4 */
				if (i!=4) goto error;
				i=(uint8)fgetc(file);
				frame.disposal_method=(i>>2)&7;
				frame.duration=pack_igetw(file);
				if (i & 1) /* Transparency? */
					frame.transparent_index=(uint8)fgetc(file);
				else {
					fgetc(file);	/* Skip the value (not valid) */
					frame.transparent_index=-1;
				}
				i=(uint8)fgetc(file); /* Size. */
				break;

			case 0xff: /* Application Extension. */
				if (i==11) {
					char name[12];
					fread(name,1,11,file);
					i=(uint8)fgetc(file); /* Size. */
					name[11]='\0';
					if (!strcmp(name,"NETSCAPE2.0")) {
						if (i==3) {
							j=(uint8)fgetc(file);
							gif->loop=pack_igetw(file);
							if (j!=1) gif->loop = 0;
							i=(uint8)fgetc(file); /* Size. */
						}
					}
				}
			}

			/* Possibly more blocks until terminator block (0). */
			while (i) {
				fseek(file,i,SEEK_CUR);
				i=(uint8)fgetc(file);
			}
			break;

		case 0x3b:
			/* GIF Trailer. */
			fclose(file);
			return gif;
		}
	}

	while (TRUE);

  error:

	if (file) fclose(file);
	if (gif) algif_destroy_raw_animation(gif);
	if (frame.bitmap_8_bit) SDL_FreeSurface(frame.bitmap_8_bit);

	return NULL;
}

/*----------------------------------------------------------------------------
 * algif_render_frame
 * Renders the next frame in a GIF animation to the specified bitmap and
 * the given position. You need to call this in order on the same
 * destination for frames [0..gif->frames_count - 1] to properly render all
 * the frames in the GIF.
 */

static void algif_render_frame(GIF_ANIMATION *gif,SDL_Surface * surf,int frame,int xpos,int ypos)
{
	int w,h;
	GIF_FRAME *f = &gif->frames[frame];
	SDL_Rect sr,dr;
	SDL_PixelFormat * pf=surf->format;

	if (frame == 0) {
		sr.x=xpos;
		sr.y=ypos;
		sr.w=gif->width;
		sr.h=gif->height;
		SDL_FillRect(surf,&sr,pf->colorkey);
	} else {
		GIF_FRAME *p = &gif->frames[frame - 1];
		if (p->disposal_method == 2) {
			sr.x=xpos+p->xoff;
			sr.y=ypos+p->yoff;
			sr.w=p->bitmap_8_bit->w;
			sr.h=p->bitmap_8_bit->h;
			SDL_FillRect(surf,&sr,pf->colorkey);
		} else if (p->disposal_method == 3 && gif->store) {
			sr.x=sr.y=0;
			dr.x=xpos+p->xoff;
			dr.y=ypos+p->yoff;
			sr.w=dr.w=gif->store->w;
			sr.h=dr.h=gif->store->h;
			SDL_BlitSurface(gif->store,&sr,surf,&dr);
            SDL_FreeSurface(gif->store);
            gif->store = NULL;
        }
    }

    w = f->bitmap_8_bit->w;
    h = f->bitmap_8_bit->h;

    if (f->disposal_method == 3)
    {
        if (gif->store) SDL_FreeSurface(gif->store);
		/* Create a compatible surface to quickly save the area */
		gif->store=SDL_CreateRGBSurface(CREATE_FLAGS,w,h,pf->BitsPerPixel,pf->Rmask,pf->Gmask,pf->Bmask,pf->Amask);
		sr.x=xpos+f->xoff;
		sr.y=ypos+f->yoff;
		dr.x=dr.y=0;
		sr.w=dr.w=w;
		dr.h=dr.h=h;
		SDL_BlitSurface(surf,&sr,gif->store,&dr);
    }

	sr.x=0; sr.y=0; sr.w=w; sr.h=h;
	dr.x=xpos + f->xoff; dr.y=ypos + f->yoff; dr.w=w; dr.h=h;
	if (f->transparent_index!=-1) SDL_SetColorKey(f->bitmap_8_bit,SDL_SRCCOLORKEY,f->transparent_index);
	SDL_BlitSurface(f->bitmap_8_bit,&sr,surf,&dr);
}

/*--------------------------------------------------------------------------*/
GIF * GifNext(const GIF * gif)
{
	if (!gif) return head;
	return gif->next;
}

/*--------------------------------------------------------------------------*/
GIF * GifPrev(const GIF * gif)
{
	if (!gif) return tail;
	return gif->prev;
}

/*--------------------------------------------------------------------------*/
Boolean GifLoadAnim(const char * filename)
{
	int del,dur,x,y,tilex,tiley;
	char name[256];
	char * NameTerm=name;
	char * p;
	FILE * f;

	LOG(LOG_MSG,"GifLoadAnim: Processing Animation File \"%s\"\n",filename);

	f=fopen(filename,"rb");
	if (!f) {
		LOG(LOG_MSG,"GifLoadAnim: Log file \"%s\" not found\n",filename);
		return FALSE;
	}

	name[0]='\0';

	while (!feof(f)) {
		char buff[512];
		GIF * gif;

		/* Fetch the directory name */

		buff[0]='\0';
		fgets(buff,sizeof buff,f);
		p=strchr(buff,'\n');
		if (p) *p='\0';	/* Remove end of line \n marker */

#define IS_WHITE(C) ((C)==' ' || (C)=='\t')

		for (p=buff; IS_WHITE(*p); ++p) ;	/* Skip white space */
		if (!*p || *p=='#') continue;	/* Blank line or Comment line */

		if (!strnicmp(p,"dir=",4)) {
			/* Found a line specifying a directory */
			p+=4;
			while (IS_WHITE(*p)) ++p;
			strcpy(name,p);	/* Directory name */
			NameTerm=name+strlen(name);
			if (*name && (NameTerm[-1]!='\\' || NameTerm[-1]!='/')) *(NameTerm++)='/';
			continue;
		}

		if (sscanf(p,"%d %d %d %d %d %d%s",&del,&dur,&x,&y,&tilex,&tiley,NameTerm)!=7) break;

		gif=GifLoad(name);
		if (gif && !GifAddToDisplay(gif,dur)) {
			algif_destroy_raw_animation(gif->anim);
			gif=NULL;
		}

		if (!gif)
			LOG(LOG_MSG,"\tUnable to load: \"%s\"\n",name);
		else {
			LOG(LOG_MSG,"\t%s\n",name);
			gif->StartDelay=del;
			gif->x=x;
			gif->y=y;
			gif->TileX=tilex;
			gif->TileY=tiley;
		}
	}

	LOG(LOG_MSG,"GifLoadAnim: Finished loading \"%s\"\n",filename);

	return TRUE;
}

/*--------------------------------------------------------------------------*/
Boolean GifAddToDisplay(GIF * gif,int MinFrameDur)
{
	int i;

	if (!gif->anim) return TRUE;
	if (head==gif || gif->next || gif->prev) return FALSE; /* Already being displayed */

	if (MinFrameDur<1) MinFrameDur=1;

	if (!head)
		head=gif;
	else {
		tail->next=gif;
		gif->prev=tail;
	}
	tail=gif;

	for (i=0; i<gif->anim->frames_count; ++i) {
		/* Calculate total duration of all frames */

		if (gif->anim->frames[i].duration && gif->anim->frames[i].duration<MinFrameDur) {
			/* NOTE: Most browsers limit the minimum duration to about 1/10 second per frame */
			gif->anim->frames[i].duration=MinFrameDur;
		}

		gif->anim->duration+=gif->anim->frames[i].duration;
	}
	gif->anim->duration*=10;	/* Convert to milliseconds to match SDL timer */

	return TRUE;
}

/*--------------------------------------------------------------------------*/
GIF * GifLoad(const char * filename)
{
	GIF * gif=calloc(1,sizeof gif[0]);
	if (!gif) return NULL;

	gif->anim=algif_load_raw_animation(filename);

	if (!gif->anim) {
		LOG(LOG_MSG,"GifLoad: Unable to load \"%s\"\n",filename);
		free(gif);
		return NULL;
	}

	gif->TileX=gif->TileY=1;

	return gif;
}

/*--------------------------------------------------------------------------*/
Boolean GifRemoveFromDisplay(GIF * gif)
{
	if (!gif) return FALSE;

	/* Must be part of a list to be considered active */
	if (!gif->next && !gif->prev && gif!=head) return FALSE;

	/* It is part of the active display list. Unlink it */
	if (gif->prev)
		gif->prev->next=gif->next;
	else {
		head=gif->next;
	}
	if (gif->next)
		gif->next->prev=gif->prev;
	else {
		tail=gif->prev;
	}

	return TRUE;
}

/*--------------------------------------------------------------------------*/
void GifUnload(GIF * gif)
{
	if (!gif) return;
	GifRemoveFromDisplay(gif);
	algif_destroy_raw_animation(gif->anim);
	free(gif);
}

/*--------------------------------------------------------------------------*/
void GifUnloadAll(void)
{
	while (tail) GifUnload(tail);
}

/*--------------------------------------------------------------------------*/
void GifRestart(void)
{
	GIF * cur;

	/* Reset all anim sequences back to start */
	StartTime=SDL_GetTicks();

	for (cur=head; cur; cur=cur->next) cur->framenum=0;

	reset=TRUE;
}

/*--------------------------------------------------------------------------*/
Boolean GifUpdate(void)
{
	/* Returns non-zero if any anim changed */
	GIF * cur;
	Boolean up=reset;
	uint32 ticks=SDL_GetTicks()-StartTime;

	reset=FALSE;

	for (cur=head; cur; cur=cur->next) {
		/* Each animation has an optional startup delay */
		if (ticks>=cur->StartDelay) {
			uint32 diff=ticks-cur->StartDelay;	/* Time since delay is over */
			uint32 lastframe=cur->framenum;
			diff%=cur->anim->duration;	/* Remaining time is which part of the display cycle */
			for (cur->framenum=0; diff>=(unsigned)cur->anim->frames[cur->framenum].duration*10; diff-=(unsigned)cur->anim->frames[cur->framenum].duration*10,++cur->framenum) ;
			if (lastframe!=cur->framenum) up=TRUE;
		}
	}

	return up;
}

/*--------------------------------------------------------------------------*/
void GifDisplay(SDL_Surface * display)
{
	GIF * cur;

	for (cur=head; cur; cur=cur->next) {
		int nx,ny; /* Number of times to tile in x,y */

		if (cur->x<display->w && cur->y<display->h) {
			/* Only display anims that are on screen */
			int j,y=cur->y;

			nx=(display->w-cur->x+cur->anim->width-1)/cur->anim->width; /* Max tiles before offscreen */
			if (cur->TileX && cur->TileX<nx) nx=cur->TileX;
			ny=(display->h-cur->y+cur->anim->height-1)/cur->anim->height;
			if (cur->TileY && cur->TileY<ny) ny=cur->TileY;

			for (j=0; j<ny; y+=cur->anim->height,++j) {
				int i,x=cur->x;
				for (i=0; i<nx; x+=cur->anim->width,++i) {
					algif_render_frame(cur->anim,display,cur->framenum,x,y);
				}
			}
		}
	}
}

/*--------------------------------------------------------------------------*/
GIF * GifCreate(void)
{
	GIF * gif=calloc(1,sizeof gif[0]);
	GIF_ANIMATION * anim=calloc(1,sizeof anim[0]);

	if (!anim || !gif) {
		free(gif);
		free(anim);
		return NULL;
	}

	gif->anim=anim;
	gif->TileX=gif->TileY=1;

	anim->background_index=-1;
	anim->LoadCount=1;
	anim->loop=-1;

	return gif;
}

/*--------------------------------------------------------------------------*/
Boolean GifSave(const char * filename,const GIF * gif)
{
	GIF_ANIMATION * anim;
	SDL_Color colors[256];
	SDL_Palette pal;
	int i,n;
	int match=-1;
	int GlobalCount=0;	/* Number of frames that share same palette */
	Boolean UseGlobal;
	Boolean HasBackground;

	FILE * f;
	int xs,ys;	/* size of the anim */

	if (!filename || !filename[0] || !gif || !gif->anim) return TRUE;

	anim=gif->anim;

	if (!anim->frames_count) return TRUE;

	f=fopen(filename,"wb");
	if (!f) return TRUE;

	// Give this anim a file name if none already there */
	if (!gif->anim->filename) gif->anim->filename=strdup(filename);

	/* First we try and combine all surface palettes into one global palette */

	pal.colors=colors;
	pal.ncolors=0;

	for (xs=ys=i=0; i<anim->frames_count && pal.ncolors<=256; ++i) {
		int j;
		int w,h;

		/* Now we keep collecting unique colors */
		int ThisMatch=-1;
		GIF_FRAME * frame=anim->frames+i;
		SDL_Surface * surf=frame->bitmap_8_bit;
		SDL_Palette * FramePal=surf->format->palette;

		/* We scan thru all frames to locate the largest area that all the
		 * animations take up. This is the size of the whole gif image.
		*/
		w=frame->xoff+surf->w;
		h=frame->yoff+surf->h;
		if (w>xs) xs=w;
		if (h>ys) ys=h;

		if (frame->transparent_index>=0) {
			/* Add the transparency pixel first so it becomes the first palette color */
			ThisMatch&=AddColor(&pal,FramePal->colors,frame->transparent_index);
		}
		for (j=0; j<FramePal->ncolors && pal.ncolors<=256; ++j) {
			/* Add every color except the transparency color */
			if (j!=frame->transparent_index) ThisMatch&=AddColor(&pal,FramePal->colors,j);
		}
		if (ThisMatch) ++GlobalCount;
		match&=ThisMatch;
	}

	UseGlobal=anim->frames_count==1 || GlobalCount>=2;

	/* match == -1 means same palette everywhere plus all colors in each palette are unique
	 * This means absolutely no remapping of indicies required.
	 * match == 1 means same palette colors everywhere but there are remapping of indicies.
	 * match == 0 combining all palettes will result in > 256 colors.
	 * If match !=0 then we can use a global palette for all frames.
	 * GlobalCount holds the number of surfaces that share palettes.
	*/

	fwrite("GIF89a",1,6,f);
	pack_iputw(xs,f);
	pack_iputw(ys,f);
	/* 7 global palette
	 * 456 color richness
	 * 3 sorted
	 * 012 palette bits
	 */
	n=GetPalPow(pal.ncolors);
	i=(UseGlobal)?0x80:0;
	i|=0x70;	/* 8 bits per color ie: 8 bits red,8 bits green, 8 bits blue) */
	i|=n;

	fputc(i,f);

	HasBackground=UseGlobal && anim->background_index>=0;
//	fputc((HasBackground)?anim->background_index:0,f);
	fputc(0,f); /* Background is zero */

	fputc(0,f);	/* Aspect ratio not used */

	/* Clear to reset any extra garbage at the end of the palette */
	memset(pal.colors+pal.ncolors,0,(256-pal.ncolors)*sizeof pal.colors[0]);

	if (UseGlobal) {
		/* More than one frame can share palettes. We will write out a global palette */
		n=1<<(n+1);	/* Now the correct number of entries to write */
		for (i=0; i<n; ++i) {
			fputc(pal.colors[i].r,f);
			fputc(pal.colors[i].g,f);
			fputc(pal.colors[i].b,f);
		}
	}

	if (anim->loop!=-1) {
		/* Loop count extension. Must appear immediately after global palette. */
		putc(0x21,f); /* Extension Introducer. */
		putc(0xff,f); /* Application Extension. */
		putc(11,f);    /* Size. */
		fwrite("NETSCAPE2.0",1,11,f);
		putc(3,f); /* Size. */
		putc(1,f);
		pack_iputw(anim->loop,f);
		putc(0,f);
	}

	/* Ok now we can write out all of the frames.
	 * We will use the same loop as before to see if we need a global or local palette
	*/

	for (i=0; i<anim->frames_count; ++i) {
		int j;
		GIF_FRAME * frame=anim->frames+i;
		SDL_Surface * surf=frame->bitmap_8_bit;
		SDL_Palette * FramePal=surf->format->palette;
		int ThisMatch=-1;
		uint8 xlate[256];	/* Index translate if needed */
		uint8 * XlatePtr;
		Boolean FrameHasTrans;

		for (j=0; j<FramePal->ncolors && pal.ncolors<=256; ++j) {
			ThisMatch&=AddColor(&pal,FramePal->colors,j);
		}

		/* If ThisMatch is non-zero then we can use the global palette.
		 * A value of -1 means no index remapping. A value of 1 means we need remapping.
		 * 0 means we must use a local palette.
		*/

		putc(0x21,f); /* Extension Introducer. */
		putc(0xf9,f); /* Graphic Control Extension. */
		putc(4,f);    /* Size. */

		/* Disposal method, and enable transparency. */
		n=frame->disposal_method<<2;
		FrameHasTrans=frame->transparent_index!=-1;

		if (FrameHasTrans) n|=1;
		putc(n,f);

		pack_iputw(frame->duration,f); /* In 1/100th seconds. */

		if (ThisMatch==1) {
			for (j=0; j<FramePal->ncolors; ++j) xlate[j]=FindColor(&pal,FramePal->colors+j);
			for (; j<256; ++j) xlate[j]=j;
			XlatePtr=xlate;
		} else {
			XlatePtr=NULL;
		}

		/* Transparency color index */
		if (FrameHasTrans)
			putc((XlatePtr)?XlatePtr[frame->transparent_index]:frame->transparent_index,f);
		else {
			putc(0,f);
		}
		putc(0x00,f); /* Terminator. */

		putc(0x2c,f); /* Image Descriptor. */
		pack_iputw(frame->xoff,f);
		pack_iputw(frame->yoff,f);
		pack_iputw(surf->w,f);
		pack_iputw(surf->h,f);

		/* 7: local palette
		 * 6: interlaced
		 * 5: sorted
		 * 012: palette bits
		*/

		if (ThisMatch)
			j=n=0;	/* No local palette */
		else {
			j=GetPalPow(FramePal->ncolors);
			n=0x80|j;
		}
		putc(n,f);

		if (n) {
			/* Write out the local palette */
			n=1<<(j+1);
			for (j=0; j<n; ++j) {
				fputc(FramePal->colors[j].r,f);
				fputc(FramePal->colors[j].g,f);
				fputc(FramePal->colors[j].b,f);
			}
		}

		SDL_LockSurface(frame->bitmap_8_bit);
		LZW_encode(f,frame->bitmap_8_bit,XlatePtr);
		SDL_UnlockSurface(frame->bitmap_8_bit);

		putc(0x00,f); /* Terminator. */
	}
	putc(0x3b,f);     /* Trailer. */

	fclose(f);

	return FALSE;
}

/*--------------------------------------------------------------------------*/
int GifAppendFrame(GIF * gif,SDL_Surface * surf,int xoff,int yoff,int dur,int disposal)
{
	GIF_ANIMATION * anim=NULL;
	SDL_Surface * temp=NULL;
	GIF_FRAME * NewFrame;
	GIF_FRAME * frames;

	if (!gif || !gif->anim || !surf) return -1;

	anim=gif->anim;

	NewFrame=calloc(1,sizeof NewFrame[0]);
	if (!NewFrame) return -1;

	temp=GifCreate8BitCopy(surf,gif->quality);
	if (!temp) goto error;

	frames=realloc(anim->frames,(anim->frames_count+1)*sizeof anim->frames[0]);
	if (!frames) goto error;
	anim->frames=frames;

	/* Now point to the new entry */
	NewFrame=frames+anim->frames_count;
	NewFrame->bitmap_8_bit=temp;
	NewFrame->disposal_method=disposal;
	NewFrame->duration=dur;

	if (temp->flags & SDL_SRCCOLORKEY)
		NewFrame->transparent_index=temp->format->colorkey;
	else {
		NewFrame->transparent_index=-1;
	}

	NewFrame->xoff=xoff;
	NewFrame->yoff=yoff;

	return anim->frames_count++;

error:
	free(temp);
	algif_destroy_raw_animation(anim);

	return -1;
}

/*--------------------------------------------------------------------------*/
SDL_Surface * GifCreate8BitCopy(SDL_Surface * src,int quality)
{
	SDL_Surface * dst;
	int i;
	Boolean HasTrans;
	uint32 colorkey;

	if (!src) return NULL;

	if (src->format->BitsPerPixel==8) {
		/* Already 8 bit. Just make a copy */
		SDL_Palette * SrcPal,* DstPal;

		dst=SDL_CreateRGBSurface(
			CREATE_FLAGS,
			src->w,src->h,
			src->format->BitsPerPixel,
			src->format->Rmask,src->format->Gmask,src->format->Bmask,src->format->Amask
			);

		if (!dst) return NULL;

		/* Copy palette */
		SrcPal=src->format->palette;
		DstPal=dst->format->palette;
		DstPal->ncolors=SrcPal->ncolors;
		memcpy(DstPal->colors,SrcPal->colors,DstPal->ncolors*sizeof DstPal->colors[0]);
		for (i=0; i<DstPal->ncolors; ++i) DstPal->colors[i].unused=255;
		if (src->flags & SDL_SRCCOLORKEY) {
			i=src->format->colorkey;
			SDL_SetColorKey(dst,SDL_SRCCOLORKEY,i);
			DstPal->colors[i].unused=0;
		}

		/* Now copy the image */
		HasTrans=(src->flags & SDL_SRCCOLORKEY)!=0;
		colorkey=src->format->colorkey;
		SDL_SetColorKey(src,0,0);	/* Remove color key temporarily */
		SDL_BlitSurface(src,NULL,dst,NULL); /* Make a copy */
		if (HasTrans) SDL_SetColorKey(src,SDL_SRCCOLORKEY,colorkey);

	} else {
		SDL_PixelFormat fmt;
		SDL_Surface * Temp24Bit;

		memset(&fmt,0,sizeof fmt);
		fmt.BitsPerPixel=24;
		fmt.BytesPerPixel=3;

		fmt.Aloss=8;	/* Alpha not used in 24 bit */
		/* We want a BGR surface */
		fmt.Rshift=16;
		fmt.Gshift=8;
		fmt.Rmask=0x00ff0000;
		fmt.Gmask=0x0000ff00;
		fmt.Bmask=0x000000ff;
		fmt.alpha=255;

		Temp24Bit=SDL_ConvertSurface(src,&fmt,SDL_SWSURFACE);

		if (!Temp24Bit) return NULL;

		/* Create a paletted destination surface */
		dst=SDL_CreateRGBSurface(
			SDL_SWSURFACE,
			src->w,src->h,
			8,
			src->format->Rmask,src->format->Gmask,src->format->Bmask,src->format->Amask
			);

		if (dst) {
			int i,n;
			unsigned char * s,* d;

			n=Temp24Bit->w*Temp24Bit->h; /* Number of pixels */

			/* The last param in initnet is a value from 0..30 which indicates
			 * conversion quality (1=highest, 30=lowest).
			 * Obviously the smaller the number the longer conversion takes.
			*/
			if (!quality)
				quality=DEFAULT_CONVERT_QUALITY;
			else if (quality<10)
				quality=1;
			else if (quality>30) {
				quality=30;
			}

			SDL_LockSurface(src);

			initnet(Temp24Bit->pixels,3*n,quality);
			learn();
			unbiasnet();
			writecolourmap(dst);
			if (src->flags & SDL_SRCCOLORKEY) {
				uint8 r,g,b;
				SDL_GetRGB(src->format->colorkey,src->format,&r,&g,&b);
				i=SDL_MapRGB(dst->format,r,g,b);
				SDL_SetColorKey(dst,SDL_SRCCOLORKEY,i);
				dst->format->palette->colors[i].unused=0;
			}
			inxbuild();

			s=Temp24Bit->pixels;
			d=dst->pixels;
			for (i=0; i<n; s+=3,++d,++i) *d=inxsearch(s[0],s[1],s[2]);

			SDL_UnlockSurface(src);
		}

		SDL_FreeSurface(Temp24Bit);
	}

	return dst;
}
