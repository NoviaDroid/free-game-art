/*
    Angelion SDL client, a client program for the Angelion MMORPG.

	This file is code that was heavily borrowed from http://algif.sourceforge.net/
	which is Copyright (c) 2000-2004 algif contributors and is subject to
	the MIT licence: http://algif.sourceforge.net/#38

	Any portions not covered by the original algif licence are subject to the
	following licence:

  Copyright (C) 2003 James Little

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    The author can be reached via e-mail to jlittle@sric.com
*/

#ifndef __GIFANIM_H__
#define __GIFANIM_H__

typedef struct GIF_ANIMATION GIF_ANIMATION;
typedef struct GIF_FRAME GIF_FRAME;
typedef struct GIF GIF;

#define CONVERT_QUALITY_SLOWEST (1)	/* Highest quality */
#define CONVERT_QUALITY_FASTEST (30) /* Lowest quality */
#define DEFAULT_CONVERT_QUALITY (CONVERT_QUALITY_FASTEST)

struct GIF_ANIMATION
{
	char * filename;
	int LoadCount;
	int width, height;
	int frames_count;
	int background_index;
	int loop; /* -1 = no, 0 = forever, 1..65535 = that many times */
	GIF_FRAME *frames;

	uint32 duration;	/* Total duration in 1/1000 sec */
	SDL_Surface *store;
};

struct GIF_FRAME
{
	SDL_Surface * bitmap_8_bit;
	int xoff,yoff;
	int duration;			/* in 1/100th seconds */
	int disposal_method;	/* 0 = don't care, 1 = keep, 2 = background, 3 = previous */
	int transparent_index;
};

struct GIF {
	GIF * next,* prev;
	GIF_ANIMATION * anim;
	uint32 StartDelay;	/* Duration in 1/1000 sec before 1st anim plays */
	int x,y;	/* Coord to display */
	int TileX,TileY; /* 0=screen edge */
	int quality;	/* Conversion quality when appending frames that are not paletted */
	uint32 framenum;
};

GIF * GifLoad(const char * filename);
/* GifLoad load a single gif file but does not display it. You can manually
 * fill in the StartDelay, x, y, TileX, TileY and call GifAddToDisplay to add
 * the animation to the list being displayed.
 * The defaults are StartDelay=0, TileX=1, TileY=1, x=0, y=0
*/

Boolean GifAddToDisplay(GIF * gif,int MinFrameDur);
/* GifAddToDisplay adds the gif file to the animation list. The animation
 * will display the next time GifDisplay is called.
 * A return value of TRUE indicates success.
 * FALSE indicates an error (already in list) or no anim in the gif.
 * Note: In order to use StartDelay it must be set to SDL_Tick*()+value since
 * the delay is based from the timer start - not when the routine is called.
 * ALSO: The duration is calculated in this routine. This means that any time
 * you change the animation duration, you should remove it and re-add it back
 * so that everything is recalculated again. That process is quick and would
 * not pose any problem.
*/

Boolean GifLoadAnim(const char * filename);
/* GifLoadAnim loads gif files specified in a text file and displays them.
 * The routine returns TRUE if the file is loaded without errors.
*/

Boolean GifRemoveFromDisplay(GIF * gif);
/* GifRemoveFromDisplay will stop displaying the gif anim specified. It is
 * removed from the active list of anims being displayed.
 * A return value of TRUE indicates success where FALSE means the anim was not
 * in the display list to begin with.
 * The animation is not discarded. You have to call GifDiscard to free the
 * memory later.
*/

void GifUnload(GIF * gif);	/* Dispose of a single gif animation */
void GifUnloadAll(void);	/* Dispose of all loaded animations */

void GifRestart(void);	/* Reset all anim sequences back to start */
Boolean GifUpdate(void); /* Returns non-zero if any anim changed */
void GifDisplay(SDL_Surface * display); /* Draws all current anims to display surface */

/* Writing out new gif files:
 * You should use GifCreate() to create an empty gif animation.
 * Then you would append surfaces to that animation.
 * Once complete, you can save the animation.
 * You can even load an animation, append additional frames to the gif->anim part and
 * write it back out.
 * You should use GifUnload() for any anims created by GifCreate() after you
 * are done with them in order to free up allocated memory.
*/

GIF * GifCreate(void);	/* Create an empty gif animation */
/* GifCreate simply creates an empty animation so you can append surfaces to it */

typedef enum GifDispoal GifDisposal;
enum GifDisposal {
	GIF_Undefined,
	GIF_Keep,
	GIF_Background,
	GIF_Previous
};
/* The disposal method for gif files indicates what to do *after* the gif image
 * is displayed. Thus the disposal only occurs at the beginning of the next
 * frame.
 * GIF_Undefined: The decoder can do anything with the area defined by the
 * frame. ie: If there is no transparency in the following frames then you can
 * specify this as a disposal method.
 * GIF_Keep: The decoder must keep the resultant image for subsequent frames.
 * ie: The first image could be a background and then you could overlay
 * images onto it.
 * GIF_Background: Restore the area to the background color.
 * GID_Previous: This is the most "intensive" setting. The area under the image
 * is stored prior to being displayed. Once the frame is over (start of the
 * next frame), the area is restored prior to displaying the next frame.
 * You would use this for small animated images that move on a background.
*/

int GifAppendFrame(GIF * gif,SDL_Surface * surf,int xoff,int yoff,int dur,int disposal);
/* GifAppendFrame return -1 for error. The surface formats must all be 8 bit paletted.
 * Simply call this routine to append the next frame of animation. A copy is made so you can
 * do anything you want with the surface you passed in.
 * trans = transparent pixel index or -1 if none.
*/

Boolean GifSave(const char * filename,const GIF * gif);	/* Save anim to file. TRUE=error */

GIF * GifNext(const GIF * gif);
GIF * GifPrev(const GIF * gif);
/* GifNext, GifPrev returns the next/prev gif in the active display list
 * To obtain the first, GifNext(NULL) and to obtain the last, use GifPrev(NULL)
 * To go thru all gif animations you could do something like:
 * GIF * next=NULL;
 * while (next=GifNext(next)) { do_something(); }
*/

SDL_Surface * GifCreate8BitCopy(SDL_Surface * src,int quality);
/* GifCreate8BitCopy returns a copy of the source surface.
 * If the surface is not 8 bit paletted then a conversion is performed.
 * GifAppendFrame does use this routine if needed. This copy routine is exposed
 * simply since it is such a useful routine for sdl surfaces.
 * The quality parameter is a value from 1 to 30.
 * A value of 1 indicates "Highest Quality / Slowest Conversion"
 * A value of 30 indicates "Lowest Quality / Fastest Conversion"
*/

#endif // __GIFANIM_H__
