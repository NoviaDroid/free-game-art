/*
    Angelion SDL client, a client program for the Angelion MMORPG.

	This file is code that was heavily borrowed from http://algif.sourceforge.net/
	which is Copyright (c) 2000-2004 algif contributors and is subject to
	the MIT licence: http://algif.sourceforge.net/#38

	Copyright (c) 2000-2004 algif contributors

	Permission is hereby granted, free of charge, to any person obtaining a
	copy of this software and associated documentation files (the "Software"),
	to deal in the Software without restriction, including without limitation
	the rights to use, copy, modify, merge, publish, distribute, sublicense,
	and/or sell copies of the Software, and to permit persons to whom the
	Software is furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in
	all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
	DEALINGS IN THE SOFTWARE.


	Any portions not covered by the original algif licence are subject to the
	following licence:

  Copyright (C) 2003 James Little

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    The author can be reached via e-mail to jlittle@sric.com
*/

#include <include.h>
#include <lzw.h>

#define SDL_R(C) ((unsigned char)(C))
#define SDL_G(C) ((unsigned char)((C)>>8))
#define SDL_B(C) ((unsigned char)((C)>>16))

typedef union PIXFORMAT PIXFORMAT;

union PIXFORMAT {
	uint8 pix8[4];
	uint16 pix16[2];
	uint32 pix32;
};

static uint32 getpixel(SDL_Surface * surf,int x,int y)
{
	PIXFORMAT * pf;
	int BytesPerPixel=surf->format->BytesPerPixel;

	pf=(PIXFORMAT *)((int)surf->pixels+surf->pitch*y+x*BytesPerPixel);

	switch (BytesPerPixel) {
	case 1: return pf->pix8[0];
	case 2: return pf->pix16[0];
	case 3: return (uint32)pf->pix16[0] | ((uint32)pf->pix8[2] << 16);
	case 4: return pf->pix32;
	}

	return 0;
}

static int read_code (FILE * file, char *buf, int *bit_pos, int bit_size)
{
    int i;
    int code = 0;
    int pos = 1;

    for (i = 0; i < bit_size; i++)
    {
        int byte_pos = (*bit_pos >> 3) & 255;

        if (byte_pos == 0)
        {
            int data_len = (uint8)fgetc (file);

            if (data_len == 0)
            {
                //printf ("Fatal. Errorneous GIF stream.\n");
                //abort ();
                return -1;
            }
            fread (buf + 256 - data_len, 1, data_len, file);
            byte_pos = 256 - data_len;
            *bit_pos = byte_pos << 3;
        }
        if (buf[byte_pos] & (1 << (*bit_pos & 7)))
            code += pos;
        pos += pos;
        (*bit_pos)++;
    }
    return code;
}

static void write_code (FILE * file, char *buf, int *bit_pos, int bit_size, int code)
{
    int i;
    int pos = 1;

    for (i = 0; i < bit_size; i++)
    {
        int byte_pos = *bit_pos >> 3;

        if (code & pos)
            buf[byte_pos] |= (1 << (*bit_pos & 7));
        else
            buf[byte_pos] &= ~(1 << (*bit_pos & 7));
        (*bit_pos)++;
        if (*bit_pos == 2040)
        {
            fputc (byte_pos + 1, file);
            fwrite (buf, 1, byte_pos + 1, file);
            *bit_pos = 0;
        }
        pos += pos;
    }
}

static int read_pixel (SDL_Surface * surf, int pos, uint8 * IndexTranslate)
{
	uint32 n=getpixel (surf, pos % surf->w, pos / surf->w);

	if (surf->format->BitsPerPixel==8 && IndexTranslate) n=IndexTranslate[n];

    return n;
}

static void write_pixel (SDL_Surface * surf, int pos, int c)
{
	/* Since gif frames only use 8 bit paletted, the destination must be 8 bit and
	 * thus we don't need to bother with other surface formats. The surface passed
	 * in would be always 8 bit paletted.
	*/

	int x=pos % surf->w;
	int y=pos / surf->w;
	PIXFORMAT * pf;

	/* Unsigned cast so neg values appear as huge pos. Eliminates < 0 tests */
	if ((unsigned)x>=(unsigned)surf->w || (unsigned)y>=(unsigned)surf->h) return;

	pf=(PIXFORMAT *)((int)surf->pixels+surf->pitch*y+x*surf->format->BytesPerPixel);

	pf->pix8[0]=(uint8)c;
}

int LZW_decode (FILE * file, SDL_Surface * surf)
{
    int orig_bit_size;
    char buf[256];
    int bit_size;
    int bit_pos;
    int clear_marker;
    int end_marker;
    struct
    {
        int prefix;
        int c;
        int len;
    }
    codes[4096];                /* Maximum bit size is 12. */
    int n;
    int i, prev, code, c;
    int out_pos = 0;

    orig_bit_size = (uint8)fgetc (file);
    n = 2 + (1 << orig_bit_size);

    for (i = 0; i < n; i++)
    {
        codes[i].c = i;
        codes[i].len = 0;
    }

    clear_marker = n - 2;
    end_marker = n - 1;

    bit_size = orig_bit_size + 1;

    bit_pos = 0;

    /* Expect to read clear code as first code here. */
    prev = read_code (file, buf, &bit_pos, bit_size);
    if (prev == -1) return -1;

    do
    {
        code = read_code (file, buf, &bit_pos, bit_size);
        if (code == -1) return -1;

        if (code == clear_marker)
        {
            bit_size = orig_bit_size;
            n = 1 << bit_size;
            n += 2;
            bit_size++;
            prev = code;
            continue;
        }

        if (code == end_marker)
            break;

        /* Known code: ok. Else: must be doubled char. */
        if (code < n)
            c = code;
        else
            c = prev;

        /* Output the code. */
        out_pos += codes[c].len;
        i = 0;
        do
        {
            write_pixel (surf, out_pos - i, codes[c].c);
            if (codes[c].len)
                c = codes[c].prefix;
            else
                break;
            i++;
        }
        while (1);

        out_pos++;

        /* Unknown code -> must be double char. */
        if (code >= n)
        {
            write_pixel (surf, out_pos, codes[c].c);
            out_pos++;
        }

        /* Except after clear marker, build new code. */
        if (prev != clear_marker)
        {
            codes[n].prefix = prev;
            codes[n].len = codes[prev].len + 1;
            codes[n].c = codes[c].c;
            n++;
        }

        /* Out of bits? Increase. */
        if (n == (1 << bit_size))
        {
            if (bit_size < 12)
                bit_size++;
        }

        prev = code;
    }
    while (1);
    return 0;
}

static int
get_minimum_bitsize (SDL_Surface * surf)
{
    int x, y, max = 0, b = 2;
    for (y = 0; y < surf->h; y++)
    {
        for (x = 0; x < surf->w; x++)
        {
            int c = getpixel (surf, x, y);
            if (c > max)
                max = c;
        }
    }
    while ((1 << b) <= max)
    {
        b++;
    }
    return b;
}

void LZW_encode (FILE * file, SDL_Surface * surf,uint8 * IndexTranslate)
{
    int orig_bit_size;
    int bit_size;
    char buf[256];
    int bit_pos;
    int clear_marker;
    int end_marker;
    struct
    {
        int prefix;
        int c;
        int len;
    }
    codes[4096];                /* Maximum bit size is 12. */
    int code, prev;
    int in_pos;
    int n, i;

    orig_bit_size = get_minimum_bitsize (surf);

    n = 2 + (1 << orig_bit_size);

    for (i = 0; i < n; i++)
    {
        codes[i].c = i;
        codes[i].len = 0;
    }

    clear_marker = n - 2;
    end_marker = n - 1;

    fputc (orig_bit_size, file);

    bit_size = orig_bit_size + 1;

    bit_pos = 0;

    /* Play fair and put a clear marker at the start. */
    write_code (file, buf, &bit_pos, bit_size, clear_marker);

    prev = read_pixel (surf, 0, IndexTranslate);

    for (in_pos = 1; in_pos < surf->w * surf->h; in_pos++)
    {
        code = read_pixel (surf, in_pos, IndexTranslate);

        if (prev != clear_marker)
        {
            /* Search for the code. */
            for (i = end_marker + 1; i < n; i++)
            {
                if (codes[i].prefix == prev && codes[i].c == code)
                {
                    code = i;
                    break;
                }
            }

            /* If not found, add it, and write previous code. */
            if (i == n)
            {
                codes[n].prefix = prev;
                codes[n].len = codes[prev].len + 1;
                codes[n].c = code;
                n++;

                write_code (file, buf, &bit_pos, bit_size, prev);
            }
        }

        /* Out of bits? Increase. */
        if (n == 1 + (1 << bit_size))
        {
            if (bit_size < 12)
                bit_size++;
        }

        /* Too big table? Clear and start over. */
        if (n == 4096)
        {
            write_code (file, buf, &bit_pos, bit_size, clear_marker);
            bit_size = orig_bit_size + 1;
            n = end_marker + 1;
        }

        prev = code;
    }
    write_code (file, buf, &bit_pos, bit_size, prev);
    write_code (file, buf, &bit_pos, bit_size, end_marker);
    if (bit_pos)
    {
        int byte_pos = (bit_pos + 7) / 8;

        fputc (byte_pos, file);
        fwrite (buf, 1, byte_pos, file);
    }
}
