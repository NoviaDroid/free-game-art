/* Animation tool - By James Little
*/

/* Switched check from _WIN32 to _MSC_VER, because _WIN32 is OS, whereas _MSC_VER is compiler */
/* see: http://www.mobydisk.com/softdev/techinfo/cpptips.html */

#ifdef _MSC_VER
#define STRICT
#if _MSC_VER > 1000
#pragma once
#endif
#define WIN32_LEAN_AND_MEAN
#else
/* For argument list function: getopt */
#include <unistd.h>
#endif

#include <include.h>
#include <png.h>

#include "IMG_savepng.h"
#include "gifanim.h"

#define MAX_BUFFER 100

#define MAX_COLUMNS 10
#define MAX_ROWS 26

#define VERSION 1.60

#undef DEBUG

#ifndef MIN
#define MIN(x,y) ((x)<(y)?(x):(y))
#endif
#ifndef MAX
#define MAX(x,y) ((x)>(y)?(x):(y))
#endif

#define SCREEN_DEPTH (8)

#define OUTPUT_MODE_DEFAULT 0
#define OUTPUT_MODE_CUT     1
#define OUTPUT_MODE_WEB     2
#define OUTPUT_MODE_BIG     3

struct options_struct
  {
    int output_mode;
  } options_struct;
struct options_struct global_options;

Uint32 GetPixel(SDL_Surface *screen, int x, int y);

#ifndef getopt
#ifndef __GETOPT_H__
#ifndef _UNISTD_H

char *optarg;
int optind=1;

char getopt(int argc, char **argv, char *args)
  {
    char nCmd;
    int n;
    int nlen = (int) strlen(args);
    int nLen = 0;

    if (argv[optind] && *argv[optind] == '-')
      {
        nCmd = *((argv[optind] + 1));

        for (n = 0; n < nlen; n++)
          {
            if (args[n] == ':')
              continue;
            if (args[n] == nCmd)
              {
                if (args[n + 1] == ':')
                  {
                    char retVal;
                    retVal = *(argv[optind] + 1);
                    optarg = argv[optind + 1];
                    if (!optarg) optarg="";
                    optind += 2;
                    return retVal;
                  }
                else
                  {
                    char retVal;
                    retVal = *(argv[optind] + 1);
                    optarg = NULL;
                    optind += 1;
                    return retVal;
                  }
              }
          }
      }
    return -1;
  }
#endif
#endif
#endif

void DrawPixel(SDL_Surface *screen, int x, int y, Uint32 color);

typedef struct image_struct
  {
    int frame_width;    /* size of the "window" */
    int frame_height;
    int rows;           /* number of rows of images */
    int columns;        /* images per row */
    Uint32 seperator_color;
    Uint32 border_color;
    Uint32 marker_color;
    SDL_Surface *images[MAX_COLUMNS][MAX_ROWS];
    int row_height[MAX_ROWS];
    int column_width[MAX_COLUMNS];
    int max_height;
    int max_width;
  } image_struct;

void Slock(SDL_Surface *screen)
  {
    if (SDL_MUSTLOCK(screen))
      if (SDL_LockSurface(screen) < 0)
        return;
  }

void Sulock(SDL_Surface *screen)
  {
    if (SDL_MUSTLOCK(screen))
      SDL_UnlockSurface(screen);
  }

void CopyPalette(SDL_Surface *dst, const SDL_Surface *src)
  {
    int s;
    SDL_Palette *DstPal = dst->format->palette;
    const SDL_Palette *SrcPal = src->format->palette;

    DstPal->ncolors = SrcPal->ncolors;
    SDL_SetColors(dst, SrcPal->colors, 0, SrcPal->ncolors);

    /* For some reason, if you SDL_Init(0) vs SDL_Init(SDL_INIT_VIDEO) 
     * SDL_SetColors above does not work... SO, here is a very ugly
     * way around that, which I'm sure is bad bad bad, but we need to 
     * be able to generate these images without Initializing the video
     * subsystem which crashes if you are trying to do this remotely and
     * have no intention of actualy seeing this stuff.
     *  -- James Little
     */
    for (s = 0; s < 256; s++)
      {
        dst->format->palette->colors[s].r = src->format->palette->colors[s].r; 
        dst->format->palette->colors[s].g = src->format->palette->colors[s].g; 
        dst->format->palette->colors[s].b = src->format->palette->colors[s].b;
        dst->format->palette->colors[s].unused = src->format->palette->colors[s].unused;
      }


    if (src->flags & SDL_SRCCOLORKEY)
      {
        /* Copy the color key as well */
        SDL_SetColorKey(dst, SDL_SRCCOLORKEY, src->format->colorkey);
      }
  }

void PaletteFixup(SDL_Surface *surf)
  {
    int counts[256];
    int n = surf->w * surf->h;
    int nColors = 0;
    int xlate[256];
    SDL_Palette *SrcPal = surf->format->palette;
    SDL_Color *SrcColors = SrcPal->colors;
    SDL_Color pal[256];
    uint8 *p;
    int i;

    Slock(surf);

    memset(counts, 0, sizeof counts);
    memset(xlate, 0, sizeof xlate);
    memset(pal, 0, sizeof pal);

    /* Scan all pixels and compute which pixels are used */
    for (p = surf->pixels, i = 0; i < n; ++p, ++i) ++counts[*p];

    /* Quick check to see if palette adjustments are needed */
    for (nColors = 256; nColors; --nColors) if (counts[nColors - 1]) break;    /* Stop at last used entry */
    for (i = 0; i < nColors; ++i) if (!counts[i]) break; /* See if all colors are used */

    if (i == nColors)
      {
        /* All colors are used. Just set the count to the correct value */
        SrcPal->ncolors = nColors;
        return;
      }

    /* Go thru all used palette entries and reassign them in case there are
     * gaps in the indicies.
     */
    for (nColors = i = 0; i < 256; ++i)
      {
        if (counts[i])
          {
            /* index i is used. Assign it the next available number */
            xlate[i] = nColors;
            pal[nColors] = SrcColors[i];    /* Also copy the palette color */
            ++nColors;
          }
      }

    if (nColors < 256)
      {
        /* New palette is built. Copy it over */
        SrcPal->ncolors = nColors;
        SDL_SetColors(surf, pal, 0, nColors);

        /* Now reassign all indicies in the bitmap */
        for (p = surf->pixels,i = 0; i < n; ++p,++i) *p = xlate[*p];

        if (surf->flags & SDL_SRCCOLORKEY)
          {
            /* Don't forget to translate the colorkey (if any) */
            surf->format->colorkey = xlate[surf->format->colorkey];
          }
      }

    Sulock(surf);
  }

int clear_image_struct(image_struct *img)
  {
    int c;
    int r;

    img->frame_width = 0;    /* size of the "window" */
    img->frame_height = 0;
    img->rows = 0;           /* number of rows of images */
    img->columns = 0;        /* images per row */
    img->seperator_color = 0;

    for (r = 0; r < MAX_ROWS; r++) for (c = 0; c < MAX_COLUMNS; c++) img->images[c][r] = NULL;
    return 0;
  }

int determine_frame_width(SDL_Surface *src,image_struct *img)
  {
    int x;
    Uint32 indicator;
    Slock(src);

    x = 1;
    while (x < src->w)
      {
        if (GetPixel(src, x, 0) == img->seperator_color) break;
        x++;
      }
    Sulock(src);
#ifdef DEBUG
    printf("frame width = %d\n", x);
#endif
    return x;
  }

int determine_columns(SDL_Surface *src,image_struct *img)
  {
    int num_columns;
    int x;

    Slock(src);

    num_columns = 0;
    x = 0;
    while (x * img->frame_width < src->w)
      {
        if (GetPixel(src, x * img->frame_width, 0) != img->seperator_color ) break;
        x++;
      }
    Sulock(src);
#ifdef DEBUG
    printf("num_columns = %d\n", x);
#endif

    return x;
}

int determine_frame_height(SDL_Surface *src,image_struct *img)
{
    int y;
    Slock(src);
    y = 1;
    while (y < src->h)
      {
        if (GetPixel(src, 0, y) == img->seperator_color) break;
        y++;
      }
    Sulock(src);
#ifdef DEBUG
    printf("frame height = %d\n", y);
#endif
    return y;
}

int determine_rows(SDL_Surface *src, image_struct *img)
  {
    int y;
    int num_rows;

    Slock(src);

    num_rows = 0;
    y = 0;
    while (y * img->frame_height < src->h)
      {
        if (GetPixel(src, 0, y * img->frame_height) != img->seperator_color) break;
        y++;
      }
    Sulock(src);

#ifdef DEBUG
    printf("num_rows = %d\n",y);
#endif
    return y;
  }

Uint32 determine_marker_color(SDL_Surface *src, image_struct *img)
  {
    int x;
    int num_columns;

    Slock(src);

    num_columns = 0;
    x = 2;
    while (x < img->frame_width)
      {
        if (GetPixel(src, x, 0) != img->border_color ) break;
        x++;
      }
    Sulock(src);

#ifdef DEBUG
    printf("marker_color = %d\n", GetPixel(src, x, 0));
#endif
    return GetPixel(src, x, 0);
  }

void add_color_to_surface(SDL_Surface *dest, Uint8 red, Uint8 green, Uint8 blue)
  {
    int i;
    int r_code;
    SDL_Color colors[256];
    Uint8 ncol = dest->format->palette->ncolors;

    for (i = 0; i < ncol; i++)
      {
        colors[i].r = dest->format->palette->colors[i].r;
        colors[i].g = dest->format->palette->colors[i].g;
        colors[i].b = dest->format->palette->colors[i].b;
      }

    colors[ncol].r = red;
    colors[ncol].g = green;
    colors[ncol].b = blue;
    ncol++;

    r_code = SDL_SetColors(dest, colors, 0, ncol);
    /*printf("return code=%d",r_code);*/
    dest->format->palette->ncolors = ncol;  /* only way I could get it to work... */
  }

void copy_pixel_to_pixel(SDL_Surface *src,SDL_Surface *dest,int x1,int y1,int x2,int y2,float brightness)
  {
    Uint32 color;
    Uint8 blue;
    Uint8 blue_2;
    Uint8 green;
    Uint8 green_2;
    Uint8 red;
    Uint8 red_2;

    color = GetPixel(src, x1, y1);
    SDL_GetRGB(color, src->format, &red, &green, &blue);

    red = (Uint8) ((float) red * brightness);
    green = (Uint8) ((float) green * brightness);
    blue = (Uint8) ((float) blue * brightness);

    color = SDL_MapRGB(dest->format, red, green, blue);

    if (dest->format->BitsPerPixel == 8)
      {
        SDL_GetRGB(color, dest->format, &red_2, &green_2, &blue_2);
        if ((red != red_2) || (green != green_2) || (blue != blue_2))
          {
            /*printf("bad color match %d %d %d\n", red, green, blue);    */

            add_color_to_surface(dest, red, green, blue);

            color = SDL_MapRGB(dest->format, red, green, blue); /* should work this time */
          }
      }
    DrawPixel(dest,x2, y2, color);
  }

int row_has_nonbackground(SDL_Surface *src, image_struct *img, int y, int x1, int x2)
  {
    int found = 0;
    int x;

    Slock(src);

    for (x = x1; x < x2; x++)
      if (GetPixel(src, x, y) != img->seperator_color)
        {
          found = 1;
          /* printf("Found non background at: %d,%d .. %d!=%d\n",x,y,GetPixel(src,x,y),src->format->colorkey); */
          break;
        }

    Sulock(src);
    return found;
  }

int column_has_nonbackground( SDL_Surface *src, image_struct *img,int x, int y1,int y2)
  {
    int y;
    int found = 0;

    Slock(src);

    for (y = y1; y < y2; y++)
      if (GetPixel(src, x, y) != img->seperator_color)
        {
          found = 1;
          /* printf("Found non background at: %d,%d .. %d!=%d\n",x,y,GetPixel(src,x,y),src->format->colorkey);*/
          break;
        }

    Sulock(src);
    return found;
  }

int find_marker_column( SDL_Surface *src,struct image_struct *dest, int y, int x1,int x2)
  {
    int found = 0;
    int x;

    Slock(src);

    for (x = x1; x < x2; x++)
      if (GetPixel(src, x, y) == dest->marker_color)
        {
          return x;
          break;
        }

    Sulock(src);
    return -1;
  }

int find_marker_row( SDL_Surface *src,struct image_struct *dest, int x, int y1,int y2)
  {
    int found = 0;
    int y;

    Slock(src);

    for (y = y1; y < y2; y++)
      if (GetPixel(src, x, y) == dest->marker_color)
        {
          return y;
          break;
        }

    Sulock(src);
    return -1;
  }

SDL_Surface *Get_Image( SDL_Surface *src,struct image_struct *dest,int col, int row, int *image_size)
  {
    int extra_x = 0;
    int extra_y = 0;
    int marker_x;
    int marker_y;
    int max_x1;
    int max_y1;
    int min_x1;
    int min_y1;
    int real_min_x1;
    int real_max_y1;
    int x;
    int x2;
    int y;
    int y2;
    int XOFFSET;
    int YOFFSET;

    SDL_Surface *destination;

    if (*image_size==0)
      {
        XOFFSET = 24;
        YOFFSET = 12;
      }
    if (*image_size==1)
      {
        XOFFSET = 48;
        YOFFSET = 24;
      }

    Slock(src);

    /*printf("Row=%d Col=%d ",row,col);*/

    min_x1 = (dest->frame_width * col) + 1;               /* absolute bigest the frame will hold */
    max_x1 = (dest->frame_width * (col + 1)) - 1;
    min_y1 = (dest->frame_height * row) + 1; 
    max_y1 = (dest->frame_height * (row + 1)) - 1;

    /*printf(" Image=(%d,%d),(%d,%d) ",min_x1,min_y1,max_x1,max_y1);*/

    marker_x = find_marker_column(src, dest, min_y1 - 1, min_x1, max_x1);    /* center of feet */
    marker_y = find_marker_row(src, dest, min_x1 - 1, min_y1, max_y1);

    real_min_x1 = min_x1;
    real_max_y1 = max_y1;

    /* truncate top of image */
    while ((row_has_nonbackground(src, dest, min_y1, min_x1, max_x1) == 0) && (min_y1 < max_y1))
      {
        min_y1++;
      }
    /* truncate bottom of image */
    while ((row_has_nonbackground(src, dest,max_y1, min_x1, max_x1) == 0) && (min_y1 < max_y1))
      {
        max_y1--;
      }
    /* truncate left of image */
    while ((column_has_nonbackground(src, dest,min_x1, min_y1, max_y1) == 0) && (min_x1 < max_x1))
      {
        min_x1++;
      }
    /* truncate right of image */
    while ((column_has_nonbackground(src, dest,max_x1, min_y1, max_y1) == 0) && (min_x1 < max_x1))
      {
        max_x1--;
      }

    if (max_x1 < min_x1) max_x1 = min_x1;   /* some sanity checks */
    if (max_y1 < min_y1) max_y1 = min_y1;

    if ((min_x1 == max_x1) && (min_y1 == max_y1)) return NULL; /* no image, quit */
    if ((marker_y == -1 ) || (marker_x == -1)) return NULL;   /* we have a marker */

    /* min_y1, min_x1, max_y1, max_x1 are now a tight box around the image */

    /* lets look at the width to determin if this is a BIG image */
    if ((max_x1 - min_x1 > 48) && (*image_size == 0)) /* big enough to be 2x2 */
      {
        *image_size = 1;   /* force future images large.. auto detect sorta */

        /* printf(" Image at col %d row %d ( width=%d > 48 ) forced enlargement in imagesize to 2x2\n",col,row,(max_x1-min_x1) );
       */

        YOFFSET = 24;  /* double size */
        XOFFSET = 48;  /* double size */
      }

    if ((marker_x - min_x1 > 24 ) && (*image_size == 0))
      {
        /*
        printf(" Image at col %d row %d  (left of marker = %d > 24) ) will not be placed correctly by client\n",col,row,(marker_x-min_x1) );
       */
      }

    max_y1 = marker_y + YOFFSET;   /* this is where the bottom of the image should be acording to the marker calc*/ 
    min_x1 = marker_x - XOFFSET;   /* this is where the left side the image should be acording to the marker calc*/ 

    if (min_x1 < real_min_x1)    /* we have extended out of src pic.. make a note of it */
      {
        extra_x = real_min_x1 - min_x1;
        min_x1 = real_min_x1;
      }

    if (max_y1 > real_max_y1)   /* we have extended out of src pic... make a note of it */
      {
        extra_y = max_y1 - real_max_y1;  /* extra padding on the bottom of the destination image */
        max_y1 = real_max_y1;
      }

    /* What we really need here is to have the size of the destination and the size of the source seperate */  

    destination = SDL_CreateRGBSurface(src->flags, (max_x1 - min_x1) + 1 + extra_x, (max_y1 - min_y1) + 1 + extra_y,
                                      src->format->BitsPerPixel,
                                      src->format->Rmask,
                                      src->format->Gmask,
                                      src->format->Bmask,
                                      src->format->Amask);
    CopyPalette(destination, src);
    Slock(destination);

    if (!(destination->flags & SDL_SRCCOLORKEY))
      {
        /* If there still is no transparency then fetch it from pixel (0,0) */
        SDL_SetColorKey(destination, SDL_SRCCOLORKEY, GetPixel(src, 0, 0));
      }

    SDL_FillRect(destination, NULL, destination->format->colorkey);

    /* printf(" actual(%d,%d) to (%d,%d) \n",min_x1,min_y1,max_x1,max_y1); */
    /* now to copy everything to the new surface ! */
    x2 = 0;
    for (x = min_x1; x <= max_x1; x++)
      {
        y2 = 0;
        for (y = min_y1; y <= max_y1; y++)
          {
            /*printf("(%d,%d)",x2,y2);*/
            copy_pixel_to_pixel(src, destination, x, y, x2 + extra_x, y2, 1.0);
            y2++;
          }
        x2++;
      }
    /*printf("\n");*/
    Sulock(src);
    Sulock(destination);
    return destination;
  }


void Parse_Image(SDL_Surface *src,image_struct *dest)
  {
    int c;
    int r;
    static int image_size = 0; /* 0 = small; 1 = 2x2 */

    Slock(src);
    dest->seperator_color = GetPixel(src, 0, 0); 
    /*printf("seperator_color = %d\n",dest->seperator_color ); */
    dest->border_color    = GetPixel(src,1,0); 
    /*printf("border_color = %d\n",dest->border_color );*/

    dest->frame_width  = determine_frame_width(src,dest);
    dest->frame_height = determine_frame_height(src,dest);
    dest->columns      = determine_columns( src, dest);
    dest->rows         = determine_rows( src, dest);
    dest->marker_color = determine_marker_color( src, dest); 

    /* now lets grab the images... */
    dest->max_height   = 0;
    dest->max_width    = 0;
    for (r=0;r<dest->rows;r++) 
      {
        for (c=0;c<dest->columns;c++)
          {
             if (dest->images[c][r] != NULL) SDL_FreeSurface(dest->images[c][r]);

             dest->images[c][r] = Get_Image(src,dest, c, r, &image_size);

             if (dest->images[c][r])
               {
                 dest->max_height = MAX(dest->max_height, dest->images[c][r]->h);
                 dest->max_width  = MAX(dest->max_width, dest->images[c][r]->w);
               }
          }
        /* determine the max height for this row */
        dest->row_height[r] = 0;

        for (c = 0; c < dest->columns; c++)
          if (dest->images[c][r])  /* if it exists */
            if (dest->images[c][r]->h > dest->row_height[r])
              dest->row_height[r] = dest->images[c][r]->h;
      }
    /* calculate with of columns */
    for (c = 0; c < dest->columns; c++)
      {
        dest->column_width[c] = 0;
        for (r = 0; r < dest->rows; r++)
          if (dest->images[c][r])  /* if it exists */
            if (dest->images[c][r]->w > dest->column_width[c])
              dest->column_width[c] = dest->images[c][r]->w;
      }
    Sulock(src);
  }

void DrawIMG(SDL_Surface *screen,SDL_Surface *img, int x, int y)
  {
    SDL_Rect dest;
    dest.x = x;
    dest.y = y-img->h;
    SDL_BlitSurface(img, NULL, screen, &dest);
  }

void CutPics(image_struct *images,char *dest_file_name)  /* dumps images to individual files */
  {
    char filename[MAX_BUFFER];  /* eek.. potential buffer overflow */
    int c;
    int dir_temp;
    int r;
    int row_temp;

    for (r = 0; r < images->rows; r++)
      {
        row_temp = 0;

        if ((r / 8) + 1 == 1)  /* top 8 */
          row_temp = 2;        /* attack */

        if ((r / 8) + 1 == 2)  /* 2nd 8 */
          row_temp = 1;        /* idle */

        if ((r / 8) + 1 == 3)   /* 2nd 8 */
           row_temp = 3;        /* idle */

        dir_temp = 0;   /* this asumes 1st image in group is facing directly away from screen */
        dir_temp = (r % 8);

        if (dir_temp == 0) dir_temp = 8;

        for (c = 0; c < images->columns; c++)
          {
            sprintf((char *) &filename, "%s.%d%d%d.png", dest_file_name, row_temp, dir_temp, c + 1);
            if (images->images[c][r] != NULL)
              {
                /*savepng(images.images[c][r],filename);*/
                IMG_SavePNG(filename, images->images[c][r], 0);
              }
           }
      }
  }

int make_big_animation(image_struct *images,char *dest_file_name)
  {
    char filename[MAX_BUFFER];  /* eek.. potential buffer overflow */
    int c;
    int r;
    GIF *tmp_gif;
    SDL_Surface *destination;  /* temp storage for drawing to */
    SDL_Surface *src = NULL;

    sprintf((char *) &filename, "%s.gif", dest_file_name);

    /* we need a good src image to copy it's attributes */
    for (r = 0; r < images->rows; r++)
      for (c = 0; c < images->columns; c++)
        if (images->images[c][r] != NULL)
          {
            src = images->images[c][r];
            c = images->columns;
            r = images->rows;
          }
        if (src == NULL)
          {
            printf("Error: src image has no frames\n");
            return 0;
          }
    destination = SDL_CreateRGBSurface(src->flags,
                                      (images->max_width + 5) * (9 + images->columns),
                                      (images->max_height + 5) * 3,
                                      src->format->BitsPerPixel,
                                      src->format->Rmask,
                                      src->format->Gmask,
                                      src->format->Bmask,
                                      src->format->Amask);

    CopyPalette(destination,src);

    /* now we are ready to do it... */
    Slock(destination);

    tmp_gif = GifCreate();
    for (c = 0; c < 8; c++)
      {
        DrawIT(destination, images);

        SDL_SetColorKey(destination, SDL_SRCCOLORKEY, images->seperator_color);
          {
            int i;
            for (i = 0; i < 256; ++i)
            destination->format->palette->colors[i].unused = 255;
          }
        destination->format->palette->colors[images->seperator_color].unused = 0;
        GifAppendFrame(tmp_gif, destination, 0, 0, 25, GIF_Background);
      }
     tmp_gif->anim->loop = 0; /* loop forever */
     printf("Gif Save:%d\n:", GifSave(filename, tmp_gif) );    /* Save anim to file. TRUE=error */
     GifUnload(tmp_gif);
  }

void CutSingleRotation(image_struct *images,char *dest_file_name,int force)  /* dumps images to individual files */
  {
    char filename[MAX_BUFFER];  /* eek.. potential buffer overflow */
    int c;
    int dir_temp;
    int got_it = 0;
    /* adding in force, to give animations with the MOST frames */
    int group_0 =0;
    int group_1 =0;
    int group_2 =0;
    int r;
    int row_temp;
    GIF *tmp_gif;

    /* first, find a row with all eight directions */
    row_temp = 0;
    got_it = 0;
    for (r = 0; r < 8; r++) if (images->images[0][r]== NULL) got_it = 1; else group_0++;
    if (!got_it) row_temp = 0;
    if (got_it)
      {
        got_it = 0;
        for (r = 8; r < 16; r++) if (images->images[0][r] == NULL) got_it = 1; else group_1++;
        if (!got_it) row_temp = 8;
      }

    if (got_it)
      {
        got_it = 0;
        for (r = 16; r < 24; r++) if (images->images[0][r] == NULL) got_it = 1; else group_2++;
        if (!got_it) row_temp = 16;
      }

    if (got_it)  /* no full rows */
      {
        if ((group_0 > group_1) && (group_0 > group_2)) { got_it = 0; row_temp = 0; }
        if ((group_1 > group_0) && (group_1 > group_2)) { got_it = 0; row_temp = 8; }
        if ((group_2 > group_0) && (group_2 > group_1)) { got_it = 0; row_temp = 16; }
      }

    if (!got_it)  /* we found all 8 dirs */
      {
        sprintf((char *) &filename, "%s.gif", dest_file_name);
        tmp_gif = GifCreate();
        for (r = row_temp; r < row_temp + 8; r++)
          {
            if (images->images[0][r] != NULL)
              GifAppendFrame(tmp_gif, images->images[0][r],
                              0, images->max_height-images->images[0][r]->h,
                              25, GIF_Background);
          }
        tmp_gif->anim->loop = 0;
        GifSave(filename, tmp_gif);
        GifUnload(tmp_gif);
      }
  }

int DrawIT(SDL_Surface *screen, image_struct *dest)
  {
    int c;
    int c1;
    int frame;
    int r;
    int rotate;
    int x;
    int y;
    int ypos = 0;
    static int t = 0;

    SDL_FillRect( screen, NULL, dest->seperator_color);

    t++;
    frame = t % dest->columns;
    rotate = t % 8;

    /* show top "Attack row" */
    for (c1 = 0; c1 < 8; c1++)
      {
        r = c1;
        c = frame;
        x = c1 * (dest->max_width + 5);
        y = dest->max_height + 5;
        if (dest->images[c][r])
          DrawIMG(screen, dest->images[c][r], x, y);
        else if (dest->images[0][r])
          DrawIMG(screen, dest->images[0][r], x, y);
      }

    for (c1 = 0; c1 < 8; c1++)
      {
        r = 8 + c1;
        c = frame;
        x = c1 * (dest->max_width + 5);
        y = (dest->max_height * 2) + 5;
        if (dest->images[c][r])
          DrawIMG(screen, dest->images[c][r], x, y);
        else if (dest->images[0][r])
          DrawIMG(screen, dest->images[0][r], x, y);

      }

    for (c1 = 0; c1 < 8; c1++)
      {
        r = 16 + c1;
        if (dest->columns == 3) /* 3 animations for walking */
          {
            c = t % 4;  /* c is now 0..3 */
            /*
              c == 0 : 0
              c == 1 : 1
              c == 2 : 0
              c == 3 : 2
            */
            if ((c == 0) || (c == 2))
              c = 0;
            else if (c == 3)
              c = 2;
          }
        else
          c = frame;
        x = c1 * (dest->max_width + 5);
        y = (dest->max_height * 3) + 5;
        if (dest->images[c][r])
          DrawIMG(screen, dest->images[c][r], x, y);
        else if (dest->images[0][r])
          DrawIMG(screen, dest->images[0][r], x, y);
      }

    /* lets draw them rotating in place */
    for (c1 = 0; c1 < dest->columns; c1++)
      {
        r = rotate;
        c = 0;
        x = (9 + c1) * (dest->max_width + 5);
        y = (dest->max_height * 1) + 5;
        if (dest->images[c1][r])
          DrawIMG(screen, dest->images[c1][r], x, y);
        else if (dest->images[0][r])
          DrawIMG(screen, dest->images[0][r], x, y);
      }

    for (c1 = 0; c1 < dest->columns; c1++)
      {
        r = 8 + rotate;
        c = 0;
        x = (9 + c1) * (dest->max_width + 5);
        y = (dest->max_height * 2) + 5;
        if (dest->images[c1][r])
          DrawIMG(screen, dest->images[c1][r], x, y);
        else if (dest->images[0][r])
          DrawIMG(screen, dest->images[0][r], x, y);

      }

    for (c1=0; c1 < dest->columns; c1++)
      {
        r = 16 + rotate;
        c = 0;
        x = (9 + c1) * (dest->max_width + 5);
        y = (dest->max_height * 3) + 5;
        if (dest->images[c1][r])
          DrawIMG(screen, dest->images[c1][r], x, y);
        else if (dest->images[0][r])
          DrawIMG(screen, dest->images[0][r], x, y);
      }
  }

void DrawPixel(SDL_Surface *screen, int x, int y, Uint32 color)
  {
    /*Uint32 color = SDL_MapRGB(screen->format, R, G, B); */
    switch (screen->format->BytesPerPixel)
      {
        case 1: // Assuming 8-bpp
          {
            Uint8 *bufp;
            bufp = (Uint8 *) screen->pixels + y * screen->pitch + x;
            *bufp = color;
          }
          break;
        case 2: // Probably 15-bpp or 16-bpp
          {
            Uint16 *bufp;
            bufp = (Uint16 *) screen->pixels + y * screen->pitch / 2 + x;
            *bufp = color;
          }
          break;
        case 3: // Slow 24-bpp mode, usually not used
          {
            Uint8 *bufp;
            bufp = (Uint8 *)screen->pixels + y*screen->pitch + x * 3;
            if (SDL_BYTEORDER == SDL_LIL_ENDIAN)
              {
                bufp[0] = color;
                bufp[1] = color >> 8;
                bufp[2] = color >> 16;
              }
            else
              {
                bufp[2] = color;
                bufp[1] = color >> 8;
                bufp[0] = color >> 16;
              }
          }
          break;
        case 4: // Probably 32-bpp
          {
            Uint32 *bufp;
            bufp = (Uint32 *) screen->pixels + y * screen->pitch / 4 + x;
            *bufp = color;
          }
          break;
      }
  }

Uint32 GetPixel(SDL_Surface *screen, int x, int y)
  {
    switch (screen->format->BytesPerPixel)
      {
        case 1: // Assuming 8-bpp
          {
            Uint8 *bufp;
            bufp = (Uint8 *) screen->pixels + y * screen->pitch + x;
            return (Uint32) *bufp;
          }
          break;
        case 2: // Probably 15-bpp or 16-bpp
          {
            Uint16 *bufp;
            bufp = (Uint16 *) screen->pixels + y * screen->pitch / 2 + x;
            return (Uint32) *bufp;
          }
          break;
        case 3: // Slow 24-bpp mode, usually not used
          {
            Uint32 color;
            Uint8 *bufp;
            bufp = (Uint8 *)screen->pixels + y*screen->pitch + x * 3;
            if (SDL_BYTEORDER == SDL_LIL_ENDIAN)
              {
                /*
                  bufp[0] = color;
                  bufp[1] = color >> 8;
                  bufp[2] = color >> 16;
                 */
                return (color = bufp[0] + (bufp[1] << 8) + (bufp[2] << 16));
              }
            else
              {
                /*
                  bufp[2] = color;
                  bufp[1] = color >> 8;
                  bufp[0] = color >> 16;
                 */
                return (color = bufp[2] + (bufp[1] << 8) + (bufp[0] << 16));
              }
          }
          break;
        case 4: // Probably 32-bpp
          {
            Uint32 *bufp;
            bufp = (Uint32 *)screen->pixels + y*screen->pitch/4 + x;
            return (*bufp); // = color;
          }
          break;
      }
    return 0;
  }

int main(int argc, char *argv[])
  {
    char destfilename[MAX_BUFFER];
    char srcfilename[MAX_BUFFER];
    char ss_filename[MAX_BUFFER];
    char title[MAX_BUFFER];
    int c;
    int cur_width;
    int cur_height;
    int done = 0;
    int exp = 0;
    int got_file_name = 0;
    /*int just_single_rotation = 0;*/  /* Get 1 .gif rotating 8 dirs */
    int loop = 0;
    int ss = 0;
    int ss_temp = 0;
    struct image_struct images;
    GIF *tmp_gif;
    SDL_Surface *bitmap;
    SDL_Surface *screen;

    /*printf("Startup\n"); */

    clear_image_struct(&images);

    /* default mode: display to screen */
    global_options.output_mode = OUTPUT_MODE_DEFAULT;

    if (argc < 2)
      {
        FILE *fp = fopen("animation_helper.dat", "r");
        if (!fp)
          {
            printf(" Error: No animation_helper.dat\n");
            return 0;
          }

        fscanf(fp, "%s", &srcfilename);
        got_file_name = 1;

        fclose(fp);
        printf("No cmd line parameters, reading src file from animation_helper.dat: %s\n",srcfilename);
      }
    else
      {
        /* straight from the getopt man page... */
        while (1)
          {
            c = getopt(argc, argv, "f:csbh");

            if (c == -1) break;   /* exit the while */

            switch (c)
              {
                case 0:
                  /* printf(" Option 0 : with arg %s", optarg); */
                  break;
                case 'f':
                  /*printf(" case 'f'\n");
                  */
                  strcpy(srcfilename,optarg); 
                  /*printf("srcfile = %s \n",srcfilename);
                  */
                  got_file_name = 1;
                  break;
                  break;
                case 'c':
                  global_options.output_mode = OUTPUT_MODE_CUT; /* setting this avoids initing screen */
                  break;
                case 's':
                  global_options.output_mode = OUTPUT_MODE_WEB; /* setting this avoids initing screen */
                  break;
                case 'b':
                  global_options.output_mode = OUTPUT_MODE_BIG; /* setting this avoids initing screen */
                  break;
                case 'h':
                  printf("Animation Helper Help:\n");

                  printf(" --cmdline options--\n");
                  printf(" -f [input file name]\n");
                  printf(" -c (outputs individual all the individual .pngs)\n");
                  printf(" -s (outputs the best rotation, used for web page)\n");
                  printf(" -b (outputs the BIG animation)\n");
                  return 0;
                  break;
                default:
                  printf("Error: Unknown argument %c.\n",c);
              }
          } /* while */
      }

      if (got_file_name == 0)
        {
          printf("You must specifiy the src file name.\n");
          return 0;
        }

      /*printf("srcfile = %s \n",srcfilename); */

      for (c = 0; srcfilename[c] != '\0'; c++) destfilename[c] = srcfilename[c];
      destfilename[c] = 0;
      if ((c > 4) && (destfilename[c - 4] == '.')) destfilename[c - 4] = 0;

      /*printf("destfile = %s \n",destfilename); */

      /*******************************************
       * Don't init video if we are just cutting *
       *******************************************/
      if (global_options.output_mode != OUTPUT_MODE_DEFAULT)
        SDL_Init(0);  /* Init no video */
      else if (SDL_Init(SDL_INIT_VIDEO) < 0) /* we need some video */
        {
          printf("Unable to init SDL: %s\n", SDL_GetError());
          exit(1);
        }
      atexit(SDL_Quit);

      if ((bitmap = IMG_Load(srcfilename)) == NULL)
        {
          printf("Unable to load bitmap: %s\n", SDL_GetError());
          exit(1);
        }

      if (global_options.output_mode == OUTPUT_MODE_DEFAULT)
        PaletteFixup(bitmap);

      Parse_Image(bitmap, &images);

      if (global_options.output_mode == OUTPUT_MODE_DEFAULT)   /* if we are just cutting, dont init screen */
        {
          screen = SDL_SetVideoMode(
              (images.max_width + 5) * (9 + images.columns),
              (images.max_height + 5) * 3,
              SCREEN_DEPTH, 0); //SDL_HWSURFACE|SDL_DOUBLEBUF);

          cur_width  = (images.max_width + 5) * (9 + images.columns);
          cur_height = (images.max_height + 5) * 3;

          if (screen == NULL)
            {
              printf("Unable to set video mode!: %s\n", SDL_GetError());
              exit(1);
            }
          CopyPalette(screen, bitmap);

          sprintf((char *) &title, "Animation Helper:%2.3f - Filename:%s ", VERSION, srcfilename);

          SDL_WM_SetCaption(title, title);
        }

      SDL_FreeSurface(bitmap);

      if ((bitmap = (void *) IMG_Load(srcfilename)) == NULL)
        {
          printf("Unable to load bitmap: %s\n", SDL_GetError());
          exit(1);
        }

      if (global_options.output_mode == OUTPUT_MODE_DEFAULT) PaletteFixup(bitmap);

      Parse_Image(bitmap, &images);
      Parse_Image(bitmap, &images);  /* do it twice to autodetect large images */

      SDL_FreeSurface(bitmap);

      /* Preparing complete, now lets do something */
      if ((!done) && global_options.output_mode == OUTPUT_MODE_CUT)
        {
          CutPics(&images, destfilename);
          done = 1;
        }
      if ((!done) && global_options.output_mode == OUTPUT_MODE_WEB)
        {
          CutSingleRotation(&images,destfilename,1);  /* force cut of SOMETHING */
          done = 1;
        }
      if ((!done) && global_options.output_mode == OUTPUT_MODE_BIG)
        {
          make_big_animation(&images, destfilename);
          done = 1;
        }

      /* At this point, if we have specified a cmd line option to output something
       * then done=1 so it will not do the realtime animation stuff
       */
      while (done == 0)  /* loop for realtime animation */
        {
          SDL_Event event;

          while (SDL_PollEvent(&event))
            {
              switch (event.type)
                {
                  case SDL_QUIT:
                    done = 1;
                    break;
                  case SDL_KEYDOWN:
                    {
                      switch (event.key.keysym.sym)
                        {
                          case SDLK_ESCAPE:
                            done = 1;
                            break;
                          case SDLK_PRINT:
                            ss = 1;
                            break;
                          case SDLK_F1:
                            exp = 1;
                            break;
                          case SDLK_F2:
                            ss = 2;
                            break;
                          case SDLK_F3:
                            ss = 3;
                            break;
                          case SDLK_F4:
                            ss = 4;
                            break;
                        }
                    }
                    break;
                }
            }
            DrawIT(screen, &images);
            SDL_Delay(250);

            /* Lets react to the user pressing keys */
            if (ss == 1)
              {
                Slock(screen);
                IMG_SavePNG("screenshot.png", screen, 0);
                ss = 0;
              }
            if (ss == 2)
              {
                if (ss_temp == 0) /* Start of SS */
                  {
                    ss_temp = 1;
                    tmp_gif = GifCreate();
                    printf("tmp_gif created\n");
                  }

                  sprintf((char *) &ss_filename, "%s.gif", destfilename);
                  /* IMG_SavePNG(ss_filename,screen,0); */
                  Slock(screen);
                  SDL_SetColorKey(screen, SDL_SRCCOLORKEY, images.seperator_color);
                    {
                      int i;
                      for (i = 0; i < 256; ++i) screen->format->palette->colors[i].unused = 255;
                    }
                  screen->format->palette->colors[images.seperator_color].unused = 0;
                  printf(" Append:%d\n", GifAppendFrame(tmp_gif, screen, 0, 0, 25, GIF_Background));
                  Sulock(screen);
                  printf("num frames:%d\n", tmp_gif->anim->frames_count);
                  ss_temp ++;

                  if (ss_temp == 9) /* End of SS */
                    {
                      tmp_gif->anim->loop = 0; /* loop forever */
                      /*tmp_gif->anim->background_index=images.seperator_color; */
                      printf("Gif Save:%d\n:", GifSave(ss_filename, tmp_gif)); /* Save anim to file. TRUE = error */
                      GifUnload(tmp_gif);

                      ss_temp = 0;
                      ss = 0;
                    }
              }
            if (ss == 3) /* F3 */
              {
                { /* individual rows */
                  int col;
                  int row;
                  for (row = 0; row < images.rows; row++)
                    {
                      tmp_gif = GifCreate();

                      for (col = 0; col < images.columns; col++)
                        {
                          if (images.images[col][row] != NULL)
                             GifAppendFrame(tmp_gif, images.images[col][row],
                                        0, images.row_height[0] - images.images[col][row]->h,
                                        25, GIF_Background);
                        }
                      tmp_gif->anim->loop = 0; /* loop forever */
                      sprintf((char *) &ss_filename, "%s_%d.gif", destfilename, row);

                      GifSave(ss_filename, tmp_gif);
                      GifUnload(tmp_gif);
                    }
                }
                { /* individual columns (grouped in 8) */
                  int col;
                  int grp;
                  int num_images;
                  int row;
                  for (grp = 0; grp < 3; grp++)
                    {
                      for (col = 0; col < images.columns; col++)
                        {
                          tmp_gif = GifCreate();
                          num_images = 0;
                          for (row = 0; row < 8; row++)
                            {
                              if (images.images[col][row + (grp * 8)] != NULL)
                                {
                                  GifAppendFrame(tmp_gif, images.images[col][row + (grp * 8)],
                                      0, images.row_height[0] - images.images[col][row + (grp * 8)]->h,
                                      25, GIF_Background);
                                  num_images++;
                                }
                            }
                          tmp_gif->anim->loop = 0; /* loop forever */

                          sprintf((char *) &ss_filename, "%s_%d_%d.gif", destfilename, grp, col);

                          if (num_images > 1) GifSave(ss_filename, tmp_gif);
                          GifUnload(tmp_gif);
                       }
                    }
                }
                ss = 0;
              }
            if (ss == 4)
              {
                CutSingleRotation(&images, destfilename, 1);  /* Cut SOMETHING */
              }
            if (exp == 1) /* save pics */
              {
                CutPics(&images,destfilename);
                exp = 0;
              }

            loop++;
            if (loop > 3)
              {
                if ((bitmap = (void *) IMG_Load(srcfilename)) != NULL)
                  {
                    PaletteFixup(bitmap);

                    Parse_Image(bitmap, &images);
                    loop = 0;

                    if ((cur_width != (images.max_width + 5) * (9 + images.columns)) ||
                        (cur_height != (images.max_height + 5) * 3) )
                      {
                        screen = SDL_SetVideoMode(
                                                (images.max_width + 5) * (9 + images.columns),
                                                (images.max_height + 5) * 3,
                                                SCREEN_DEPTH, 0); //SDL_HWSURFACE|SDL_DOUBLEBUF);
                        cur_width = (images.max_width + 5) * (9 + images.columns);
                        cur_height = (images.max_height + 5) * 3;
                        CopyPalette(screen, bitmap);
                      }
                    SDL_FreeSurface(bitmap);
                  }
              }
            SDL_Flip(screen);
        }
    return 0;
  }
