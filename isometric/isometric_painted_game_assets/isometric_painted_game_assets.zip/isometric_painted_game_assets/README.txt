author: laetissima
license: Public Domain
origin: http://opengameart.org/content/isometric-painted-game-assets


Includes:
Buttons numbered 1-10
Buttons:  Restart, Levels, Main, Play, Next
Cartoon knight character with walking animation (4 directions) and concept
Isometric tile blocks:  floor, ice, candelabra, leaning pile of books, banner, brick wall
Misc. screens

All assets come in .png and .ora, and sometimes .xcf.