author: Clint Bellanger
license: CC-BY 3.0
origin: http://opengameart.org/content/isometric-hero-and-creatures

Here's a collection of isometric hero and creature graphics.

I basically abandoned this series because I switched from a tactics-style turned based RPG to an action RPG which requires much better animation.

Features (i.e. limitations)

Very low color count, and not anti-aliased.  This is basically to make recoloring very easy.
Very low number of frames.  Movement is a 4 frame cycle.  Attack, Special, Hit, Dead are all single frame.
8 direction
256x256 per frame.  I planned to use these at 128x128 but rendered them bigger.
Graphics included:

Elemental
Goblin
Magician (monster; not the same animations as the hero)
Hero in clothes
Hero in leather armor
Hero in metal armor
Ogre
Skeleton
Slime
Werewolf
Zombie
Also, overlays for the hero (works with all three hero graphics)

longsword
longbow
staff
shield
