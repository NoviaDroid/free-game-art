/////////////////////////////////////////////////////////////////////////
void define_world(LPplanet planet_creat)
{
	 planet_creat->planet_type    = TEMP;
	 planet_creat->land_type      = BROWN;
	 planet_creat->hydro_type     = WATER;
	 planet_creat->hydro_size     = random(30)+10;
	 planet_creat->section_type   = random(4)+1;
	 planet_creat->plant_size     = NONE;
	 planet_creat->plant_type     = NONE;
	 planet_creat->swamp_size     = NONE;


	 int total_value;
	 int dice;
	 int temp_hydro_size;


	 total_value = lava_world + ice_world + temp_world +
                   iles_world + jungle_world + moon_world +
				   gaseous_world + desert_world + water_world
				   + oasis_world + dune_world + rocky_world;

	 dice=random(total_value)+1;

	 //lava world
	 if ( dice < lava_world )
	 {
		 planet_creat->planet_type    = LAVA;
		 planet_creat->land_type      = DARK;
		 planet_creat->hydro_type     = LAVA;
		 planet_creat->hydro_size     = random(30)+10;
		 planet_creat->section_type   = random(4)+1;

		 debugfile ("lava world\n", 1 );
		 return;
	 }

     //ice world
	 else if ( dice < (lava_world + ice_world)  )
	 {
		 planet_creat->planet_type    = ICE;
		 planet_creat->land_type      = WHITE;
		 planet_creat->hydro_type     = ICE;
         planet_creat->hydro_size     = random(70)+20;
         planet_creat->section_type   = random(4)+3;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}

	     debugfile ("ice world\n", 1 );
		 return;
     }

     //temp word
	 else if ( dice < (lava_world + ice_world + temp_world)  )
     {
		 planet_creat->planet_type    = TEMP;
		 planet_creat->land_type      = PLAIN;
		 planet_creat->hydro_type     = WATER;
		 planet_creat->hydro_size     = random(70)+20;
		 planet_creat->section_type   = random(4)+3;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 10;
		 planet_creat->swamp_size     = 5;

		 debugfile ("temp world\n", 1 );
		 return;
     }

     //islands
	 else if ( dice < (lava_world + ice_world + temp_world + iles_world)  )
     {
		 planet_creat->planet_type    = ISLE;
		 planet_creat->land_type      = PLAIN;
		 planet_creat->hydro_type     = WATER;
		 planet_creat->hydro_size     = random(19)+80;
		 planet_creat->section_type   = random(6)+1;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 20;
		 planet_creat->swamp_size     = 2;

		 debugfile ("islands world\n", 1 );
		 return;
	 }

     //jungle world
	 else if ( dice < (lava_world + ice_world + temp_world
						+ iles_world + jungle_world)  )
	 {
		 planet_creat->planet_type    = JUNGLE;
		 planet_creat->land_type      = JUNGLE;
		 planet_creat->hydro_type     = WATER;
		 planet_creat->hydro_size     = random(70)+20;
		 planet_creat->section_type   = random(5)+2;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 40;
		 planet_creat->swamp_size     = 20;

		 debugfile ("jungle world\n", 1 );
		 return;
     }

     //moon world
	 else if ( dice < (lava_world + ice_world
								+ temp_world + iles_world + jungle_world
								+ moon_world)  )
     {
		 planet_creat->planet_type    = MOON;
		 planet_creat->land_type      = GREY;
         planet_creat->hydro_type     = NONE;
		 planet_creat->hydro_size     = 0;
         planet_creat->section_type   = random(5)+2;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}

	     debugfile ("moon\n", 1 );
		 return;
     }

	 //gaseous world
	 else if ( dice < (lava_world + ice_world + temp_world
								+ iles_world + jungle_world
								+ moon_world + gaseous_world)  )
	 {
		planet_creat->planet_type    = EXOTIC;
		planet_creat->land_type      = EXOTIC;
		planet_creat->hydro_type     = ACID;
		planet_creat->hydro_size     = random(30)+10;
		planet_creat->section_type   = random(4)+1;
		debugfile ("exotic world\n", 1 );
		  return;
     }
	 //desert world
	 else if ( dice < (lava_world + ice_world
						+ temp_world + iles_world + jungle_world
						+ moon_world + gaseous_world + desert_world)  )
     {
		 planet_creat->planet_type    = DESERT;
		 planet_creat->land_type      = BROWN;
		 planet_creat->hydro_type     = DESERT;
		 temp_hydro_size              = random(60)-20;
		 if ( temp_hydro_size     <= 0 ) {planet_creat->hydro_size = 0;}
		 else    {planet_creat->hydro_size = temp_hydro_size;}
		 planet_creat->section_type   = random(4)+4;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
	     debugfile ("desert world\n", 1 );
		 return;
     }
	 //oasis world
	 else if ( dice < (lava_world + ice_world
						+ temp_world + iles_world + jungle_world
						+ moon_world + gaseous_world + desert_world
						+ oasis_world)  )
     {
		 planet_creat->planet_type    = OASIS;
		 planet_creat->land_type      = BROWN;
		 planet_creat->hydro_type     = WATER;
		 planet_creat->hydro_size     = random(7)+5;
		 planet_creat->section_type   = random(4)+4;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 20;
		 debugfile ("oasis world\n", 1 );
		 return;
     }
	 //dune world
	 else if ( dice < (lava_world + ice_world
						+ temp_world + iles_world + jungle_world
						+ moon_world + gaseous_world + desert_world
						+ oasis_world + dune_world)  )
     {
		 planet_creat->planet_type    = DESERT;
		 planet_creat->land_type      = BROWN;
		 planet_creat->hydro_type     = DUNE;
		 planet_creat->hydro_size     = random(30)+60;
		 planet_creat->section_type   = random(4)+3;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
	     debugfile ("dune world\n", 1 );
		 return;
     }
     //rocky world
	 else if ( dice < (lava_world + ice_world
						+ temp_world + iles_world + jungle_world
						+ moon_world + gaseous_world + desert_world
						+ oasis_world + dune_world + rocky_world)  )
     {
		 planet_creat->planet_type    = DESERT;
		 planet_creat->land_type      = BROWN;
		 planet_creat->hydro_type     = NONE;
		 planet_creat->hydro_size     = 0;
		 planet_creat->section_type   = random(5)+2;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}

	     debugfile ("rocky world\n", 1 );
		 return;
     }
	 // swamp world
     else
     {
		 planet_creat->planet_type    = SWAMP;
		 planet_creat->land_type      = SWAMP;
		 planet_creat->hydro_type     = WATER;

		 planet_creat->hydro_size     = random(40)+50;
		 planet_creat->section_type   = random(5)+2;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 10;
		 planet_creat->swamp_size     = 40;

		 debugfile ("swamp world\n", 1 );
		 return;
     }

}

///////////////////////////////////////////////////////////////////////
void creat_world(int planet_number)
{
	debugfile ("****creating world****\n",planet_number );
	LPplanet planet_creat;
    LPhex    hex_creat;
    int dice;
    int section[100][100]; /// large to englobe planet size

    int nx, ny ,mx, my;
    int hex_x_now_doing, hex_y_now_doing;
    int odd_even;
    int slide_x;

    planet_creat = (LPplanet) malloc( sizeof(planet) );

	if ( planet_creat == NULL )
	debugfile ("ERROR...no memory for planet struct\n", 1 );


	// set defaults

	planet_creat->planet_type    = TEMP;
	planet_creat->land_type      = BROWN;

    planet_creat->hydro_type     = HYDRO;
    planet_creat->hydro_size     = random(100)+1;
    planet_creat->section_type   = random(6)+1;

	planet_creat->first_town	= (LPtown) NULL;
	planet_creat->palace		= (LPbuilding) NULL;
	planet_creat->forts			= (LPbuilding) NULL;
	planet_creat->churches		= (LPbuilding) NULL;
	planet_creat->mines			= (LPbuilding) NULL;
	planet_creat->wells			= (LPbuilding) NULL;
	planet_creat->farms			= (LPbuilding) NULL;
	planet_creat->starports		= (LPbuilding) NULL;
	planet_creat->labs			= (LPbuilding) NULL;
    planet_creat->ruins			= (LPbuilding) NULL;
	planet_creat->other_build	= (LPbuilding) NULL;


	if ( planet_creat->section_type == 5 )
	{planet_creat->section_type = 8;}
    planet_creat->number         = planet_number;


		debugfile ("= planet number\n", planet_number );



	generation_bar_move (planet_number, NumberStars);

	if ( planet_number == NumberStars-1 )
	{
		debugfile ("doing last planet\n", planet_number );

	}

	// do world
	if (star [planet_number].owner==HIGH_STEWARD)
	{
		 planet_creat->planet_type    = TEMP;
		 planet_creat->land_type      = PLAIN;
		 planet_creat->hydro_type     = WATER;
		 planet_creat->hydro_size     = 20;
		 planet_creat->section_type   = 6;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 10;
		 planet_creat->swamp_size     = 2;

	}
	else if (star [planet_number].owner==RED)
	{
		 planet_creat->planet_type    = ICE;
		 planet_creat->land_type      = WHITE;
		 planet_creat->hydro_type     = ICE;
		 planet_creat->hydro_size     = 40;
		 planet_creat->section_type   = 7;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 0;
		 planet_creat->swamp_size     = 0;

	}
	else if (star [planet_number].owner==GREEN)
	{
		 planet_creat->planet_type    = EXOTIC;
		 planet_creat->land_type      = EXOTIC;
		 planet_creat->hydro_type     = ACID;
		 planet_creat->hydro_size     = 10;
		 planet_creat->section_type   = 2;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 0;
		 planet_creat->swamp_size     = 0;

	}
	else if (star [planet_number].owner==ORANGE)
	{
		 int temp_hydro_size;
		 planet_creat->planet_type    = OASIS;
		 planet_creat->land_type      = BROWN;
		 planet_creat->hydro_type     = WATER;
		 planet_creat->hydro_size     = random(7)+5;
		 planet_creat->section_type   = random(4)+4;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 5;
		 planet_creat->swamp_size     = 0;
	}
	else if (star [planet_number].owner==YELLOW)
	{
		 planet_creat->planet_type    = TEMP;
		 planet_creat->land_type      = PLAIN;
		 planet_creat->hydro_type     = WATER;
		 planet_creat->hydro_size     = 60;
		 planet_creat->section_type   = 6;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 20;
		 planet_creat->swamp_size     = 5;

	}
	else if (star [planet_number].owner==GUILD)
	{
		 planet_creat->planet_type    = TEMP;
		 planet_creat->land_type      = PLAIN;
		 planet_creat->hydro_type     = WATER;
		 planet_creat->hydro_size     = 50;
		 planet_creat->section_type   = 6;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 10;
		 planet_creat->swamp_size     = 2;

	}
	else if (star [planet_number].owner==BLEU)
	{
		 planet_creat->planet_type    = ISLE;
		 planet_creat->land_type      = PLAIN;
		 planet_creat->hydro_type     = WATER;
		 planet_creat->hydro_size     = 80;
		 planet_creat->section_type   = random(6)+2;
		 if ( planet_creat->section_type == 5 )
		 {planet_creat->section_type = 8;}
		 planet_creat->plant_size     = 3;
		 planet_creat->swamp_size     = 10;

	}
	else define_world ( planet_creat );

	star [planet_number].planet_surface = planet_creat;


   int section_x_size=planet_creat->section_type;
   int section_y_size=planet_creat->section_type;
   //  hydrografix
   //first in sections
   for (nx=0; nx< (planet_size_x/section_x_size); nx++)
   {
	   for ( ny=0; ny< (planet_size_y/section_y_size); ny++)
	   {
		  dice=random(100)+1;
          if ( dice < planet_creat->hydro_size )
          {
              section[nx][ny]            = HYDRO;
          }
          else
          {
              section[nx][ny]            = PLAIN;
              dice=random(100)+1;
              if ( dice < 33 )
              {
                   section[nx][ny]            = MOUNT;
              }
              else if ( dice < 66 )
              {
                   section[nx][ny]            = HILL;
              }

          }

       }
   }

   if ( planet_number == 0 )
   debugfile ("done first planet sections\n", planet_number );

   // now do hexs by sections

   int section_x_now=0;
   int section_y_now=0;

   for ( ny=0; ny<planet_size_y; ny= ny + section_y_size )
   {



       for ( nx=0; nx<planet_size_x ; nx= nx + section_x_size  )
       {


                 for (my=0; my < section_y_size; my++)
                 {


                           for ( mx=0; mx < section_x_size; mx++ )
                           {
                                 hex_creat = (LPhex) malloc( sizeof(hex) );
								 if ( hex_creat == NULL )
								 debugfile ("no memory for a hex struct, x\n", nx );
								 if ( hex_creat == NULL )
								 debugfile ("no memory for a hex struct, y\n", ny );
								 if ( hex_creat == NULL )
								 debugfile ("no memory for a hex struct, planet num\n", planet_number );

								 hex_creat->type            = EMPTY;
								 hex_creat->sub_type        = random(10)+1;;
								 hex_creat->flag            = EMPTY;
								 hex_creat->blank1          = NOT_USED;
								 hex_creat->coast           = NONE;
								 hex_creat->resourse        = NONE;
								 hex_creat->build_in_hex    = (LPbuilding) NULL;
								 hex_creat->unit_in_hex     = (LPunit)NULL;
								 hex_creat->road   		    = EMPTY;
								 hex_creat->X_hex_location	= 0;
								 hex_creat->Y_hex_location	= 0;
								 hex_creat->planet          = planet_creat;

                                 if ( section[section_x_now][section_y_now]==HYDRO )
                                 {
                                        hex_creat->type            = HYDRO;
                                 }
                                 else
                                 {
                                        hex_creat->type            = PLAIN;
                                        if ( section[section_x_now][section_y_now]==HILL )
                                        {
											dice=random(100)+1;
                                            if ( dice < 33 )
                                            {
                                                   hex_creat->blank1   = HILL;
                                            }

                                        }
                                        if ( section[section_x_now][section_y_now]==MOUNT )
                                        {
                                            dice=random(100)+1;
                                            if ( dice < 33 )
                                            {
                                                   hex_creat->blank1   = MOUNT;
                                            }
                                            else if ( dice < 66 )
                                            {
                                                   hex_creat->blank1   = HILL;
                                            }

                                        }
                                 }

								 if ( nx+mx >= planet_size_x )
								 {
								 //debugfile ("error....nx+mx too big, x\n", nx+mx );
								 break;
								 }

								 if ( ny+my >= planet_size_y )
								 {
								 //debugfile ("error....ny+my too big, x\n", ny+my );
								 break;
								 }

                                 odd_even = (section_y_now+1) % 2;

                                 if ( (odd_even != 0) || (section_x_size==1) )
                                 {
									 planet_creat->planet_matrice[nx+mx][ny+my] = hex_creat;
									 hex_creat->X_hex_location	= nx+mx;
									 hex_creat->Y_hex_location	= ny+my;
                                     //if ( planet_number < 2 ) debugfile ("None slide, x\n", nx+mx );
                                     //if ( planet_number < 2 ) debugfile (" None slide, y\n", ny+my );
                                     //if ( planet_number < 2 ) debugfile (".......................\n", 0 );
                                 }
                                 else //   slide sections
                                 {
                                     slide_x = (section_x_size/2)+(nx+mx);

                                     if ( slide_x >= planet_size_x )
                                     {
                                         slide_x = slide_x-planet_size_x;

                                     }
                                     if ( slide_x >= planet_size_x ) debugfile ("error....slide_x too big, x\n", nx+mx );
                                     if ( ny+my >= planet_size_y ) debugfile ("error....ny+my too big, y\n", ny+my );

                                     //if ( planet_number < 2 ) debugfile ("slide from, x\n", nx+mx );
                                     //if ( planet_number < 2 ) debugfile ("slide, x\n", slide_x );

                                     //if ( planet_number < 2 ) debugfile ("slide, y\n", ny+my );
                                     //if ( planet_number < 2 ) debugfile (".......................\n", 0 );

									 planet_creat->planet_matrice[slide_x][ny+my] = hex_creat;
									 hex_creat->X_hex_location	= slide_x;
									 hex_creat->Y_hex_location	= ny+my;
                                 }

                           }

                 }
                 section_x_now++;
       }
       section_x_now=0;
       section_y_now++;
   }


   debugfile ("done planet hexs\n", planet_number );

   // now do coastline
   coastline( planet_creat );
   if ( section_x_size >= 4 ) coastline( planet_creat );
   if ( section_x_size >= 6 ) coastline( planet_creat );
   if ( section_x_size >= 8 )
   {
       coastline( planet_creat );
       coastline( planet_creat );
   }
   if ( section_x_size == 1 )
   {
       coastline( planet_creat );
       coastline( planet_creat );
       coastline( planet_creat );
       coastline( planet_creat );
       coastline( planet_creat );
   }
   if ( section_x_size == 2 )
   {
       coastline( planet_creat );
   }

   border_line( planet_creat, HYDRO, SHALOW, YES_IF_BORDER );
   border_line( planet_creat, HYDRO, DEEP, YES_IF_NO_BORDER );

   coast_draw_set ( planet_creat, SHALOW , HYDRO );

  debugfile ("done planet coastline\n", planet_number );

   //////place hills/////
   hills( planet_creat );
   debugfile ("done planet hills\n", planet_number );

	if ((planet_creat->planet_type) != OASIS)
	{
		/////place forrests//
	   if ( (planet_creat->plant_size) != NONE )
	   {
		   plants ( planet_creat ) ;
		   debugfile ("done planet forests\n", planet_number );
	   }
       //////place swamps//
       if ( (planet_creat->swamp_size) != NONE )
       {
    	   swamps ( planet_creat ) ;
		   debugfile ("done planet swamps\n", planet_number );
	   }
	}


   // if world is water, change land to water
   /*
   if (planet_creat->planet_type  == WATER)
   {
	   for (ny=0; ny< planet_size_y; ny++)
		  {
		   for (nx=0; nx< planet_size_x; nx++ )
		   {
				if (planet_creat->planet_matrice[nx][ny]->type  == PLAIN )
				{
					planet_creat->planet_matrice[nx][ny]->type  = SHALOW;
				}
				if (planet_creat->planet_matrice[nx][ny]->type  == HILL )
				{
					planet_creat->planet_matrice[nx][ny]->type  = SHALOW;
				}
				if (planet_creat->planet_matrice[nx][ny]->type  == MOUNT )
				{
					planet_creat->planet_matrice[nx][ny]->type  = SHALOW;
				}
		   }
		  }
   }
	*/
   get_hydro_percent( planet_creat );

   ////////// now find resources/////

   set_world_resources (planet_creat);

   /////////////rivers///////////////

   debugfile ("hydro percent \n", planet_creat->hydro_size );
   if (planet_creat->hydro_type != DUNE) //no rivers for dune type worlds
   {
		if ( (planet_creat->hydro_size > 5)  && (planet_creat->hydro_size < 95) )
			{rivers( planet_creat ); out_num_rivers++; }
   }
   ///////// oasis type land///////////
      if ( (planet_creat->planet_type) == OASIS )
   {
	  // for (int ois = 0; ois <= (planet_creat->hydro_size)*5; ois++)
	   //{
			   planet_scan_oasis_place ( planet_creat );
	   //}
	   place_terain( planet_creat, PLAIN, NONE, SWAMP, SWAMP, hills_adjust, GROW_BY_INCREES );
	   place_terain( planet_creat, PLAIN, NONE, SWAMP, SWAMP, hills_adjust, GROW_BY_INCREES );
	   place_terain( planet_creat, PLAIN, NONE, SWAMP, SWAMP, hills_adjust, GROW_BY_INCREES );
	   place_terain( planet_creat, PLAIN, NONE, SWAMP, SWAMP, hills_adjust, GROW_BY_INCREES );
	   place_terain( planet_creat, PLAIN, NONE, SWAMP, SWAMP, hills_adjust, GROW_BY_INCREES );

	   coast_draw_set ( planet_creat, SWAMP , SHALOW );


	   /////place desert forrests//
	   if ( (planet_creat->plant_size) != NONE )
	   {
		   plants_oasis ( planet_creat ) ;
	   }

   }
   /////////////////////////////////////
   //////////////////////////////////////
   //if ( planet_number == NumberStars-1 )
   debugfile ("finished planet \n", planet_number );
   //if ( planet_number == NumberStars-1 )
   debugfile ("number of good rivers \n", out_num_rivers_ok );
   //if ( planet_number == NumberStars-1 )
   debugfile ("number of 'bad' rivers \n", out_num_rivers_ko );
   //if ( planet_number == NumberStars-1 )
   debugfile ("number planets checking rivers \n", out_num_rivers );
   //if ( planet_number == NumberStars-1 )
   debugfile ("number mountains checking rivers \n", out_mount_rivers );
   //if ( planet_number == NumberStars-1 )
   debugfile ("number no value rivers \n", rivers_no_path_value );
   //if ( planet_number == NumberStars-1 )
   debugfile ("number times seeking rivers \n", rivers_seeking );

   /////////now find structures////////////////
   int number_of_towns=0;
   int size_of_towns=0;

   int number_of_factory=0;
   int number_of_elec=0;
   int number_of_steel=0;
   int number_of_chemy=0;
   int number_of_farms=0;
   int number_of_enc_farms=0;
   int number_of_mines=0;
   int number_of_ruins=0;
   int number_of_forts=0;
   int number_of_starports=0;
   int number_of_barracks=0;
   int number_of_labs=0;
   int number_of_unis=0;

   int church=false;
   int palace=false;;

if (star [planet_number].owner==YELLOW)
{
			debugfile ("planet owned yellow\n", 1 );

			number_of_towns=10;
			size_of_towns=random(12)+24;
			number_of_factory=random(6)+6;
			number_of_elec=random(3);
			number_of_steel=random(3);
			number_of_chemy=random(3);
			number_of_farms=random(16)+10;
			number_of_mines=random(6)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=2;
			number_of_barracks=1;
			number_of_labs=random(3);
			number_of_unis=random(2);
			number_of_enc_farms=0;
			church=true;
			palace=true;
}
else if (star [planet_number].owner==ORANGE)
{
			debugfile ("planet owned orange\n", 2 );

			number_of_towns=8;
			size_of_towns=random(12)+24;
			number_of_factory=random(6)+6;
			number_of_elec=random(3);
			number_of_steel=random(3);
			number_of_chemy=random(3);
			number_of_farms=random(8)+10;
			number_of_mines=random(6)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=2;
			number_of_barracks=1;
			number_of_labs=random(3);
			number_of_unis=random(2);
			number_of_enc_farms=0;
			church=true;
			palace=true;
}
else if (star [planet_number].owner==RED)
{
			debugfile ("planet owned red\n", 1 );

			number_of_towns=5;
			size_of_towns=random(12)+15;
			number_of_factory=random(6)+10;
			number_of_elec=random(3);
			number_of_steel=random(3);
			number_of_chemy=random(3);
			number_of_farms=0;
			number_of_mines=random(6)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=2;
			number_of_barracks=1;
			number_of_labs=random(3);
			number_of_unis=random(2);
			number_of_enc_farms=12;
			church=true;
			palace=true;
}
else if (star [planet_number].owner==BLEU)
{
			debugfile ("planet owned bleu\n", 1 );

			number_of_towns=5;
			size_of_towns=random(12)+24;
			number_of_factory=random(6)+6;
			number_of_elec=random(3);
			number_of_steel=random(3);
			number_of_chemy=random(3);
			number_of_farms=random(16)+10;
			number_of_mines=random(6)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=2;
			number_of_barracks=1;
			number_of_labs=random(3);
			number_of_unis=random(2);
			number_of_enc_farms=0;
			church=true;
			palace=true;
}
else
{
   if (planet_creat->planet_type==TEMP)
   {
	   dice=random(100)+1;
	   if (dice<10)
	   {
			debugfile ("planet unihabited\n", 0 );

			//empty
			number_of_towns=0;
			size_of_towns=0;
			number_of_factory=0;
			number_of_elec=0;
			number_of_steel=0;
			number_of_chemy=0;
			number_of_farms=0;
			number_of_mines=0;
			number_of_ruins=random(12)+1;
			number_of_forts=0;
			number_of_starports=0;
			number_of_barracks=0;
			number_of_labs=0;
			number_of_unis=0;
			number_of_enc_farms=0;
			church=false;
			palace=false;
	   }
	   else if (dice<40)
	   {
			debugfile ("colony planet\n", dice );

			//colony
			number_of_towns=random(6)+1;
			size_of_towns=random(12);
			number_of_factory=random(2);
			number_of_elec=random(1);
			number_of_steel=random(1);
			number_of_chemy=random(1);
			number_of_farms=random(6)+1;
			number_of_mines=random(6)+1;
			number_of_ruins=random(6)+1;
			number_of_starports=random(2);
			number_of_labs=0;
			number_of_unis=0;
			number_of_enc_farms=0;
			church=true;
			palace=false;
	   }
	   else if (dice<80)
	   {
		  debugfile ("populated planet\n", dice );

		  //populated
			number_of_towns=random(5)+2;
			size_of_towns=random(12)+24;
			number_of_factory=random(6)+random(6);
			number_of_elec=random(3)+random(3);
			number_of_steel=random(3)+random(3);
			number_of_chemy=random(3)+random(3);
			number_of_farms=random(16)+10;
			number_of_mines=random(6)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=1;
			number_of_barracks=1;
			number_of_labs=random(3);
			number_of_unis=random(2);
			number_of_enc_farms=0;
			church=true;
			palace=true;
	   }
	   else
	   {
		  debugfile ("very populated planet\n", dice );

		  //populated empire world
			number_of_towns=random(3)+4;
			size_of_towns=random(36)+random(36)+36;
			number_of_factory=random(12)+12;
			number_of_elec=random(6)+random(6);
			number_of_steel=random(6)+random(6);
			number_of_chemy=random(6)+random(6);
			number_of_farms=random(16)+20;
			number_of_mines=random(16)+6;
			number_of_ruins=0;
			number_of_forts=1;
			number_of_starports=1;
			number_of_barracks=1;
			number_of_labs=random(7);
			number_of_unis=1;
			number_of_enc_farms=0;
			church=true;
			palace=true;
	   }
	   if (star [planet_number].owner==HIGH_STEWARD)
		{
			debugfile ("capi populated planet\n", dice );

			//capital
			number_of_towns=random(40)+100;
			size_of_towns=random(36)+random(36)+800;
			number_of_factory=random(24)+120;
			number_of_elec=random(16)+random(16);
			number_of_steel=random(16)+random(16);
			number_of_chemy=random(16)+random(16);
			number_of_farms=random(16)+40;
			number_of_mines=random(16)+46;
			number_of_ruins=0;
			number_of_forts=5;
			number_of_starports=6;
			number_of_barracks=1;
			number_of_labs=random(10)+1;
			number_of_unis=3;
			number_of_enc_farms=random(5);
			church=true;
			palace=true;
        }
   }
   if (planet_creat->planet_type==JUNGLE)
   {
	   dice=random(100)+1;
	   if (dice<20)
	   {
			debugfile ("planet unihabited\n", 0 );
			//empty
			number_of_towns=0;
			size_of_towns=0;
			number_of_factory=0;
			number_of_elec=0;
			number_of_steel=0;
			number_of_chemy=0;
			number_of_farms=0;
			number_of_mines=0;
			number_of_ruins=random(12)+1;
			number_of_labs=0;
			number_of_unis=0;
			number_of_enc_farms=0;
			church=false;
			palace=false;
	   }
	   else if (dice<50)
	   {
			debugfile ("colony planet\n", dice );

			//colony
			number_of_towns=random(5)+2;
			size_of_towns=random(12);
			number_of_factory=random(2);
			number_of_elec=random(1);
			number_of_steel=random(1);
			number_of_chemy=random(1);
			number_of_farms=random(6)+1;
			number_of_mines=random(6)+1;
			number_of_ruins=random(6)+1;
			number_of_starports=random(2);
			church=true;
			palace=false;
	   }
	   else if (dice<90)
	   {
		  debugfile ("populated planet\n", dice );

		  //populated
			number_of_towns=random(4)+3;
			size_of_towns=random(12)+24;
			number_of_factory=random(6)+random(6);
			number_of_elec=random(3)+random(3);
			number_of_steel=random(3)+random(3);
			number_of_chemy=random(3)+random(3);
			number_of_farms=random(6)+6;
			number_of_mines=random(16)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=1;
			number_of_barracks=1;
			number_of_labs=random(3);
			number_of_unis=random(2);
			number_of_enc_farms=0;
			church=true;
			palace=true;
	   }
	   else
	   {
		  debugfile (" v populated planet\n", dice );

		  //populated empire world
			number_of_towns=random(3)+4;
			size_of_towns=random(36)+random(36)+36;
			number_of_factory=random(12)+random(12);
			number_of_elec=random(6)+random(6);
			number_of_steel=random(6)+random(6);
			number_of_chemy=random(6)+random(6);
			number_of_farms=random(16)+16;
			number_of_mines=random(16)+6;
			number_of_ruins=0;
			number_of_forts=1;
			number_of_starports=1;
			number_of_barracks=1;
			number_of_labs=random(7);
			number_of_unis=1;
			number_of_enc_farms=0;
			church=true;
			palace=true;
	   }
   }
   if (planet_creat->planet_type==ICE)
   {
	   dice=random(100)+1;
	   if (dice<40)
	   {

			debugfile ("planet unihabited\n", 0 );
			//empty
			number_of_towns=0;
			size_of_towns=0;
			number_of_factory=0;
			number_of_elec=0;
			number_of_steel=0;
			number_of_chemy=0;
			number_of_farms=0;
			number_of_mines=0;
			number_of_ruins=random(12)+1;
			number_of_labs=0;
			number_of_unis=0;
			number_of_enc_farms=0;
			church=false;
			palace=false;
	   }
	   else if (dice<90)
	   {
			debugfile ("colony planet\n", dice );

			//colony
			number_of_towns=random(6)+1;
			size_of_towns=random(12);
			number_of_factory=random(2);
			number_of_elec=random(1);
			number_of_steel=random(1);
			number_of_chemy=random(1);
			//number_of_farms=random(6)+1;
			number_of_mines=random(6)+1;
			number_of_ruins=random(6)+1;
			number_of_starports=random(2);
			number_of_labs=random(2);
			number_of_unis=0;
			number_of_enc_farms=random(3);
			church=true;
			palace=false;
	   }
	   else
	   {
		  debugfile ("populated planet\n", dice );

		  //populated
			number_of_towns=random(5)+2;
			size_of_towns=random(12)+24;
			number_of_factory=random(6)+random(6);
			number_of_elec=random(3)+random(3);
			number_of_steel=random(3)+random(3);
			number_of_chemy=random(3)+random(3);
			//number_of_farms=random(6)+6;
			number_of_mines=random(6)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=1;
			number_of_barracks=1;
			number_of_labs=random(4);
			number_of_unis=random(2);
			number_of_enc_farms=random(12);
			church=true;
			palace=true;
	   }

   }
   if (planet_creat->planet_type==DESERT)
   {
	   dice=random(100)+1;
	   if (dice<40)
	   {
			debugfile ("planet unihabited\n", 0 );

			//empty
			number_of_towns=0;
			size_of_towns=0;
			number_of_factory=0;
			number_of_elec=0;
			number_of_steel=0;
			number_of_chemy=0;
			number_of_farms=0;
			number_of_mines=0;
			number_of_ruins=random(12)+1;
			church=false;
			palace=false;
	   }
	   else if (dice<90)
	   {
			debugfile ("colony planet\n", dice );

			//colony
			number_of_towns=random(6)+1;
			size_of_towns=random(12);
			number_of_factory=random(2);
			number_of_elec=random(1);
			number_of_steel=random(1);
			number_of_chemy=random(1);
			number_of_farms=0;
			number_of_mines=random(6)+1;
			number_of_ruins=random(6)+1;
			number_of_starports=random(2);
			number_of_labs=random(2);
			number_of_unis=0;
			number_of_enc_farms=random(4);
			church=true;
			palace=false;
	   }
	   else
	   {
		  debugfile ("populated planet\n", dice );

		  //populated
			number_of_towns=random(6)+1;
			size_of_towns=random(12)+24;
			number_of_factory=random(6)+random(6);
			number_of_elec=random(3)+random(3);
			number_of_steel=random(3)+random(3);
			number_of_chemy=random(3)+random(3);
			number_of_farms=0;
			number_of_mines=random(6)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=1;
			number_of_barracks=1;
			number_of_labs=random(6);
			number_of_unis=random(2);
			number_of_enc_farms=random(12);
			church=true;
			palace=true;
	   }

   }
   if (planet_creat->planet_type==OASIS)
   {
	   dice=random(100)+1;
	   if (dice<30)
	   {

			debugfile ("planet unihabited\n", 0 );
			//empty
			number_of_towns=0;
			size_of_towns=0;
			number_of_factory=0;
			number_of_elec=0;
			number_of_steel=0;
			number_of_chemy=0;
			number_of_farms=0;
			number_of_mines=0;
			number_of_ruins=random(12)+1;
			church=false;
			palace=false;
	   }
	   else if (dice<50)
	   {
			debugfile ("colony planet\n", dice );

			//colony
			number_of_towns=random(6)+1;
			size_of_towns=random(12);
			number_of_factory=random(2);
			number_of_elec=random(1);
			number_of_steel=random(1);
			number_of_chemy=random(1);
			number_of_farms=random(6)+1;
			number_of_mines=random(6)+1;
			number_of_ruins=random(6)+1;
			number_of_starports=random(2);
			number_of_labs=random(2);
			number_of_unis=0;
			number_of_enc_farms=0;
			church=true;
			palace=false;
	   }
	   else
	   {
		  debugfile ("populated planet\n", dice );

		  //populated
			number_of_towns=random(6)+1;
			size_of_towns=random(12)+24;
			number_of_factory=random(6)+random(6);
			number_of_elec=random(3)+random(3);
			number_of_steel=random(3)+random(3);
			number_of_chemy=random(3)+random(3);
			number_of_farms=random(6)+6;
			number_of_mines=random(6)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=1;
			number_of_barracks=1;
			number_of_labs=random(6);
			number_of_unis=random(2);
			number_of_enc_farms=0;
			church=true;
			palace=true;
	   }

   }
   if (planet_creat->planet_type==ISLE)
   {
	   dice=random(100)+1;
	   if (dice<30)
	   {
			debugfile ("planet unihabited\n", 0 );

			//empty
			number_of_towns=0;
			size_of_towns=0;
			number_of_factory=0;
			number_of_elec=0;
			number_of_steel=0;
			number_of_chemy=0;
			number_of_farms=0;
			number_of_mines=0;
			number_of_ruins=random(12)+1;
			church=false;
			palace=false;
	   }
	   else if (dice<80)
	   {
			debugfile ("colony planet\n", dice );

			//colony
			number_of_towns=random(5)+2;
			size_of_towns=random(12);
			number_of_factory=random(2);
			number_of_elec=random(1);
			number_of_steel=random(1);
			number_of_chemy=random(1);
			number_of_farms=random(6);
			number_of_mines=random(6)+1;
			number_of_ruins=random(6)+1;
			number_of_starports=random(2);
			number_of_labs=random(3);
			number_of_unis=0;
			number_of_enc_farms=0;
			church=true;
			palace=false;
	   }
	   else
	   {
		  debugfile ("populated planet\n", dice );

		  //populated
			number_of_towns=random(4)+3;
			size_of_towns=random(12)+24;
			number_of_factory=random(6)+random(6);
			number_of_elec=random(3)+random(3);
			number_of_steel=random(3)+random(3);
			number_of_chemy=random(3)+random(3);
			number_of_farms=random(12);
			number_of_mines=random(6)+6;
			number_of_ruins=random(3);
			number_of_forts=1;
			number_of_starports=1;
			number_of_barracks=1;
			number_of_labs=random(6);
			number_of_unis=1;
			number_of_enc_farms=0;
			church=true;
			palace=true;
	   }

   }
}
	   //mine place////////
	   if (number_of_mines>0)
	   {
			for (int i = 1; i <= number_of_mines ; i++)
			{
				if  (  planet_scan_mine_place ( planet_creat ) == false )
				{debugfile ("no mines \n", planet_number );}
			}
	   }

	   //town place////////
	   if (number_of_towns>0)
	   {
			for (int i = 1; i <= number_of_towns ; i++)
			{
				if  (  planet_scan_town_place ( planet_creat, TOWN, i ) == false )
				{debugfile ("no town \n", planet_number );}
			}
	   }
		//////palace/////
	   if (palace==true)
	   {
			if  (  planet_scan_town_grow ( planet_creat, PALACE ) == false )
			{debugfile ("no palace \n", planet_number );}
	   }
	   ///church//////
	   if (church==true)
	   {
			if  (  planet_scan_town_grow ( planet_creat, CHURCH ) == false )
			{debugfile ("no church \n", planet_number );}
	   }
	   ///starport//////
	   if (number_of_starports>0)
	   {
			for (int i = 0; i < number_of_starports ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, STARPORT ) == false )
				{debugfile ("no starport \n", planet_number );}
			}
	   }
	   ///university//////
	   if (number_of_unis>0)
	   {
			for (int i = 0; i < number_of_unis ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, UNI ) == false )
				{debugfile ("no university \n", planet_number );}
			}
	   }
	   ///town grow///////
	   if (size_of_towns>0)
	   {
			for (int i = 0; i <= size_of_towns ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, TOWN ) == false )
					{debugfile ("no town grow \n", planet_number );}
			}
	   }
	   ///lab//////
	   if (number_of_labs>0)
	   {
			for (int i = 0; i < number_of_labs ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, LAB ) == false )
				{debugfile ("no lab \n", planet_number );}
			}
	   }
	   ///barracks///////
	   if (number_of_barracks>0)
	   {
			for (int i = 0; i < number_of_barracks ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, BARRACKS ) == false )
					{debugfile ("no barracks \n", planet_number );}
			}
	   }
	   ///factory, elec, steel, chemy////////
	   if (number_of_factory>0)
	   {
			for (int i = 0; i <= number_of_factory ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, FACTORY ) == false )
					{debugfile ("no factory \n", planet_number );}
			}
		}
		if (number_of_elec>0)
	   {
			for (int i = 0; i <= number_of_elec ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, ELEC ) == false )
					{debugfile ("no elec \n", planet_number );}
			}
		}
		if (number_of_steel>0)
	   {
			for (int i = 0; i <= number_of_steel ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, STEEL ) == false )
					{debugfile ("no steel \n", planet_number );}
			}
		}
		if (number_of_chemy>0)
	   {
			for (int i = 0; i <= number_of_chemy ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, CHEMY ) == false )
					{debugfile ("no chemy \n", planet_number );}
			}
		}
		///enclosed farm///////
	   if (number_of_enc_farms>0)
	   {
			for (int i = 0; i < number_of_enc_farms ; i++)
			{
				if  (  planet_scan_town_grow ( planet_creat, ENCLOSED_FARM ) == false )
					{debugfile ("no ENCLOSED_FARM \n", planet_number );}
			}
	   }

	  /////////farms
		if (number_of_farms>0)
	   {
			for (int i = 0; i <= number_of_farms ; i++)
			{
				if  (  planet_scan_town_place ( planet_creat, FARM, NONE ) == false )
				{debugfile ("no farm \n", planet_number );}
			}
	   }
	   /////fort/////
	   if (number_of_forts>0)
	   {
			for (int i = 0; i < number_of_forts ; i++)
			{
				if  (  planet_scan_town_place ( planet_creat, FORT, NONE ) == false )
				{debugfile ("no fort \n", planet_number );}
			}
	   }
	    /////ruins/////
	   if (number_of_ruins>0)
	   {
			for (int i = 0; i < number_of_ruins ; i++)
			{
				if  (  planet_scan_town_place ( planet_creat, RUINS, NONE ) == false )
				{debugfile ("no fort \n", planet_number );}
			}
	   }

	////////road place///////// find_planet_roads ( LPplanet planet )
	find_planet_roads (  planet_creat );

	///set aligences//////////
	if ( star [planet_number].owner==YELLOW  ||
		 star [planet_number].owner==ORANGE  ||
	     star [planet_number].owner==BLEU    ||
		 star [planet_number].owner==RED         )
	{
		///find palace town///////////////

		LPtown palace_town=(LPtown)NULL;

		///find palace number
		int capitals_number=planet_creat->palace->town_number;
		planet_creat->palace->aligence=star [planet_number].owner;

		///go through towns to find number
		for ( LPtown town_temp=planet_creat->first_town; town_temp != (LPtown)NULL; town_temp=town_temp->next )
		{
			   if (town_temp->town_number==capitals_number)
			   {
					palace_town=town_temp;
					break;
			   }
		}
		if (palace_town==(LPtown)NULL)
		{
				debugfile ("no palace for yellow \n", planet_number );
		}

		for ( LPbuilding town_struct=palace_town->housing; town_struct != (LPbuilding)NULL; town_struct=town_struct->next )
		{
			town_struct->aligence=star [planet_number].owner;
		}

		//find second town
		int greatest_popu=0;
		int num_popy=0;
		LPtown town_now;
		LPtown town_with_great_popu=(LPtown)NULL;
        ///go through towns to find number
		for ( town_now=planet_creat->first_town; town_now != (LPtown)NULL; town_now=town_now->next )
		{
			for ( LPbuilding town_struct=town_now->housing; town_struct != (LPbuilding)NULL; town_struct=town_struct->next )
			{
				num_popy++;

			}
			if (num_popy>greatest_popu)
			{
			   greatest_popu= num_popy;
			   town_with_great_popu= town_now;
			}
			num_popy=0;
		}
		if (capitals_number!=town_with_great_popu->town_number)
		{
			for ( LPbuilding town_struct=town_with_great_popu->housing; town_struct != (LPbuilding)NULL; town_struct=town_struct->next )
			{
				town_struct->aligence=star [planet_number].owner;
			}
		}
		else
		{
			for ( town_now=planet_creat->first_town; town_now != (LPtown)NULL; town_now=town_now->next )
			{
				if (capitals_number!=town_now->town_number)
				{
					for ( LPbuilding town_struct=town_now->housing; town_struct != (LPbuilding)NULL; town_struct=town_struct->next )
					{
						town_struct->aligence=star [planet_number].owner;
					}
					break;
				}
			}
		}

		///if number of total buiding is to small, add another town
    }

	///////workers creat///////////
	set_workers ( planet_creat );
	///////units creat////////////
	Unit_start( planet_creat ) ;

}

/////////////////////////////////////////////////////////////////////////////
void RemovePlanet(
				LPplanet planet     // the planet to be removed
                )
{

    int nx, ny;

    if ( planet != (LPplanet) NULL )
    {
        //first delet town node
		if ( planet->first_town != (LPtown) NULL )
		{
			DeleteAllTownNodes ( planet );
		}
        // then delete structures  hex by hex
		for ( nx=0; nx<planet_size_y; nx++)
        {
            for ( ny=0; ny<planet_size_y; ny++)
		   {

				if ( planet->planet_matrice[nx][ny] != (LPhex) NULL )
				{
							 if (planet->planet_matrice[nx][ny]->build_in_hex != (LPbuilding) NULL)
							 {
								//only delete labour in towns, as this is where the linked list is
								if ( (planet->planet_matrice[nx][ny]->build_in_hex->worker != (LPLABOUR) NULL)
										&& (planet->planet_matrice[nx][ny]->build_in_hex->type == TOWN )  )
								{
									LPLABOUR next_labour;
									for ( LPLABOUR thelabour=planet->planet_matrice[nx][ny]->build_in_hex->worker; thelabour != (LPLABOUR)NULL; thelabour=next_labour )
									{
										next_labour = thelabour->next;
										free( thelabour );
										free_nodes++;
									}
								}
								free( planet->planet_matrice[nx][ny]->build_in_hex );
								planet->planet_matrice[nx][ny]->build_in_hex = (LPbuilding) NULL;
							 }

							 free( planet->planet_matrice[nx][ny] );
							 planet->planet_matrice[nx][ny] = (LPhex) NULL;
                             /// free planet units and buildings here///
                }
            }
        }

        free( planet );
    }
}

//////////////////////////////////////////////////////////////////////////////////////
void Remove_all_Planets
(
    void
)
{
     debugfile ("removing planets from memory\n", 1 );
	 for ( int n=0; n<NumberStars ;n++)
   {
       RemovePlanet( star [n].planet_surface );
   }
}

////////////////////////////////////////////////////////////////////////////////////
void DrawWorld(int planet_number)
{
   unsigned char tile_type;
   unsigned char river_type;
   int odd_even;
   int nx, ny; int x=513; int y=313;
   RECT rcRectTile;

   rcRectTile.top=36; rcRectTile. bottom=42;
   rcRectTile.left=0; rcRectTile.right=5;     // ++8 right left

   if (star [planet_number].planet_surface->land_type==PLAIN)
   {
		rcRectTile.top=36; rcRectTile. bottom=42;
   }

   if (star [planet_number].planet_surface->land_type==BROWN)
   {
		rcRectTile.top=6; rcRectTile. bottom=12;
   }

   if (star [planet_number].planet_surface->land_type==DARK)
   {
		rcRectTile.top=12; rcRectTile. bottom=18;
   }

   if (star [planet_number].planet_surface->land_type==WHITE)
   {
		rcRectTile.top=18; rcRectTile. bottom=24;
   }

   if (star [planet_number].planet_surface->land_type==GREY)
   {
		rcRectTile.top=24; rcRectTile. bottom=30;
   }

   if (star [planet_number].planet_surface->land_type==JUNGLE)
   {
		rcRectTile.top=30; rcRectTile. bottom=36;
   }

   if (star [planet_number].planet_surface->land_type==EXOTIC)
   {
		rcRectTile.top=42; rcRectTile. bottom=48;
   }

	  if (star [planet_number].planet_surface->land_type==WATER)
   {
		rcRectTile.top=48; rcRectTile. bottom=54;
   }

   // black out smalle map
   ZeroMemory( &ddbltfx, sizeof( ddbltfx ) );
   ddbltfx.dwSize = sizeof( ddbltfx );
   ddbltfx.dwFillColor = dwBackground;
   lpDDSOffScreen->Blt( &rcRectSection2, NULL,
   										NULL,
   										DDBLT_COLORFILL |
                                 DDBLT_WAIT, &ddbltfx );

   for ( nx=0; nx<planet_size_x ;nx++)
   {
       for ( ny=0; ny<planet_size_y ;ny++)
       {
			  tile_type = star [planet_number].planet_surface->planet_matrice[nx][ny]->type;
			  //if ( nx==0 && ny==0 ) {tile_type =HILL;} //marker to see first block
              odd_even = (ny+1) % 2;
              if ( odd_even !=0 ) { odd_even = 3; }
              rcRectTile.left=0+(tile_type)*5;
              rcRectTile.right=5+(tile_type)*5;

              lpDDSOffScreen->BltFast( (nx*5)+x+odd_even,   // basic system for now
             									(ny*5)+y,
									   lpDDSOffMap_color,
                                       &rcRectTile,
                                       DDBLTFAST_WAIT |
                                       DDBLTFAST_SRCCOLORKEY );

              // now rivers
			  river_type = star [planet_number].planet_surface->planet_matrice[nx][ny]->flag;
              if ( river_type != NONE )
              {
                  tile_type=RIVER_MARKER;
                  rcRectTile.left=0+(tile_type)*5;
                  rcRectTile.right=5+(tile_type)*5;
                  lpDDSOffScreen->BltFast( (nx*5)+x+odd_even,   // basic system for now
             									(ny*5)+y,
									   lpDDSOffMap_color,
									   &rcRectTile,
                                       DDBLTFAST_WAIT |
                                       DDBLTFAST_SRCCOLORKEY );

              }
              ///east
			  if ( (river_type & FLAG_EAST)!= NONE )
			  {
				  tile_type=RIVER_MARKER_E;
				  rcRectTile.left=0+(tile_type)*5;
				  rcRectTile.right=5+(tile_type)*5;
                  lpDDSOffScreen->BltFast( (nx*5)+x+odd_even,   // basic system for now
             									(ny*5)+y,
									   lpDDSOffMap_color,
									   &rcRectTile,
									   DDBLTFAST_WAIT |
									   DDBLTFAST_SRCCOLORKEY );

			  }

			  ///west
			  if ( (river_type & FLAG_WEST)!= NONE )
			  {
				  tile_type=RIVER_MARKER_W;
				  rcRectTile.left=0+(tile_type)*5;
				  rcRectTile.right=5+(tile_type)*5;
                  lpDDSOffScreen->BltFast( (nx*5)+x+odd_even,   // basic system for now
             									(ny*5)+y,
									   lpDDSOffMap_color,
                                       &rcRectTile,
                                       DDBLTFAST_WAIT |
                                       DDBLTFAST_SRCCOLORKEY );

              }
              ///North east
			  if ( (river_type & FLAG_NORTH_EAST)!= NONE )
              {
                  tile_type=RIVER_MARKER_NE;
                  rcRectTile.left=0+(tile_type)*5;
                  rcRectTile.right=5+(tile_type)*5;
                  lpDDSOffScreen->BltFast( (nx*5)+x+odd_even,   // basic system for now
             									(ny*5)+y,
									   lpDDSOffMap_color,
                                       &rcRectTile,
                                       DDBLTFAST_WAIT |
                                       DDBLTFAST_SRCCOLORKEY );

              }
              ///North west
			  if ( (river_type & FLAG_NORTH_WEST)!= NONE )
              {
                  tile_type=RIVER_MARKER_NW;
                  rcRectTile.left=0+(tile_type)*5;
                  rcRectTile.right=5+(tile_type)*5;
                  lpDDSOffScreen->BltFast( (nx*5)+x+odd_even,   // basic system for now
             									(ny*5)+y,
									   lpDDSOffMap_color,
                                       &rcRectTile,
                                       DDBLTFAST_WAIT |
                                       DDBLTFAST_SRCCOLORKEY );

              }
              ///south east
			  if ( (river_type & FLAG_SOUTH_EAST)!= NONE )
              {
                  tile_type=RIVER_MARKER_SE;
                  rcRectTile.left=0+(tile_type)*5;
                  rcRectTile.right=5+(tile_type)*5;
                  lpDDSOffScreen->BltFast( (nx*5)+x+odd_even,   // basic system for now
             									(ny*5)+y,
									   lpDDSOffMap_color,
                                       &rcRectTile,
                                       DDBLTFAST_WAIT |
                                       DDBLTFAST_SRCCOLORKEY );

              }
              ///south west
              if ( (river_type & FLAG_SOUTH_WEST)!= NONE )
              {
                  tile_type=RIVER_MARKER_SW;
                  rcRectTile.left=0+(tile_type)*5;
                  rcRectTile.right=5+(tile_type)*5;
                  lpDDSOffScreen->BltFast( (nx*5)+x+odd_even,   // basic system for now
             									(ny*5)+y,
                                       lpDDSOffMap_color,
                                       &rcRectTile,
                                       DDBLTFAST_WAIT |
                                       DDBLTFAST_SRCCOLORKEY );

              }
       }
   }
}




