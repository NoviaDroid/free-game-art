void InitLinkedList( void )
{
    /*
	g_bottom_node == NULL;
	g_top_node == NULL;
    g_bottom_task == NULL;
    g_top_task == NULL;
	g_bottom_notknown == NULL;
    g_top_notknown == NULL;
    g_bottom_explored == NULL;
    g_top_explored == NULL;
    g_bottom_colony == NULL;
	g_top_colony == NULL;
	g_bottom_unit_task == NULL;
	g_top_unit_task    == NULL;
	unit_first_in_list == NULL;
	*/

}

void CloseLinkedList( void )               // free all memory
{

   debugfile ("closing linked list\n", 1 );
   debugfile ("node memory\n", (sizeof( NODE))*8  );
   debugfile ("star 1 memory\n", (sizeof( star [1] ))*8 );
   debugfile ("planet memory\n", (sizeof( planet))*8  );
   debugfile ("hex memory in Oct\n", sizeof( hex) );
   debugfile ("hex memory for one world in K\n", (sizeof( hex))*8*planet_size_x*planet_size_y  );
   debugfile ("total memory for 1000 worlds in MEG K\n", ((sizeof( hex)*8*planet_size_y*planet_size_x)/1000)+((sizeof( planet)*8)/1000)  );
   LPNODE next_node = (LPNODE) NULL;
   LPNODE thenode;
   LPTASK next_task = (LPTASK) NULL;
   LPTASK thetask;
   int number_of_freed=0;

	for ( thenode=g_bottom_node; thenode != (LPNODE)NULL; thenode=next_node )
    {
		next_node = thenode->next;
		free( thenode );
		number_of_freed++;
	}
	debugfile ("freed nodes\n", number_of_freed );
	//////////////////////
	number_of_freed=0;
	for ( thetask=g_top_task; thetask != (LPTASK)NULL; thetask=next_task )
    {
        next_task = thetask->next;
		free( thetask );
        number_of_freed++;
	}
	debugfile ("freed thetask\n", number_of_freed );
	//////////////////////
	g_bottom_node = NULL;
	g_top_node = NULL;
    g_bottom_task = NULL;
    g_top_task = NULL;

	///free all units and their tasks//
	Freeunit_tasks ();
	Freeunit_in_game ();
}

void RemoveNode(
				LPNODE node     // the node to be removed
                )
{
  if ( node != (LPNODE) NULL )
  {
	if (node == g_bottom_node)
	{
			g_bottom_node = node->next;
			if ( g_bottom_node != (LPNODE) NULL )
			{
				g_bottom_node->prev = (LPNODE) NULL;
			}

    }
    else if (node == g_top_node)
    {
        g_top_node = node->prev;
        g_top_node->next = (LPNODE) NULL;
    }
    else
    {
        node->prev->next = node->next;
        node->next->prev = node->prev;
    }
	free( node );
  }
}

void RemoveTask(
				LPTASK task     // the task to be removed
                )
{
	if ( task != (LPTASK) NULL)
	{
        if (task == g_bottom_task)
        	{
        		g_bottom_task = task->prev;
				if ( g_bottom_task != (LPTASK) NULL )
        		{
        			g_bottom_task->next = (LPTASK) NULL;
        		}
        	}
        	else if (task == g_top_task)
        	{
        		g_top_task = task->next;
        		if ( g_top_task != (LPTASK) NULL )
        		{
        				g_top_task->prev = (LPTASK) NULL;
        		}
        	}
        	else
        	{
        		task->prev->next = task->next;
        		task->next->prev = task->prev;
        	}
        	free( task );
	}
}


void UpdateStates( void )
{
	// Go through each node in the list

    LPNODE next_node = (LPNODE) NULL;
    LPNODE thenode;
    double MapAjuster=GalaxySize/280;
    //int minX= (Zoomx-513-14)*MapAjuster;
    //int minY= (Zoomy-313-14)*MapAjuster;

    float minX= 1.0*((Zoomx-513.0-14.0)/Small_Place  )*MapAjuster;
    float minY= 1.0*((Zoomy-313.0-14.0)/Small_Place  )*MapAjuster;
    //int maxX= ((Zoomx-513+7-1)*MapAjuster);
    //int maxY= ((Zoomy-313+7-1)*MapAjuster);
    double ship_x_pos; double ship_y_pos;
    double ship_time_loc;
    double ship_time_total;
    double ship_time_percent;
    short int ship_x_start;
    short int ship_y_start;
    short int ship_x_fin;
    short int ship_y_fin;

    for ( thenode=g_bottom_node; thenode!=(LPNODE)NULL; thenode=next_node )
	{
		next_node = thenode->next;

         //(star[n].x -minX)*4,
         //((star[n].y -minY)*4)+100 ,

   		ship_time_loc  = 0.00 + ( TotalSec*10 + dwTime/100) - (thenode->start_time)*10;
   		ship_time_total= 0.00 + (thenode->arrive_time)*10 - (thenode->start_time)*10;
   		ship_time_percent= 0.00 + ship_time_loc / (ship_time_total + 0.0000001);
     		if ( ship_time_percent<1 )
         {
        		ship_x_start=star[(thenode->start_at)].x;
        		ship_y_start=star[(thenode->start_at)].y;
        		ship_x_fin=star[(thenode->going_to)].x;
        		ship_y_fin=star[(thenode->going_to)].y;
        		ship_x_pos= ship_x_start + ( (ship_x_fin - ship_x_start)*(ship_time_percent) );
        		ship_y_pos= ship_y_start + ( (ship_y_fin - ship_y_start)*(ship_time_percent) );
            if ( Zoomtype==1 )
            	{
        				lpDDSBack->BltFast( ((ship_x_pos-minX )*4),
											((ship_y_pos-minY )*4+100),
                                 	lpDDSOffSmaleStars,
                                    &rcRectShip,
                                    DDBLTFAST_WAIT |
                                    DDBLTFAST_SRCCOLORKEY );
               }
            else
            	{
               	lpDDSBack->BltFast( ((ship_x_pos-minX )*MapSet)-3,
        									((ship_y_pos-minY )*MapSet)-3,
                                 	lpDDSOffSmaleStars,
                                    &rcRectShip,
                                    DDBLTFAST_WAIT |
                                    DDBLTFAST_SRCCOLORKEY );
               }

     		}

      	else
      	{
      		RemoveNode(
                			   thenode     // the node to be removed
                			);
      	}
    }

}

void AddNode (
              LPNODE newNode    // the node to be added
              )
{   // added at top of list
    if (g_bottom_node == (LPNODE) NULL )    // if no other node
    {
        g_bottom_node = newNode;
        newNode->prev = (LPNODE) NULL ;
    }
    else                                    // else add to top
    {
        newNode->prev = g_top_node;
        newNode->prev->next = newNode;
    }
    g_top_node = newNode;
    newNode->next = (LPNODE) NULL;
}

void AddTask (
              LPTASK newTask    // the task to be added
              )
{   // added by order of time
    if (g_bottom_task == (LPTASK) NULL )    						// if no other task
    {
        g_bottom_task = newTask;
        g_top_task=     newTask;
        newTask->prev = (LPTASK) NULL ;
        newTask->next = (LPTASK) NULL ;
        return;
    }
    else if ( (newTask->time) >= (g_bottom_task->time) )   // if at end of list
    {
         g_bottom_task->next=newTask;
         newTask->prev = g_bottom_task ;
        	newTask->next = (LPTASK) NULL ;
         g_bottom_task = newTask;
         return;
    }
    else if ( (newTask->time) < (g_top_task->time) )       // if first of list                                     	  // if first of list
    {
         g_top_task->prev=newTask;
         newTask->prev = (LPTASK) NULL ;
        	newTask->next = g_top_task ;
         g_top_task = newTask;
         return;
    }
    else
    {                                                      // else in middle
         LPTASK temp_task; LPTASK next_task = (LPTASK) NULL;
         for ( temp_task=g_top_task; temp_task != (LPTASK)NULL; temp_task=next_task )
         {
             next_task = temp_task->next;
             if ( (newTask->time) < (temp_task->time) )
             {
                 	newTask->prev = temp_task->prev ;
        				newTask->next = temp_task ;
                  newTask->prev->next = newTask;
                  temp_task->prev = newTask;
                  return;
             }
         }
    }
}


LPNODE CreateShip( int desti, int start, short int mission,
							unsigned int Ttime, unsigned int	beginTime )
{
    LPNODE ship;

    ship = (LPNODE) malloc( sizeof(NODE) );

    if ( ship == NULL )
        return ship;

    ship->going_to =	desti;
    ship->start_at = start;
    ship->doing = 	mission;
    ship->arrive_time=Ttime;
    ship->start_time=beginTime;

    AddNode ( ship );

    return ship;
}

LPTASK CreateTask( short int id, int task_location, short int task_doing,
							unsigned int task_time, unsigned int task_start_time )
{
    LPTASK task_now;

    task_now = (LPTASK) malloc( sizeof(TASK) );

    if ( task_now == NULL )
        return task_now;

    task_now->alien_id =   id;
    task_now->location =	task_location;
    task_now->doing = 		task_doing;
    task_now->time = 		task_time;
    task_now->start_time=	task_start_time;

    AddTask ( task_now );

    return task_now;
}

