/////////unit placement////////

///free all units in hex///
void Freeunit_in_hex (
			  LPhex theHex    // the hex whose units are to be removed
			  )
{
	LPunit theUnit;
	LPunit next_unit= (LPunit)NULL;

	for ( theUnit=theHex->unit_in_hex; theUnit != (LPunit)NULL; theUnit=next_unit )
	{
		next_unit = theUnit->next;
		free( theUnit );
	}
}
///free all units in game///////////////////////////////
void Freeunit_in_game ( void )
{
	LPunit theUnit;
	LPunit next_unit=(LPunit)NULL;
	int number_of_freed=0;
	///free units
	for ( theUnit=unit_first_in_list; theUnit != (LPunit)NULL; theUnit=next_unit )
	{
		next_unit = theUnit->next;
		free( theUnit );
		number_of_freed++;
	}
	unit_first_in_list= NULL;
	debugfile ("freed units_in_game\n", number_of_freed );
}

//add unit to list////// //////////////////////////
void Add_unit_to_global (
			  LPunit newUnit    // the unit to be added
			  )
{   // added at top of list

	if (unit_first_in_list == (LPunit) NULL )    // if no other node
	{
		newUnit->next = (LPunit) NULL ;
	}
    else                                    // else add to top
    {
		newUnit->next = unit_first_in_list;
	}
	unit_first_in_list = newUnit;    // as at top, add link from hex
}

////remove from hex/////////////////////////
void RemoveUnitFromHex(
				LPunit unit_from_hex     // the unit to be removed
				)
{
	//debugfile ("RemoveUnitFromHex\n", 1 ) ;
	LPhex the_hex_with_unit=unit_from_hex->hex ;
	if ( unit_from_hex != (LPunit) NULL)
	{
		//remove from hex if top unit in chain
		if (unit_from_hex->prev_in_hex == (LPunit) NULL)
		{
			unit_from_hex->hex->unit_in_hex =  unit_from_hex->next_in_hex;
		}
		//remove from chain
		if (unit_from_hex->next_in_hex == (LPunit) NULL ) // g_bottom_unit
			{
				unit_from_hex->next_in_hex = unit_from_hex->prev_in_hex;
				if ( unit_from_hex->next_in_hex != (LPunit) NULL )
				{
					unit_from_hex->next_in_hex->next_in_hex = (LPunit) NULL;
				}
			}
		else if (unit_from_hex->prev_in_hex == (LPunit) NULL) // g_top_unit
			{
				unit_from_hex->prev_in_hex = unit_from_hex->next_in_hex;
				if ( unit_from_hex->prev_in_hex != (LPunit) NULL )
				{
						unit_from_hex->prev_in_hex->prev_in_hex = (LPunit) NULL;
				}
			}
		else
			{
				unit_from_hex->prev_in_hex->next_in_hex = unit_from_hex->next_in_hex;
				unit_from_hex->next_in_hex->prev_in_hex = unit_from_hex->prev_in_hex;
			}

		//debugfile ("Removed Unit From Hex\n", 1 )  ;
	}
}
////add to hex /////////////////////////////

void Add_unit_to_hex (
			  LPunit newUnit    // the unit to be added
			  )
{   // added at top of list

	if (newUnit->hex->unit_in_hex == (LPunit) NULL )    // if no other node
	{
		newUnit->next_in_hex = (LPunit) NULL ;
	}
	else                                    // else add to top
	{
		newUnit->next_in_hex = newUnit->hex->unit_in_hex;
		newUnit->next_in_hex->prev_in_hex = newUnit;
	}
	newUnit->hex->unit_in_hex = newUnit;    // as at top, add link from hex
	newUnit->prev_in_hex = (LPunit) NULL ;

}

///creat unit//////
LPunit Createunit( 	unsigned char type, unsigned char aligence,
					unsigned char blank1, unsigned char  facing,
					LPunit next, LPunit next_unit_in_hex, LPunit prev_unit_in_hex,
					LPhex  hex_with_units, int X_loc_in_HEX, int Y_loc_in_HEX
					)
{
	LPunit new_unit;

	new_unit = (LPunit) malloc( sizeof(unit) );

	if ( new_unit == NULL )
		{
			debugfile ("error creating unit\n", aligence );
			return new_unit;

		}

	new_unit->hex_x_loc	=	X_loc_in_HEX;
	new_unit->hex_y_loc	=	Y_loc_in_HEX;
	new_unit->type 		=	type;
	new_unit->aligence 	= 	aligence;
	new_unit->blank1 	= 	blank1;
	new_unit->facing	=	facing;
	new_unit->next		=	next;    ///global next, used to empty mem
	new_unit->next_in_hex=	next_unit_in_hex;
	new_unit->prev_in_hex=	prev_unit_in_hex;
	new_unit->hex		=	hex_with_units;
	///set pointers to null
	new_unit->going_path=   (LPhex_path) NULL;
	new_unit->desty_path=   (LPHEX_LIST) NULL;
	new_unit->task=         (LPUNIT_DOING_TASK) NULL;
	//////////add to universe/////////
	Add_unit_to_global ( new_unit );
	Add_unit_to_hex    ( new_unit );

	return new_unit;
}
///////////////////////////////////////////////
void Unit_start(
				LPplanet planet     // the planet to be checked
				)
{
	 unsigned char type_of_unit;
	 unsigned char aligence_of_unit;
	 unsigned char blank1_of_unit; unsigned char  direction_unit_facing;
	 int xx_location; int yy_location ;
	 LPunit next_unit; LPunit prev_unit;
	 LPunit next_unit_in_hex;
	 LPhex Hex_with_units;
	 if ( planet->palace != (LPbuilding) NULL  )
	 {

		Hex_with_units=     planet->planet_matrice[planet->palace->location_x][planet->palace->location_y];
		type_of_unit= 		NOBLE;
		aligence_of_unit= 	Hex_with_units->build_in_hex->aligence;
		blank1_of_unit= 	NONE;
		direction_unit_facing= 	random(6)+1; //six directions of hex
		xx_location=		HEX_CENTER_X;
		yy_location=		HEX_CENTER_Y;
		next_unit=  		(LPunit) NULL;
		prev_unit=  		(LPunit) NULL;
		next_unit_in_hex=  	(LPunit) NULL;

		Createunit( 	type_of_unit, aligence_of_unit,
							blank1_of_unit, direction_unit_facing,
							next_unit, prev_unit, next_unit_in_hex, Hex_with_units,
							xx_location, yy_location
					);
	  }
	  if ( planet->forts != (LPbuilding) NULL  )
	  {

		Hex_with_units=     planet->planet_matrice[planet->forts->location_x][planet->forts->location_y];
		aligence_of_unit= 	Hex_with_units->build_in_hex->aligence;
		type_of_unit= 		INFANTRY_1;  //default
		if ( aligence_of_unit == RED )    { type_of_unit = INFANTRY_4; }
		if ( aligence_of_unit == BLEU )   { type_of_unit = INFANTRY_3; }
		if ( aligence_of_unit == YELLOW ) { type_of_unit = INFANTRY_2; }
		if ( aligence_of_unit == ORANGE ) { type_of_unit = INFANTRY_5; }
		blank1_of_unit= 	NONE;
		direction_unit_facing= 	random(6)+1; //six directions of hex
		xx_location=		HEX_CENTER_X;
		yy_location=		HEX_CENTER_Y;
		next_unit=  		(LPunit) NULL;
		prev_unit=  		(LPunit) NULL;
		next_unit_in_hex=  	(LPunit) NULL;

		Createunit( 	type_of_unit, aligence_of_unit,
							blank1_of_unit, direction_unit_facing,
							next_unit, prev_unit, next_unit_in_hex, Hex_with_units,
							xx_location, yy_location
					);
	  }


	  if ( planet->first_town != (LPtown) NULL )
	  {
			//place a unit in each town
			for ( LPtown thetown = planet->first_town ; thetown != (LPtown)NULL ; thetown=thetown->next )
			{
				//security: if no building in town exit loop
				if ( thetown->housing != (LPbuilding) NULL )
				{
					Hex_with_units=     planet->planet_matrice[thetown->housing->location_x][thetown->housing->location_y];
					aligence_of_unit= 	Hex_with_units->build_in_hex->aligence;

					type_of_unit= 		INFANTRY_1;  //default
					if ( aligence_of_unit == RED )    { type_of_unit = INFANTRY_4; }
					if ( aligence_of_unit == BLEU )   { type_of_unit = INFANTRY_3; }
					if ( aligence_of_unit == YELLOW ) { type_of_unit = INFANTRY_2; }
					if ( aligence_of_unit == ORANGE ) { type_of_unit = INFANTRY_5; }

					//test computer movement on capital by seting all units on that world as high stewart
					if (star [planet->number].owner==HIGH_STEWARD)
					{
						type_of_unit = INFANTRY_1;
						aligence_of_unit=HIGH_STEWARD;
					}

					////end test

					blank1_of_unit= 	NONE;
					direction_unit_facing= 	random(6)+1; //six directions of hex
					xx_location=		HEX_CENTER_X;
					yy_location=		HEX_CENTER_Y;
					next_unit=  		(LPunit) NULL;
					prev_unit=  		(LPunit) NULL;
					next_unit_in_hex=  	(LPunit) NULL;

					Createunit( 	type_of_unit, aligence_of_unit,
									blank1_of_unit, direction_unit_facing,
									next_unit, prev_unit, next_unit_in_hex, Hex_with_units,
									xx_location, yy_location
								);
				}
			}
	  }

}
//////////////////////////////////////////
