
/////////// prototypes /////////////
void Steward_setup (void);
int Unit_Go_Random_Location (LPunit TheUnit);
int Unit_Wait_Random_Time(LPunit TheUnit);
void Map8xBackground(int ZoomXposition,int ZoomYposition);
void StarBackground(int Xposition,int Yposition);
void coast_draw_set ( LPplanet planet_creat, int check_hex_type, int not_if_type );
int planet_place_farm_land ( LPplanet planet_scaned, int nxxx, int nyyy );
int planet_scan_farm_land ( LPplanet planet_scaned, int nx, int ny );
void Creat_Nebula (void);
void Creat_GasGiant (void);
void border_line( LPplanet planet_creat, int scan_from, int scan_to, int change_type );
void coastline( LPplanet planet_creat );
void place_terain( LPplanet planet_creat, int change_from_1, int change_from_2, int change_to_1, int change_to_2, int rnd_factor, unsigned char place_type );
void hills( LPplanet planet_creat );
void plants ( LPplanet planet_creat );
void plants_oasis ( LPplanet planet_creat );
void swamps ( LPplanet planet_creat );
int river_value (unsigned char terre_type);
void get_hydro_percent( LPplanet planet_creat );
void rivers( LPplanet planet_creat );
int planet_scan_oasis_place ( LPplanet planet_scaned );
void Freeunit_tasks (void);
void Freeunit_in_game (void);
void Unit_Task_waiting_list(void);
void waiting_list(void);
int get_vars (void);
void ai_setup(void);
void randomname(void);
int Zoom_Routine_on_Selection (int blank);

