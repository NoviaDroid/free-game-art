void SetUpMap (int ZZoomx,int ZZoomy)
{
	cursorOff=true;
	startgame=false;
	FillScreen();
	//PlaceSmalleMap(ZZoomx,ZZoomy);		// smale map stars & zoom
	if (Zoomtype==1)  { PlaceMap1x(ZZoomx,ZZoomy);  } // large map starsx1
	if (Zoomtype==2)  { PlaceMap8x( ZZoomx,ZZoomy); } // large map starsx8
/*
		// menu screen #############################
		lpDDSOffScreen->BltFast( 0,0 , lpDDSOffOne, NULL,
                                               DDBLTFAST_WAIT |
    										   DDBLTFAST_SRCCOLORKEY );
*/
}

void UpdateMap (void)
{
	void SetUpSystem ();  void UpdateSystem ();
	int px; int py;
	//int MapXCenter=(276/2+513);int MapYCenter=(276/2+313);
	//float typeOfMap=1.0;
	py=((yPos)+22)/MapSet; px=((xPos)+12)/MapSet;

	// check if x1 map //check if cusor in section large screen //if mouse down
   if ( (Zoomtype==1) && (RMouseDown==1) )
	{
		 Zoomtype=2;
		 SetUpMap (Zoomx,Zoomy);
	  }

	if ( (Zoomtype==2) &&  (RMouseDown==1)  )
	{
		 Zoomx=(Zoomx+RMousexDif);
		 Zoomy=(Zoomy+RMouseyDif);
		 SetUpMap (Zoomx,Zoomy);
	  }

   // if mouse in smalle map section & mouse Lbutton down
   // or start game true


   if  (   (LMouseDown==1 )  ||	(startgame==true) )
           		{
           			 //Zoomx=int(LMousexPos);
           			 //Zoomy=int(LMouseyPos);
           			 SetUpMap (Zoomx,Zoomy);
				  }



    // check if x8 map  //  check if cusor in section large screen
      /*
       if ( (Zoomtype==2)  )
          	{
                if (screenMap[px][py]!=0)   		// if cursor over star
                {
                	FixedMouseX=xPos;
             		FixedMouseY=yPos;
       			SolarSystem(false);



       				if  (LMouseDown==true)          	// if click on star
       				{
       					ScreenType=WORLD;
       				   	planet_see_x= screen_x;
       					planet_see_y= 0;
       					//planet_see_x= 1240;
       					//planet_see_y= -240;
       					planet_draw=screenMap[px][py];
       					LPplanet planet=star[planet_draw].planet_surface;
       					Draw_the_World(planet,planet_see_x,planet_see_y);
       					return;
       				}


                }
			 }
   */

   // place czars screen memory into back buffer, ready for flip
   lpDDSBack->BltFast( 0,0 , lpDDSOffScreen, NULL,
                                           DDBLTFAST_WAIT |
                                           DDBLTFAST_SRCCOLORKEY );

   // animation here..................................

   // space ships
   UpdateStates();


   // smalle see world
/*
        if (	(Zoomtype==2) && (screenMap[px][py]!=0)  &&  (xPos<486) && (yPos>109)	)
       	{
    		 DrawWorld(screenMap[px][py]);
    		 //InSolar(typeOfMap, MapXCenter, MapYCenter,px,py);
		  }
*/
	//   else { 	PlaceSmalleMap(Zoomx,Zoomy);	}
}
