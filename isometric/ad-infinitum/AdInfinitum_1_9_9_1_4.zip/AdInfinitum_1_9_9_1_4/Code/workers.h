//creat worker node
LPLABOUR CreateTownWorkers ( LPbuilding worker_home, LPbuilding worker_work, LPLABOUR next_worker,
							unsigned char owner_of_worker, unsigned char worker_type )
{
    // creat new list node
    LPLABOUR worker_now;
	worker_now = (LPLABOUR) malloc( sizeof(LABOUR) );
    if ( worker_now == NULL )
    	{
			debugfile ("NO MEM worker or labour \n", 1 );
		}

	creat_nodes++;

	worker_now->home =			worker_home;
	worker_now->work =			worker_work;
	worker_now->next = 			next_worker;
	worker_now->aligence =   	owner_of_worker;
	worker_now->type =   		worker_type;

	return worker_now;
}

////////////////////////////////////////
//set all of a worlds workers in towns to default
void set_workers ( LPplanet planet )
{
	//go through towns on planet
	for ( LPtown town_temp=planet->first_town; town_temp != (LPtown)NULL; town_temp=town_temp->next )
	{
		//go through town structures in towns
		for ( LPbuilding town_struct=town_temp->housing; town_struct != (LPbuilding)NULL; town_struct=town_struct->next )
		{
			//give  worker units to house structure
			LPLABOUR Prev_Worker = (LPLABOUR)NULL;
			int units_aligence=town_struct->aligence;

			for ( int n_work=1; n_work <= Num_workers; n_work++ )
			{
				LPLABOUR New_Worker =	CreateTownWorkers ( town_struct,
															(LPbuilding)NULL,
															Prev_Worker,
															units_aligence,
															UNEMPLOYED );
				if  (n_work==Num_workers)
				{
					  town_struct->worker = New_Worker;
				}


				Prev_Worker =  New_Worker;
			}
		}
	}

	//////farm workers/////////
	for ( LPbuilding farm_temp=planet->farms; farm_temp != (LPbuilding)NULL; farm_temp=farm_temp->next )
	{
	  int start_x=farm_temp->location_x;
	  int start_y=farm_temp->location_y;
	  int desty_type=UNEMPLOYED;
	  int dest_x=NONE;
	  int dest_y=NONE;

	  //LPLABOUR farmer_Worker;

		if ( desty_type!=NONE )
		{

			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1000, TRANSPORT )==true)
			{
				if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex!=(LPbuilding)NULL)
				{
					 if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker==(LPLABOUR)NULL)
					{
						  debugfile ("ERROR...no worker on farm employ.\n", 1 ); //#/#/#/
					}
					else
					{
						for ( LPLABOUR workers=planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
						{
							if (workers->type==UNEMPLOYED)
							{
								workers->type=FARMER;

								planet->planet_matrice[start_x][start_y]->build_in_hex->worker=workers;

								workers->work=planet->planet_matrice[g_top_hex_list->x_location][g_top_hex_list->y_location]->build_in_hex;

								workers->work->aligence=workers->aligence;

								break;
							}
                        }



					}
				}
				else debugfile ("ERROR...no building on farm employ.\n", 1 ); //#/#/#/



			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////well workers/////////
	for ( LPbuilding well_temp=planet->wells; well_temp != (LPbuilding)NULL; well_temp=well_temp->next )
	{
	  int start_x=well_temp->location_x;
	  int start_y=well_temp->location_y;
	  int desty_type=UNEMPLOYED;
	  int dest_x=NONE;
	  int dest_y=NONE;

	  //LPLABOUR well_worker;

		if ( desty_type!=NONE )
		{

			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1000, TRANSPORT )==true)
			{
				if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex!=(LPbuilding)NULL)
				{
					 if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker==(LPLABOUR)NULL)
					{
						  debugfile ("ERROR...no worker on mine employ.\n", 1 ); //#/#/#/
					}
					else
					{
						for ( LPLABOUR workers=planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
						{
							if (workers->type==UNEMPLOYED)
							{
								if (well_temp->type==WELL)
								{
									workers->type=OILWELL_WORKER;
								}
								if (well_temp->type==OFFSHORE_WELL)
								{
									workers->type=OILPLATFORM_WORKER;
								}

								planet->planet_matrice[start_x][start_y]->build_in_hex->worker=workers;

								workers->work=planet->planet_matrice[g_top_hex_list->x_location][g_top_hex_list->y_location]->build_in_hex;

								workers->work->aligence=workers->aligence;

								break;
							}
                        }



					}
				}
				else debugfile ("ERROR...no building on mine employ.\n", 1 ); //#/#/#/



			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////mine workers/////////
	for ( LPbuilding mine_temp=planet->mines; mine_temp != (LPbuilding)NULL; mine_temp=mine_temp->next )
	{
	  int start_x=mine_temp->location_x;
	  int start_y=mine_temp->location_y;
	  int desty_type=UNEMPLOYED;
	  int dest_x=NONE;
	  int dest_y=NONE;

	  LPLABOUR miner_worker;

		if ( desty_type!=NONE )
		{

			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1000, TRANSPORT )==true)
			{
				if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex!=(LPbuilding)NULL)
				{
					 if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker==(LPLABOUR)NULL)
					{
						  debugfile ("ERROR...no worker on mine employ.\n", 1 ); //#/#/#/
					}
					else
					{
						for ( LPLABOUR workers=planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
						{
							if (workers->type==UNEMPLOYED)
							{
								if (mine_temp->type==MINE)
								{
									workers->type=MINER;
								}
								else if (mine_temp->type==MINE_TRACE)
								{
									workers->type=MINER_TRACE;
								}
								else if (mine_temp->type==MINE_GEMS)
								{
									workers->type=MINER_GEMS;
								}
								else if (mine_temp->type==MINE_HYPER_STEEL)
								{
									workers->type=MINER_HYPER_STEEL;
								}
								else if (mine_temp->type==MINE_RADIOACTIVE)
								{
									workers->type=MINER_RADIOACTIVE;
								}
								else if (mine_temp->type==MINE_CHEMY)
								{
									workers->type=MINER_CHEMY;
								}

								planet->planet_matrice[start_x][start_y]->build_in_hex->worker=workers;

								workers->work=planet->planet_matrice[g_top_hex_list->x_location][g_top_hex_list->y_location]->build_in_hex;

								workers->work->aligence=workers->aligence;

								break;
							}
						}



					}
				}
				else debugfile ("ERROR...no building on mine employ.\n", 1 ); //#/#/#/



			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////palace workers/////////
	for ( LPbuilding palace_temp=planet->palace; palace_temp != (LPbuilding)NULL; palace_temp=palace_temp->next )
	{
	  int start_x=palace_temp->location_x;
	  int start_y=palace_temp->location_y;
	  int desty_type=UNEMPLOYED;
	  int dest_x=NONE;
	  int dest_y=NONE;

		if ( desty_type!=NONE )
		{

			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1000, TRANSPORT )==true)
			{
				if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex!=(LPbuilding)NULL)
				{
					 if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker==(LPLABOUR)NULL)
					{
						  debugfile ("ERROR...no worker on palace employ.\n", 1 ); //#/#/#/
					}
					else
					{
						for ( LPLABOUR workers=planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
						{
							if (workers->type==UNEMPLOYED)
							{
								workers->type=PALACE_STAFF;

								planet->planet_matrice[start_x][start_y]->build_in_hex->worker=workers;

								workers->work=planet->planet_matrice[g_top_hex_list->x_location][g_top_hex_list->y_location]->build_in_hex;

								workers->work->aligence=workers->aligence;

								break;
							}
						}



					}
				}
				else debugfile ("ERROR...no building on palace employ.\n", 1 ); //#/#/#/



			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////factory workers/////////
	/////go through towns/////////
	for ( LPtown thetown=planet->first_town; thetown != (LPtown)NULL; thetown=thetown->next )
	{
		  if (thetown->industry!=(LPbuilding) NULL)
		  {
			  //go through industrial buildings
			  for ( LPbuilding TheIndustry=thetown->industry; TheIndustry != (LPbuilding)NULL; TheIndustry=TheIndustry->next )
			  {
				  int   found_home_place=false;
				  //go through town buildings in town to find home
				  for ( LPbuilding TheHome=thetown->housing; TheHome != (LPbuilding)NULL; TheHome=TheHome->next )
				  {
					  ///check for unemployed
					  for ( LPLABOUR workers=TheHome->worker; workers != (LPLABOUR)NULL; workers=workers->next )
						{
							if (workers->type==UNEMPLOYED)
							{
								if (TheIndustry->type==FACTORY)
								{
									 workers->type=FACTORY_WORKER;
								}
								if (TheIndustry->type==CHEMY)
								{
									 workers->type=FACTORY_WORKER_CHEMY;
								}
								if (TheIndustry->type==ELEC)
								{
									 workers->type=FACTORY_WORKER_ELEC;
								}
								if (TheIndustry->type==STEEL)
								{
									 workers->type=FACTORY_WORKER_STEEL;
								}

								TheIndustry->worker=workers;

								workers->work=TheIndustry;

								found_home_place=true;

								workers->work->aligence=workers->aligence;

								break;
							}
						}
					  if (found_home_place==true) { break;  }
                  }
              }
		  }
	}

	//////star port workers/////////
	for ( LPbuilding star_temp=planet->starports; star_temp != (LPbuilding)NULL; star_temp=star_temp->next )
	{
	  int start_x=star_temp->location_x;
	  int start_y=star_temp->location_y;
	  int desty_type=UNEMPLOYED;
	  int dest_x=NONE;
	  int dest_y=NONE;

		if ( desty_type!=NONE )
		{

			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1000, TRANSPORT )==true)
			{
				if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex!=(LPbuilding)NULL)
				{
					 if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker==(LPLABOUR)NULL)
					{
						  debugfile ("ERROR...no worker on starport employ.\n", 1 ); //#/#/#/
					}
					else
					{
						for ( LPLABOUR workers=planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
						{
							if (workers->type==UNEMPLOYED)
							{
								workers->type=STAR_PORT_DOCKER;

								planet->planet_matrice[start_x][start_y]->build_in_hex->worker=workers;

								workers->work=planet->planet_matrice[g_top_hex_list->x_location][g_top_hex_list->y_location]->build_in_hex;

								workers->work->aligence=workers->aligence;

								break;
							}
						}



					}
				}
				else debugfile ("ERROR...no building on starport employ.\n", 1 ); //#/#/#/



			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////lab workers/////////
	for ( LPbuilding lab_temp=planet->labs; lab_temp != (LPbuilding)NULL; lab_temp=lab_temp->next )
	{
	  int start_x=lab_temp->location_x;
	  int start_y=lab_temp->location_y;
	  int desty_type=UNEMPLOYED;
	  int dest_x=NONE;
	  int dest_y=NONE;

		if ( desty_type!=NONE )
		{

			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1000, TRANSPORT )==true)
			{
				if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex!=(LPbuilding)NULL)
				{
					 if (planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker==(LPLABOUR)NULL)
					{
						  debugfile ("ERROR...no worker on lab employ.\n", 1 ); //#/#/#/
					}
					else
					{
						for ( LPLABOUR workers=planet->planet_matrice[desti_hex_list->x_location][desti_hex_list->y_location]->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
						{
							if (workers->type==UNEMPLOYED)
							{
								workers->type=LAB_ASSISTANT;

								planet->planet_matrice[start_x][start_y]->build_in_hex->worker=workers;

								workers->work=planet->planet_matrice[g_top_hex_list->x_location][g_top_hex_list->y_location]->build_in_hex;

                                workers->work->aligence=workers->aligence;

								break;
							}
						}



					}
				}
				else debugfile ("ERROR...no building on lab employ.\n", 1 ); //#/#/#/



			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
 /////////////////
}
