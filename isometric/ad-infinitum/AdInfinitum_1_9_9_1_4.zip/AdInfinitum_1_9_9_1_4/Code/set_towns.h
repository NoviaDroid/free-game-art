void add_mines ( LPbuilding newNode, LPplanet planet_scaned )
{
    // added at top of list
	if ( planet_scaned->mines==(LPbuilding) NULL) // if no other node
	{
		planet_scaned->mines = newNode;
		newNode->next = (LPbuilding) NULL ;
	}
	else                                    // else add to top
    {
        newNode->next = planet_scaned->mines;
		planet_scaned->mines->prev=newNode;
		planet_scaned->mines = newNode;
    }
	newNode->prev = (LPbuilding) NULL;
}

void add_wells ( LPbuilding newNode, LPplanet planet_scaned )
{
    // added at top of list
	if ( planet_scaned->wells==(LPbuilding) NULL) // if no other node
	{
		planet_scaned->wells = newNode;
		newNode->next = (LPbuilding) NULL ;
	}
	else                                    // else add to top
    {
        newNode->next = planet_scaned->wells;
		planet_scaned->wells->prev=newNode;
		planet_scaned->wells = newNode;
    }
	newNode->prev = (LPbuilding) NULL;
}

void add_forts ( LPbuilding newNode, LPplanet planet_scaned )
{
    // added at top of list
	if ( planet_scaned->forts==(LPbuilding) NULL) // if no other node
	{
        planet_scaned->forts = newNode;
		newNode->next = (LPbuilding) NULL ;
    }
    else                                    // else add to top
    {
        newNode->next = planet_scaned->forts;
		planet_scaned->forts->prev=newNode;
		planet_scaned->forts = newNode;
    }
	newNode->prev = (LPbuilding) NULL;
}

void add_farms ( LPbuilding newNode, LPplanet planet_scaned )
{
    // added at top of list
	if ( planet_scaned->farms==(LPbuilding) NULL) // if no other node
	{
        planet_scaned->farms = newNode;
		newNode->next = (LPbuilding) NULL ;
    }
    else                                    // else add to top
    {
        newNode->next = planet_scaned->farms;
		planet_scaned->farms->prev=newNode;
		planet_scaned->farms = newNode;
    }
	newNode->prev = (LPbuilding) NULL;
}

void add_labs ( LPbuilding newNode, LPplanet planet_scaned )
{
    // added at top of list
	if ( planet_scaned->labs==(LPbuilding) NULL) // if no other node
	{
        planet_scaned->labs = newNode;
		newNode->next = (LPbuilding) NULL ;
    }
    else                                    // else add to top
    {
        newNode->next = planet_scaned->labs;
		planet_scaned->labs->prev=newNode;
		planet_scaned->labs = newNode;
    }
	newNode->prev = (LPbuilding) NULL;
}

void add_starport ( LPbuilding newNode, LPplanet planet_scaned )
{
    // added at top of list
	if ( planet_scaned->starports==(LPbuilding) NULL) // if no other node
	{
        planet_scaned->starports = newNode;
		newNode->next = (LPbuilding) NULL ;
    }
    else                                    // else add to top
    {
        newNode->next = planet_scaned->starports;
		planet_scaned->starports->prev=newNode;
		planet_scaned->starports = newNode;
    }
	newNode->prev = (LPbuilding) NULL;
}

void add_palace ( LPbuilding newNode, LPplanet planet_scaned )
{
    // added at top of list
	if ( planet_scaned->palace==(LPbuilding) NULL) // if no other node
	{
        planet_scaned->palace = newNode;
		newNode->next = (LPbuilding) NULL ;
    }
    else                                    // else add to top
    {
        newNode->next = planet_scaned->palace;
		planet_scaned->palace->prev=newNode;
		planet_scaned->palace = newNode;
    }
	newNode->prev = (LPbuilding) NULL;
}

 void add_churche ( LPbuilding newNode, LPplanet planet_scaned )
{
    // added at top of list
	if ( planet_scaned->churches==(LPbuilding) NULL) // if no other node
	{
        planet_scaned->churches = newNode;
		newNode->next = (LPbuilding) NULL ;
    }
    else                                    // else add to top
    {
		newNode->next = planet_scaned->churches;
		planet_scaned->churches->prev=newNode;
		planet_scaned->churches = newNode;
    }
	newNode->prev = (LPbuilding) NULL;
}

void add_ruins ( LPbuilding newNode, LPplanet planet_scaned )
{
	// added at top of list
	if ( planet_scaned->ruins==(LPbuilding) NULL) // if no other node
	{
		planet_scaned->ruins = newNode;
		newNode->next = (LPbuilding) NULL ;
	}
	else                                    // else add to top
	{
		newNode->next = planet_scaned->ruins;
		planet_scaned->ruins->prev=newNode;
		planet_scaned->ruins = newNode;
	}
	newNode->prev = (LPbuilding) NULL;
}



LPtown CreateTownNode( unsigned char type1, unsigned char aligence1, unsigned char population1,
							unsigned char blank11, unsigned char town_number1, LPtown next1,
							LPtown	prev1, LPbuilding housing1, LPbuilding industry1 )
{
    // creat new list node
    LPtown town_now;
	town_now = (LPtown) malloc( sizeof(town) );
    if ( town_now == NULL )
    	{
			debugfile ("NO MEM town list\n", 1 );
		}

	creat_nodes++;

	town_now->type =   		type1;
	town_now->aligence =   	aligence1;
	town_now->population =	population1;
	town_now->blank1=		blank11;
	town_now->town_number= 	town_number1;
	town_now->prev = 		prev1;
	town_now->next = 		next1;
	town_now->housing = 	housing1;
	town_now->industry = 	industry1;


	return town_now;
}

void DeleteAllTownNodes ( LPplanet planet_with_towns )
{
	LPtown next_town;
	for ( LPtown thetown=planet_with_towns->first_town; thetown != (LPtown)NULL; thetown=next_town )
    {
        next_town = thetown->next;
        free( thetown );
		free_nodes++;
    }
	planet_with_towns->first_town=(LPtown)NULL;
}

void add_town ( LPbuilding newNode, LPplanet planet_scaned, int building_type )
{
	//debugfile (" ##tryin build num##\n",newNode->town_number );
	LPtown next_town;
	// added at top of list
	if ( planet_scaned->first_town==(LPtown) NULL) // if no other town node
	{
		debugfile ("creating first town.\n",newNode->town_number );

		newNode->next = (LPbuilding) NULL ;
		newNode->prev = (LPbuilding) NULL ;
		if (building_type==TOWN)
		{
			planet_scaned->first_town = CreateTownNode( TOWN, NUTRAL, Num_workers,
														NONE, newNode->town_number, (LPtown) NULL,
														(LPtown) NULL, newNode, (LPbuilding) NULL );
		}
		else
		{
			planet_scaned->first_town = CreateTownNode( TOWN, NUTRAL, Num_workers,
														NONE, newNode->town_number, (LPtown) NULL,
														(LPtown) NULL,(LPbuilding) NULL, newNode );
        }

	}
	else    // go through town numbers to see if in
	{
		for ( LPtown thetown=planet_scaned->first_town; thetown != (LPtown)NULL; thetown=next_town )
		{
			//debugfile ("trying twon num.\n",thetown->town_number );
			//if in
			if ( thetown->town_number==newNode->town_number )
			{
				if (thetown != (LPtown)NULL)
				{
					if (building_type==TOWN)
					{
						if (thetown->housing!=(LPbuilding) NULL)
						{
							newNode->next = thetown->housing;
							thetown->housing->prev=newNode;
							thetown->housing = newNode;
							newNode->prev = (LPbuilding) NULL;
							return;
						}
						else
						{
							newNode->next = (LPbuilding) NULL;
							thetown->housing = newNode;
							newNode->prev = (LPbuilding) NULL;
							return;
						}
					}
					else
                    {
						if (thetown->industry!=(LPbuilding) NULL)
						{
							newNode->next = thetown->industry;
							thetown->industry->prev=newNode;
							thetown->industry = newNode;
							newNode->prev = (LPbuilding) NULL;
							return;
						}
						else
						{
							newNode->next = (LPbuilding) NULL;
							thetown->industry = newNode;
							newNode->prev = (LPbuilding) NULL;
							return;
                        }
					}
				}
			}

			next_town = thetown->next;

			//if no other towns to check
			//creat town, and place into
			if ( next_town == (LPtown)NULL )
			{
				//debugfile ("creating end of list town.\n",newNode->town_number );
                if (building_type==TOWN)
					{
						thetown->next=CreateTownNode( TOWN, NONE, Num_workers, NONE, newNode->town_number, (LPtown) NULL,
									thetown, newNode, (LPbuilding) NULL);
					}
				else
					{
                         thetown->next=CreateTownNode( TOWN, NONE, Num_workers, NONE, newNode->town_number, (LPtown) NULL,
									thetown, (LPbuilding) NULL, newNode);
                    }
				newNode->next = (LPbuilding) NULL ;
				newNode->prev = (LPbuilding) NULL ;
				return;
			}

		}

	}

}

//////////////////planet construction/////////////////
 ///////scan world for mine/well locations
int planet_scan_mine_place ( LPplanet planet_scaned )
{
   int check_hex_x, check_hex_y;
   int scan_yes;
   //int Number_diferent;
   //int change_for_coast;
   int town_temp [100][100];
   int nx,ny;
   int structure_type;

   int planet_number = planet_scaned->number;
   int dice;
   int scan_value=0;
   int total_value=0;

	for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   { town_temp [nx][ny] =  0; }  //set to null
   }

   for (ny=0; ny< planet_size_y; ny++)
   {


	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			check_hex_x = nx;
			check_hex_y = ny;
			//first work out center hex
			scan_yes = false; //default
			scan_value = 0;   //default
			if ( (planet_scaned->planet_matrice[nx][ny]->resourse) == GEM )
					 { scan_value=scan_value+1000; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->resourse) == METAL )
					 { scan_value=scan_value+50; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->resourse) == TRACE )
					 { scan_value=scan_value+50; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->resourse) == OIL )
					 { scan_value=scan_value+100; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->resourse) == RADIOACTIVE )
					 { scan_value=scan_value+100; scan_yes = true; }

			//no build on another building
			if  ( planet_scaned->planet_matrice[nx][ny]->build_in_hex != (LPbuilding) NULL )
					 { scan_value=0; scan_yes = false;}

			town_temp [nx][ny] = scan_value;
			total_value=total_value+scan_value;
	   }
   }
   //now work out where mine randomly is
   if (total_value==0)
   {
		 return false;
   }
   dice = random( total_value );
   int adding_value=0;
   for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			adding_value=adding_value+town_temp [nx][ny];
			if (adding_value  >  dice)
			{
				////wells
				if (planet_scaned->planet_matrice[nx][ny]->resourse==OIL)
				{
					if ( (planet_scaned->planet_matrice[nx][ny]->type==HYDRO) && (planet_scaned->hydro_type!=DESERT) )
					{
						if ( planet_scaned->hydro_type != DUNE )
						structure_type=OFFSHORE_WELL;
						else structure_type=WELL;
					}
					else structure_type=WELL;
				}
				else    ////mines
                {
					//structure_type=MINE;      //debug

					if (planet_scaned->planet_matrice[nx][ny]->resourse==METAL)
					{
						structure_type=MINE;
					}
					else if (planet_scaned->planet_matrice[nx][ny]->resourse==TRACE)
					{
						structure_type=MINE_TRACE;
					}
					else if (planet_scaned->planet_matrice[nx][ny]->resourse==GEM)
					{
						structure_type=MINE_GEMS;
					}
					else if (planet_scaned->planet_matrice[nx][ny]->resourse==RADIOACTIVE)
					{
						structure_type=MINE_RADIOACTIVE;
					}
					else if (planet_scaned->planet_matrice[nx][ny]->resourse==HYPER_STEEL)
					{
						structure_type=MINE_HYPER_STEEL;
					}
					else if (planet_scaned->planet_matrice[nx][ny]->resourse==CHEMICAL)
					{
						structure_type=MINE_CHEMY;
					}
					else if (planet_scaned->planet_matrice[nx][ny]->resourse==SPICE)
					{
						debugfile ("ERROR working out spice.\n",1 );
						structure_type=MINE_CHEMY;
					}
					else
					{
					   structure_type=MINE;
					   debugfile ("ERROR no resource.\n",1 );
					   debugfile ("ERROR no resource.\n",planet_scaned->planet_matrice[nx][ny]->resourse );
					}

				}

				LPbuilding build_now;

				build_now = (LPbuilding) malloc( sizeof(building) );

				if ( build_now == NULL )
				return false;

				build_now->location_x=nx;
				build_now->location_y=ny;

				build_now->type =   	structure_type;
				build_now->aligence =	NUTRAL;
				build_now->population = NONE;
				build_now->blank1 = 	NONE;
				build_now->worker = 	(LPLABOUR) NULL;


				//Addbuilding ( build_now );

				///now cut down trees, dry any  swamp
				if (planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_PLAIN)
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
				}
				if (planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_HILL)
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  HILL;
				}
				if ( (planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_SWAMP) && (planet_scaned->planet_type!=OASIS))
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
				}
				else if ( (planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_SWAMP) && (planet_scaned->planet_type==OASIS))
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  SWAMP;
                }
				if ( (planet_scaned->planet_matrice[nx][ny]->type ==  SWAMP) && (planet_scaned->planet_type!=OASIS) )
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
				}

				planet_scaned->planet_matrice[nx][ny]->build_in_hex = build_now;
				if (	structure_type==WELL || structure_type==OFFSHORE_WELL) add_wells ( build_now, planet_scaned );
				else add_mines ( build_now, planet_scaned );
				return true;

			}

	   }
   }

return false;
}

////scan world for best locations
int planet_scan_town_place ( LPplanet planet_scaned, int structure_type, int the_town_number )
{
   //debugfile ("RAND_MAX\n",  RAND_MAX); //should check max rand funtion (14 points per hex as max)

   int check_hex_x, check_hex_y;
   int scan_yes;
   //int Number_diferent;
   //int change_for_coast;
   int town_temp [100][100];
   int nx,ny;
   int odd_even;
   int planet_number = planet_scaned->number;
   int dice;
   int scan_value;
   int total_value=0;
   int swamp_bonus=0;
   if (planet_scaned->planet_type==OASIS)
   {
		swamp_bonus = 10;
   }

	for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   { town_temp [nx][ny] =  0; }  //set to null
   }

   for (ny=0; ny< planet_size_y; ny++)
    {
	   odd_even = (ny+1) % 2;

	   for (nx=0; nx< planet_size_x; nx++ )
	    {
			check_hex_x = nx;
			check_hex_y = ny;
			//first work out center hex
			scan_yes = false; //default
			scan_value = 0;   //default
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == PLAIN )
					 { scan_value=scan_value+6; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == HILL )
					 { scan_value=scan_value+2; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == PLANT_PLAIN )
					 { scan_value=scan_value+2; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == PLANT_HILL )
					 { scan_value=scan_value+1; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == SWAMP )
					 { scan_value=scan_value+1+swamp_bonus; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == PLANT_SWAMP )
					 { scan_value=scan_value+1+swamp_bonus; scan_yes = true; }
			//no build on another building
			if  ( planet_scaned->planet_matrice[nx][ny]->build_in_hex != (LPbuilding) NULL )
					 { scan_value=0; scan_yes = false;}
			// no farm not on swamp land on oasis world
			if  ( (planet_scaned->planet_type==OASIS) && (structure_type==FARM) && ( planet_scaned->planet_matrice[nx][ny]->type != SWAMP ) )
					 { scan_value=0; scan_yes = false;}


			//then scan neibours for adjustments on value
			if (scan_yes == true) //scan hexs only if center can build
			{
				//Number_diferent=0;

				if ( planet_scaned->planet_matrice[nx][ny] == NULL )
				{debugfile ("error....no hex in scan town \n", planet_number );}

                /// check east hex
				check_hex_x = nx+1;
				if ( check_hex_x >= planet_size_x )
					 { check_hex_x = 0; }  //go round world if over
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
					 { scan_value=scan_value+6; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
					 { scan_value=scan_value+2; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
					 { scan_value=scan_value+2; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
					 { scan_value=scan_value+1; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
					 { scan_value=scan_value+1+swamp_bonus; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
					 { scan_value=scan_value+1+swamp_bonus; }
				//no build next to another building with towns
				if  ( structure_type == TOWN  )
					{
						if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
						{ scan_value=0;}
					}

				/// check west hex
				check_hex_x = nx-1;
                if ( check_hex_x < 0 )
                     { check_hex_x = planet_size_x-1; }  //go round world if over
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
					 { scan_value=scan_value+6; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
					 { scan_value=scan_value+2; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
					 { scan_value=scan_value+2; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
					 { scan_value=scan_value+1; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
					 { scan_value=scan_value+1+swamp_bonus; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
					 { scan_value=scan_value+1+swamp_bonus; }
				//no build next to another building with towns
				if  ( structure_type == TOWN  )
					{
						if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
						{ scan_value=0;}
					}

				/// check north west hex
				check_hex_x = nx;
                check_hex_y = ny-1;
				if ( check_hex_y >= 0 ) //only check if not over top
				{
                     if ( odd_even == 1 )
					 {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+6; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+1; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							//no build next to another building with towns
							if  ( structure_type == TOWN  )
							{
								if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
								{ scan_value=0;}
							}
					 }
					 else
                     {
						   check_hex_x = nx-1;
                           if ( check_hex_x < 0 )
							 { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+6; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+1; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							//no build next to another building with towns
							if  ( structure_type == TOWN  )
							{
								if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
								{ scan_value=0;}
							}
                     }
				}

				/// check north east hex
				check_hex_x = nx;
                check_hex_y = ny-1;
                if ( check_hex_y >= 0 ) //only check if not over top
				{
					 if ( odd_even == 0 )
                     {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+6; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+1; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							//no build next to another building with towns
							if  ( structure_type == TOWN  )
							{
								if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
								{ scan_value=0;}
							}
                     }
					 else
					 {
                           check_hex_x = nx+1;
						   if ( check_hex_x >= planet_size_x )
								{ check_hex_x = 0; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+6; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+1; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							//no build next to another building with towns
							if  ( structure_type == TOWN  )
							{
								if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
								{ scan_value=0;}
							}
					 }
                }


				/// check South west hex
				check_hex_x = nx;
                check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
				{
                     if ( odd_even == 1 )
                     {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+6; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+1; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							//no build next to another building with towns
							if  ( structure_type == TOWN  )
							{
								if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
								{ scan_value=0;}
							}
					 }
					 else
                     {
                           check_hex_x = nx-1;
						   if ( check_hex_x < 0 )
                             { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+6; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+1; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							//no build next to another building with towns
							if  ( structure_type == TOWN  )
							{
								if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
								{ scan_value=0;}
							}
                     }
                }

				/// check South east hex
				check_hex_x = nx;
				check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
                {
					 if ( odd_even == 0 )
                     {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+6; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+1; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							//no build next to another building with towns
							if  ( structure_type == TOWN  )
							{
								if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
								{ scan_value=0;}
							}
					 }
                     else
					 {
                           check_hex_x = nx+1;
						   if ( check_hex_x >= planet_size_x )
								{ check_hex_x = 0; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+6; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+2; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+1; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+1+swamp_bonus; }
							//no build next to another building with towns
							if  ( structure_type == TOWN  )
							{
								if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
								{ scan_value=0;}
							}
					 }
                }

				/*
                    if ( Number_diferent > 0 )
                    				{  town_temp [nx][ny] = 1;  }
									else
									{  town_temp [nx][ny] = 2;  }

				*/
				if ( check_hex_x < 0 ) debugfile ("error....check hex less than zero, x\n", check_hex_x );
				if ( check_hex_x >= planet_size_x ) debugfile ("error....check hex too big, x\n", check_hex_x );
			}

			if (scan_value>14) {scan_value=14;}//to offset rand max number
			town_temp [nx][ny] = scan_value;
			total_value=total_value+scan_value;
	    }
    }
   //now work out where town randomly is
   if (total_value==0)
   {
		 return false;
   }
   dice = rand()%total_value ;
   int adding_value=0;
   for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			adding_value=adding_value+town_temp [nx][ny];
			if (adding_value  >  dice)
			{
				//debug
				//if (FIRST_BUILD_PLANET==true)
					//{

					   //debugfile ("built structure type\n", structure_type);
					   //debugfile ("at x\n", nx);
					   //debugfile ("at y\n", ny);
					   //debugfile ("adding_value\n", adding_value);
					   //debugfile ("dice value\n", adding_value);
					   //debugfile ("total value\n", total_value);
					   //debugfile ("RAND_MAX\n",  RAND_MAX);
					   //debugfile ("############################\n", 0);

					//}


				LPbuilding build_now;

				build_now = (LPbuilding) malloc( sizeof(building) );

				if ( build_now == NULL )
				return false;

                build_now->location_x=nx;
				build_now->location_y=ny;

				build_now->type =   	structure_type;
				build_now->aligence =	NUTRAL;
				build_now->population = NONE;
				build_now->blank1 = 	NONE;
				build_now->town_number = 	the_town_number;
				build_now->worker = 	(LPLABOUR) NULL;

				//Addbuilding ( build_now );

				///now cut down trees, dry swamp land
				if (planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_PLAIN)
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
				}
				if (planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_HILL)
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  HILL;
				}
				if (( planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_SWAMP) && (planet_scaned->planet_type!=OASIS) )
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
				}
				else if (( planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_SWAMP) && (planet_scaned->planet_type==OASIS) )
				{
					  planet_scaned->planet_matrice[nx][ny]->type =  SWAMP;
				}
				if ( (planet_scaned->planet_matrice[nx][ny]->type ==  SWAMP) && (planet_scaned->planet_type!=OASIS) )
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
				}

				//link hex to planet
				planet_scaned->planet_matrice[nx][ny]->build_in_hex = build_now;

				//add structures to node lists
				if (build_now->type==FORT)
				{
					add_forts ( build_now, planet_scaned ) ;
                }
				if (build_now->type==FARM)
				{
					add_farms ( build_now, planet_scaned ) ;
                }
				if (build_now->type==PALACE)
				{
					add_palace ( build_now, planet_scaned ) ;
                }
				if (build_now->type==LAB)
				{
					add_labs ( build_now, planet_scaned ) ;
                }
				if (build_now->type==STARPORT)
				{
					add_starport ( build_now, planet_scaned ) ;
				}
				if (build_now->type==TOWN)
				{
					add_town ( build_now, planet_scaned, TOWN ) ;
				}
				if (build_now->type==FACTORY)
				{
					add_town ( build_now, planet_scaned, FACTORY ) ;
				}

				if (build_now->type==CHURCH)
				{
					add_churche ( build_now, planet_scaned ) ;
				}
				if (build_now->type==RUINS)
				{
					add_ruins ( build_now, planet_scaned ) ;
				}
				///////////////////////////
				if (build_now->type==FARM)
				{
					// if farm, flatten land
                    if (planet_scaned->planet_type != OASIS)
					{
						planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
                    }
					// scan for farm land
					planet_scan_farm_land ( planet_scaned, nx, ny );

				}
				return true;
			}

	   }
   }

return false;
}
 ////////////town growth////////////////////////
 ///////////////////////////////////////////////
///scan world for best locations
int planet_scan_town_grow ( LPplanet planet_scaned, int structure_type )
{
   int check_hex_x, check_hex_y;
   int scan_yes;
   //int Number_diferent;
   //int change_for_coast;
   int town_temp [100][100];
   char town_temp_number [100][100];
   char town_grow_from;
   int nx,ny;
   int odd_even;
   int planet_number = planet_scaned->number;
   int dice;
   int scan_value;
   int total_value=0;
   int swamp_bonus=0;
   if (planet_scaned->planet_type==OASIS)
   {
		swamp_bonus = 200;
   }

	for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   { town_temp [nx][ny] =  0; }  //set to null
   }

   for (ny=0; ny< planet_size_y; ny++)
   {
	   odd_even = (ny+1) % 2;

	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			check_hex_x = nx;
			check_hex_y = ny;
			//first work out center hex
			scan_yes = false; //default
			//scan_value = 0;   //default

			//build next to other town

			if (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL)
			{

					//if  ( planet_scaned->planet_matrice[nx][ny]->build_in_hex->type == TOWN )
					//{ scan_value=0; scan_yes = true;}
					scan_value =    0;
					scan_yes   = true;
					/////// exeption buildings:  /////
					// not if mine
					if (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex->type == MINE)
					{
						scan_yes   = false;
					}
					if (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex->type == MINE_TRACE)
					{
						scan_yes   = false;
					}
					if (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex->type == MINE_GEMS)
					{
						scan_yes   = false;
					}
					if (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex->type == MINE_HYPER_STEEL)
					{
						scan_yes   = false;
					}
					if (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex->type == MINE_CHEMY)
					{
						scan_yes   = false;
					}
					if (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex->type == MINE_RADIOACTIVE)
					{
						scan_yes   = false;
					}
					// not if well
					if (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex->type == WELL)
					{
						scan_yes   = false;
					}
			}



			//then scan neibours for adjustments on value
			if (scan_yes == true) //scan hexs only if center can build
			{
				//Number_diferent=0;
				town_grow_from=planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex->town_number;

				if ( planet_scaned->planet_matrice[nx][ny] == NULL )
				{debugfile ("error....no hex in scan town \n", planet_number );}

				/// check east hex
				 scan_value=0;
				check_hex_x = nx+1;
                if ( check_hex_x >= planet_size_x )
					 { check_hex_x = 0; }  //go round world if over
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
					 { scan_value=scan_value+100; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
					 { scan_value=scan_value+50; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
					 { scan_value=scan_value+50; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
					 { scan_value=scan_value+25; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
					 { scan_value=scan_value+20+swamp_bonus; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
					 { scan_value=scan_value+15+swamp_bonus; }

				if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
					 { scan_value=0; }

				town_temp [check_hex_x][check_hex_y] =town_temp [check_hex_x][check_hex_y] + scan_value;
				total_value=total_value+scan_value;

				town_temp_number [check_hex_x][check_hex_y] =town_grow_from;

				/// check west hex
				scan_value=0;
				check_hex_x = nx-1;
                if ( check_hex_x < 0 )
                     { check_hex_x = planet_size_x-1; }  //go round world if over
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
					 { scan_value=scan_value+100; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
					 { scan_value=scan_value+50; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
					 { scan_value=scan_value+50; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
					 { scan_value=scan_value+25; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
					 { scan_value=scan_value+20+swamp_bonus; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
					 { scan_value=scan_value+15+swamp_bonus; }
                 if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
					 { scan_value=0; }
				town_temp [check_hex_x][check_hex_y] =town_temp [check_hex_x][check_hex_y] + scan_value;
				total_value=total_value+scan_value;
				town_temp_number [check_hex_x][check_hex_y] =town_grow_from;

				/// check north west hex
				scan_value=0;
				check_hex_x = nx;
                check_hex_y = ny-1;
				if ( check_hex_y >= 0 ) //only check if not over top
				{
					 if ( odd_even == 1 )
					 {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+20+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+15+swamp_bonus; }
							if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
							{ scan_value=0; }
							town_temp [check_hex_x][check_hex_y] =  town_temp [check_hex_x][check_hex_y] + scan_value;
							total_value=total_value+scan_value;
							town_temp_number [check_hex_x][check_hex_y] =town_grow_from;
                     }
					 else
                     {
						   check_hex_x = nx-1;
                           if ( check_hex_x < 0 )
                             { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+20+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+15+swamp_bonus; }
							if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
							{ scan_value=0; }
							town_temp [check_hex_x][check_hex_y] =  town_temp [check_hex_x][check_hex_y] + scan_value;
							total_value=total_value+scan_value;
							town_temp_number [check_hex_x][check_hex_y] =town_grow_from;
					 }
				}

				/// check north east hex
				scan_value=0;
				check_hex_x = nx;
                check_hex_y = ny-1;
                if ( check_hex_y >= 0 ) //only check if not over top
                {
					 if ( odd_even == 0 )
                     {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+20+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+15+swamp_bonus; }
							if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
							{ scan_value=0; }
							town_temp [check_hex_x][check_hex_y] =  town_temp [check_hex_x][check_hex_y] + scan_value;
							total_value=total_value+scan_value;
							town_temp_number [check_hex_x][check_hex_y] =town_grow_from;
					 }
                     else
					 {
                           check_hex_x = nx+1;
                           if ( check_hex_x >= planet_size_x )
                                { check_hex_x = 0; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+20+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+15+swamp_bonus; }
							if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
							{ scan_value=0; }
							town_temp [check_hex_x][check_hex_y] =  town_temp [check_hex_x][check_hex_y] + scan_value;
							total_value=total_value+scan_value;
							town_temp_number [check_hex_x][check_hex_y] =town_grow_from;
					 }
                }


				/// check South west hex
				scan_value=0;
				check_hex_x = nx;
                check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
                {
                     if ( odd_even == 1 )
                     {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+20+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+15+swamp_bonus; }
							if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
							{ scan_value=0; }
							town_temp [check_hex_x][check_hex_y] =  town_temp [check_hex_x][check_hex_y] + scan_value;
							total_value=total_value+scan_value;
							town_temp_number [check_hex_x][check_hex_y] =town_grow_from;
					 }
                     else
                     {
                           check_hex_x = nx-1;
                           if ( check_hex_x < 0 )
                             { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+20+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+15+swamp_bonus; }
							if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
							{ scan_value=0; }
							town_temp [check_hex_x][check_hex_y] =  town_temp [check_hex_x][check_hex_y] + scan_value;
							total_value=total_value+scan_value;
							town_temp_number [check_hex_x][check_hex_y] =town_grow_from;
                     }
                }

				/// check South east hex
				scan_value=0;
				 check_hex_x = nx;
				check_hex_y = ny+1;
                if ( check_hex_y < planet_size_y ) //only check if not over bottom
                {
                     if ( odd_even == 0 )
                     {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+20+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+15+swamp_bonus; }
							if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
							{ scan_value=0; }
							town_temp [check_hex_x][check_hex_y] =  town_temp [check_hex_x][check_hex_y] + scan_value;
							total_value=total_value+scan_value;
							town_temp_number [check_hex_x][check_hex_y] =town_grow_from;
                     }
                     else
                     {
                           check_hex_x = nx+1;
                           if ( check_hex_x >= planet_size_x )
								{ check_hex_x = 0; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+20+swamp_bonus; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+15+swamp_bonus; }
							if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex != (LPbuilding) NULL )
							{ scan_value=0; }
							town_temp [check_hex_x][check_hex_y] =town_temp [check_hex_x][check_hex_y] + scan_value;
							total_value=total_value+scan_value;
							town_temp_number [check_hex_x][check_hex_y] =town_grow_from;
                     }
				}


                if ( check_hex_x < 0 ) debugfile ("error....check hex less than zero, x\n", check_hex_x );
				if ( check_hex_x >= planet_size_x ) debugfile ("error....check hex too big, x\n", check_hex_x );
			}

	   }
   }
   //now work out where town randomly is
   if (total_value==0)
   {
		 return false;
   }
   dice = random( total_value );
   int adding_value=0;
   for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			adding_value=adding_value+town_temp [nx][ny];
			if (adding_value  >  dice)
			{
				LPbuilding build_now;

				build_now = (LPbuilding) malloc( sizeof(building) );

				if ( build_now == NULL )
				return false;

                build_now->location_x=nx;
				build_now->location_y=ny;

				build_now->type =   	structure_type;
				build_now->aligence =	NUTRAL;
				build_now->population = NONE;
				build_now->blank1 = 	NONE;
				build_now->town_number =town_temp_number [nx][ny] ;
				build_now->worker = 	(LPLABOUR) NULL;

				//Addbuilding ( build_now );

				///now cut down trees, dry land
				if (planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_PLAIN)
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
				}
				if (planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_HILL)
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  HILL;
				}
				if ( (planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_SWAMP) && (planet_scaned->planet_type!=OASIS) )
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
				}
				else if ((planet_scaned->planet_matrice[nx][ny]->type ==  PLANT_SWAMP) && (planet_scaned->planet_type==OASIS))
				{
                     planet_scaned->planet_matrice[nx][ny]->type =  SWAMP;
				}
				if ( (planet_scaned->planet_matrice[nx][ny]->type ==  SWAMP) && (planet_scaned->planet_type!=OASIS) )
				{
					 planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
				}
				if (build_now->type==STARPORT)
				{
					// if starport, flatten land
					if (planet_scaned->planet_type != OASIS)
					{
						planet_scaned->planet_matrice[nx][ny]->type =  PLAIN;
					}
				}

				planet_scaned->planet_matrice[nx][ny]->build_in_hex = build_now;

				//add structures to node lists
				if (build_now->type==FORT)
				{
					add_forts ( build_now, planet_scaned ) ;
                }
				if (build_now->type==FARM)
				{
					add_farms ( build_now, planet_scaned ) ;
                }
				if (build_now->type==PALACE)
				{
					add_palace ( build_now, planet_scaned ) ;
                }
				if (build_now->type==LAB)
				{
					add_labs ( build_now, planet_scaned ) ;
                }
				if (build_now->type==STARPORT)
				{
					add_starport ( build_now, planet_scaned ) ;
				}
				if (build_now->type==TOWN)
				{
					add_town ( build_now, planet_scaned, TOWN ) ;
				}
				if (build_now->type==FACTORY)
				{
					add_town ( build_now, planet_scaned, FACTORY ) ;
				}
				if (build_now->type==CHEMY)
				{
					add_town ( build_now, planet_scaned, CHEMY ) ;
				}
				if (build_now->type==ELEC)
				{
					add_town ( build_now, planet_scaned, ELEC ) ;
				}
				if (build_now->type==STEEL)
				{
					add_town ( build_now, planet_scaned, STEEL ) ;
				}
				if (build_now->type==CHURCH)
				{
					add_churche ( build_now, planet_scaned ) ;
				}
				if (build_now->type==RUINS)
				{
					add_ruins ( build_now, planet_scaned ) ;
				}
				return true;
			}

	   }
   }
 {debugfile ("not able to place all towns \n", planet_number );}
return false;
}
///////add farm hex land/////////
int planet_place_farm_land ( LPplanet planet_scaned, int nxxx, int nyyy )
{
				LPbuilding build_now;

				build_now = (LPbuilding) malloc( sizeof(building) );

				if ( build_now == NULL )
				return false;

				build_now->location_x=nxxx;
				build_now->location_y=nyyy;

				build_now->type =   	FARM_LAND;
				build_now->aligence =	NUTRAL;
				build_now->population = NONE;
				build_now->blank1 = 	NONE;
				build_now->town_number =NONE ;
				build_now->worker = 	(LPLABOUR) NULL;

				//Addbuilding ( build_now );

				planet_scaned->planet_matrice[nxxx][nyyy]->build_in_hex = build_now;
				if (planet_scaned->planet_type != OASIS)
				{
					 planet_scaned->planet_matrice[nxxx][nyyy]->type =  PLAIN;
				}
				else
				{
					 planet_scaned->planet_matrice[nxxx][nyyy]->type =  SWAMP;
                }

				return true;
}

///////////farm land//////////
int planet_scan_farm_land ( LPplanet planet_scaned, int nx, int ny )
{
   int check_hex_x, check_hex_y;
   int scan_yes;
   int odd_even;
   int planet_number = planet_scaned->number;
   int dice;
   int scan_value=0;
   int total_value=0;

	   odd_even = (ny+1) % 2;

	   check_hex_x = nx;
	   check_hex_y = ny;
	   //first work out center hex
	   if ( planet_scaned->planet_matrice[nx][ny] == NULL )
	   {debugfile ("error....no hex in scan town \n", planet_number );}

	   /// check east hex
	   check_hex_x = nx+1;
	   if ( check_hex_x >= planet_size_x )
			{ check_hex_x = 0; }  //go round world if over
	   if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
			{
				if (planet_scaned->planet_type!=OASIS)
				{
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
                    					 { scan_value=scan_value+500; }
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
										 { scan_value=scan_value+50; }
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
										 { scan_value=scan_value+50; }
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
										 { scan_value=scan_value+25; }
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
										 { scan_value=scan_value+30; }
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
										 { scan_value=scan_value+20; }
				}
				else
				{
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
										 { scan_value=scan_value+30; }
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
										 { scan_value=scan_value+20; }
				}

					if (scan_value>0)
					{
					   scan_value=0;
					   //planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type =  PLAIN;
					   if (planet_place_farm_land ( planet_scaned,  check_hex_x,  check_hex_y ) !=true)
					   {debugfile ("error. could not place farm land \n", planet_number);}
					}

			}

				/// check west hex
			check_hex_x = nx-1;
			if ( check_hex_x < 0 )
					 { check_hex_x = planet_size_x-1; }  //go round world if over
			if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
			{
			  if (planet_scaned->planet_type!=OASIS)
				{
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
					{ scan_value=scan_value+500; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
					{ scan_value=scan_value+50; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
					{ scan_value=scan_value+50; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
					{ scan_value=scan_value+25; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
					{ scan_value=scan_value+30; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
					{ scan_value=scan_value+20; }
				}
				else
				{
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
										 { scan_value=scan_value+30; }
					if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
										 { scan_value=scan_value+20; }
				}

				if (scan_value>0)
					{
					   scan_value=0;
					   //planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type =  PLAIN;
					   if (planet_place_farm_land (  planet_scaned,  check_hex_x,  check_hex_y ) !=true)
					   {debugfile ("error. could not place farm land \n", planet_number);}
					}


			}
				/// check north west hex///////////////////////////

					check_hex_x = nx;
                                    check_hex_y = ny-1;
                    				if ( check_hex_y >= 0  ) //only check if not over top
                    				{

                    					 if ( odd_even == 1)
                    					 {
                                              if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
											  {
                                                if (planet_scaned->planet_type!=OASIS)
												{
												   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
												   { scan_value=scan_value+500; }
												   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
												   { scan_value=scan_value+50; }
												   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
												   { scan_value=scan_value+50; }
												   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
												   { scan_value=scan_value+25; }
												   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
													{ scan_value=scan_value+30; }
													if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
													{ scan_value=scan_value+20; }
												}
												else
												{
													if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
															{ scan_value=scan_value+30; }
													if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
															{ scan_value=scan_value+20; }
												}
											  }
                                         }
                    					 else
                    					 {
											check_hex_x = nx-1;
											if ( check_hex_x < 0 )
												 { check_hex_x = planet_size_x-1; }  //go round world if over
											if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
											{
                    						   if (planet_scaned->planet_type!=OASIS)
											   {
												if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
                    							{ scan_value=scan_value+500; }
                    							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
                    							{ scan_value=scan_value+50; }
                    							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
                    							{ scan_value=scan_value+50; }
                    							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
                    							{ scan_value=scan_value+25; }
												if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
													{ scan_value=scan_value+30; }
													if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
													{ scan_value=scan_value+20; }
											   }
											   else
												{
													if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
															{ scan_value=scan_value+30; }
													if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
															{ scan_value=scan_value+20; }
												}
											}
                    					 }

                    					 if (scan_value>0)
                    					{
                    					   scan_value=0;
                    					   //planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type =  PLAIN;
                    					   if (planet_place_farm_land (  planet_scaned,  check_hex_x,  check_hex_y ) !=true)
                    					   {debugfile ("error. could not place farm land \n", planet_number);}
                    					}



									}


				/// check north east hex
				check_hex_x = nx;
                check_hex_y = ny-1;
				if ( check_hex_y >= 0 ) //only check if not over top
				{
					 if ( odd_even == 0 )
                     {
                         if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
						 {
						  if (planet_scaned->planet_type!=OASIS)
						  {
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+500; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+30; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+20; }
						  }
						  else
							{
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
															{ scan_value=scan_value+30; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
															{ scan_value=scan_value+20; }
							}
						 }
                     }
					 else
					 {

							   check_hex_x = nx+1;
							   if ( check_hex_x >= planet_size_x )
							   { check_hex_x = 0; }  //go round world if over
						 if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
						 {
							if (planet_scaned->planet_type!=OASIS)
							{
							   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
                               							{ scan_value=scan_value+500; }
							   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
                               							{ scan_value=scan_value+50; }
							   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
                               							{ scan_value=scan_value+50; }
							   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
														{ scan_value=scan_value+25; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
													{ scan_value=scan_value+30; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
													{ scan_value=scan_value+20; }
							}
							else
							{
									if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
															{ scan_value=scan_value+30; }
									if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
															{ scan_value=scan_value+20; }
							}
						  }
					 }

                     if (scan_value>0)
					{
					   scan_value=0;
					   //planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type =  PLAIN;
					   if (planet_place_farm_land (  planet_scaned, check_hex_x,  check_hex_y ) !=true)
					   {debugfile ("error. could not place farm land \n", planet_number);}
					}


                }


				/// check South west hex
				check_hex_x = nx;
                check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
				{

					 if ( odd_even == 1 )
					 {

                             if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
							{
								if (planet_scaned->planet_type!=OASIS)
								{
                                   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
								   { scan_value=scan_value+500; }
								   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
								   { scan_value=scan_value+50; }
								   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
								   { scan_value=scan_value+50; }
								   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
								   { scan_value=scan_value+25; }
								   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
													{ scan_value=scan_value+30; }
									if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
													{ scan_value=scan_value+20; }
								}
								else
								{
									if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
															{ scan_value=scan_value+30; }
									if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
															{ scan_value=scan_value+20; }
								}
							}

					 }
                     else
					 {
						   check_hex_x = nx-1;
						   if ( check_hex_x < 0 )
							 { check_hex_x = planet_size_x-1; }  //go round world if over
						 if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
						 {
						   if (planet_scaned->planet_type!=OASIS)
						   {
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+500; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+30; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+20; }
						   }
						   else
							{
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
															{ scan_value=scan_value+30; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
															{ scan_value=scan_value+20; }
							}
						 }
					 }

					 if (scan_value>0)
					{
					   scan_value=0;
					   //planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type =  PLAIN;
					   if (planet_place_farm_land (  planet_scaned,  check_hex_x,  check_hex_y ) !=true)
					   {debugfile ("error. could not place farm land \n", planet_number);}
					}

				}

				/// check South east hex
				check_hex_x = nx;
				check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
                {

					 if ( odd_even == 0 )
					 {
						if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
						{

						  if (planet_scaned->planet_type!=OASIS)
						  {
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
							{ scan_value=scan_value+500; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
							{ scan_value=scan_value+50; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
							{ scan_value=scan_value+25; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
							{ scan_value=scan_value+30; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
							{ scan_value=scan_value+20; }
						  }
						  else
						  {
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
															{ scan_value=scan_value+30; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
															{ scan_value=scan_value+20; }
						  }
						}
					 }
					 else
					 {
						   ////////////debug/////////

						   check_hex_x = nx+1;
						   if ( check_hex_x >= planet_size_x )
						   { check_hex_x = 0; }  //go round world if over

						 if  ( planet_scaned->planet_matrice[check_hex_x][check_hex_y]->build_in_hex == (LPbuilding) NULL )
						 {
                            if (planet_scaned->planet_type!=OASIS)
							{
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLAIN )
								{ scan_value=scan_value+500; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == HILL )
								{ scan_value=scan_value+50; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_PLAIN )
								{ scan_value=scan_value+50; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_HILL )
								{ scan_value=scan_value+25; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
									{ scan_value=scan_value+30; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
								{ scan_value=scan_value+20; }
							}
							else
							{
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SWAMP )
															{ scan_value=scan_value+30; }
								if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == PLANT_SWAMP )
															{ scan_value=scan_value+20; }
							}
						 }


						   ////////////////////////////
					 }

                     if (scan_value>0)
					{
					   scan_value=0;
					   //planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type =  PLAIN;
					   if (planet_place_farm_land (  planet_scaned,  check_hex_x,  check_hex_y ) !=true)
					   {debugfile ("error. could not place farm land \n", planet_number);}
					}



				}


				if ( check_hex_x < 0 ) debugfile ("error....check hex less than zero, x\n", check_hex_x );
				if ( check_hex_x >= planet_size_x ) debugfile ("error....check hex too big, x\n", check_hex_x );


   return true;
}


