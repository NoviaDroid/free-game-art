

void FillScreen(void)
{
   //OutputDebugString( "Color fill...\n" );

   ZeroMemory( &ddbltfx, sizeof( ddbltfx ) );
   ddbltfx.dwSize = sizeof( ddbltfx );

   // Fill the surface with background colour .
   ddbltfx.dwFillColor = dwBackground;
   lpDDSOffScreen->Blt( NULL, NULL,        // black out screen
							NULL,
						DDBLT_COLORFILL |
						DDBLT_WAIT, &ddbltfx );
}

void FillMap(void)
{
   OutputDebugString( "Color fill...\n" );

   ZeroMemory( &ddbltfx, sizeof( ddbltfx ) );
   ddbltfx.dwSize = sizeof( ddbltfx );

   // Fill the surface with background colour .
   ddbltfx.dwFillColor = dwBackground;
	lpDDSOffMap->Blt( NULL, NULL,           //  black out map off surface
   						NULL,
                     DDBLT_COLORFILL |
                     DDBLT_WAIT, &ddbltfx );
}

void SmalleStarsOnMap(void)
{
			//  set star possitions on map surface
         int xxx,yyy;
         double MapAjuster=GalaxySize/280;

         for (int n=0; n<NumberStars; n++)    //  1000 is number of stars
      			{
            		xxx = (star[n].x/MapAjuster)* (Small_Place);
            		yyy = (star[n].y/MapAjuster)* (Small_Place);

            		if (star[n].size==TINY_STAR)
            			{
          					lpDDSOffMap->BltFast( xxx,yyy , lpDDSOffSmaleStars,
                        						&rcRectAstar,           // left
                                           DDBLTFAST_WAIT |
                                           DDBLTFAST_SRCCOLORKEY );
               		}
            		if (star[n].size==SMALLE_STAR)
            			{
    							lpDDSOffMap->BltFast( xxx,yyy , lpDDSOffSmaleStars,
                        						&rcRectBstar,            // right
                                           DDBLTFAST_WAIT |
                                           DDBLTFAST_SRCCOLORKEY );
               		}
            		if (star[n].size==MEDIUM_STAR)
            			{
     							lpDDSOffMap->BltFast( xxx,yyy , lpDDSOffSmaleStars,
                        						&rcRectCstar,             // top
                                           DDBLTFAST_WAIT |
                                           DDBLTFAST_SRCCOLORKEY );
               		}
            		if (star[n].size==LARGE_STAR)
            			{
     							lpDDSOffMap->BltFast( xxx,yyy , lpDDSOffSmaleStars,
                        						&rcRectDstar,          // bottom
                                           DDBLTFAST_WAIT |
                                           DDBLTFAST_SRCCOLORKEY );
               		}

         		}
}

void PlaceSmalleMap(int ZoomXpos,int ZoomYpos)			  // smale map stars
{
                      /*
                lpDDSOffScreen->BltFast( 513,313 , lpDDSOffMap, NULL,
               										   DDBLTFAST_WAIT |
               										   DDBLTFAST_SRCCOLORKEY );

               			lpDDSOffScreen->BltFast( ZoomXpos-14,ZoomYpos-14 ,
               													lpDDSOffSmaleStars,
               													&rcRectZoom,
               										  DDBLTFAST_WAIT |
               										  DDBLTFAST_SRCCOLORKEY );
           */
            ViewerType=MAP;
}

void PlaceMap1x(int ZoomXpos,int ZoomYpos)
{

   double MapAjuster=GalaxySize/(280); int minX, minY, maxX, maxY;
   minX= ((ZoomXpos-513-14)/Small_Place  )*MapAjuster;
   minY= ((ZoomYpos-313-14)/Small_Place  )*MapAjuster;

   for (int n=0; n<NumberStars; n++)
   	{
      if (  (star[n].x > minX-2)  &&   (star[n].y > minY-2)   )
      	{
         	lpDDSOffScreen->BltFast( (star[n].x -minX)*4,
            									((star[n].y -minY)*4)+100 ,
                                        lpDDSOffSmaleStars, &rcRectDstar,
                                        DDBLTFAST_WAIT |
                                        DDBLTFAST_SRCCOLORKEY 	);
         }
      }
}

void Jump(float minX,float minY,float maxX,float maxY)     // jump routs seen
{  // jump 3
   int hitstar=false; float calculatedX; float calculatedY;
	for (int n=0; n<NumberStars; n++)         // jump3 range
   	{

      	if (  (star[n].x > minX-240) && (star[n].x < maxX+120) &&
            		(star[n].y > minY-120) && (star[n].y < maxY+240)  )
         	{
            	rcRectJump3.top=0; rcRectJump3.bottom=239;
               rcRectJump3.left=0; rcRectJump3.right=239;
               if (hitstar!=true)	{  hitstar=true; firstx=n;  }

               calculatedX=(((star[n].x -minX)*MapSet)-120.0);
               calculatedY=(((star[n].y -minY)*MapSet)+100.0-120.0);
               if (  (calculatedX>-240) && (calculatedY>-240)  )
                     {
                     	if  (calculatedX<0)
                        	{rcRectJump3.left=abs(calculatedX); calculatedX=0;}
                        if  (calculatedY<0)
                        	{rcRectJump3.top=abs(calculatedY);calculatedY=0;}
                        if  (calculatedX>480-240+(12))
                        	{rcRectJump3.right=240+(12)+(480-240-calculatedX);}
                        if  (calculatedY>599-240)
                        	{rcRectJump3.bottom=240+(599-240-calculatedY);}
                        //lpDDSOffScreen->BltFast( calculatedX, calculatedY ,
                        //									lpDDSOffJump3,
                        //                           &rcRectJump3,
                         //                  			DDBLTFAST_WAIT |
                         //                          DDBLTFAST_SRCCOLORKEY );
                     }
					lastx=n;
				}
		}

	// jump 2
	for (int n=firstx; n<=lastx; ++n)         // jump2 range
   	{
          	if (  (star[n].x > minX-160) && (star[n].x < maxX+80) &&
            		(star[n].y > minY-80) && (star[n].y < maxY+160)  )
            		{
            			rcRectJump2.top=0; rcRectJump2.bottom=159;
                     rcRectJump2.left=0; rcRectJump2.right=159;

                     calculatedX=(((star[n].x -minX)*MapSet)-80);
                     calculatedY=(((star[n].y -minY)*MapSet)+100-80);

                     if (  (calculatedX>-160) && (calculatedY>-160)  )
                     {
                     	if  (calculatedX<0)
                        	{rcRectJump2.left=abs(calculatedX); calculatedX=0;}
                        if  (calculatedY<0)
                        	{rcRectJump2.top=abs(calculatedY);calculatedY=0;}
                        if  (calculatedX>480-160+(12))
                        	{rcRectJump2.right=160+(12)+(480-160-calculatedX);}
                        if  (calculatedY>599-160)
                        	{rcRectJump2.bottom=160+(599-160-calculatedY);}
                        //lpDDSOffScreen->BltFast( calculatedX, calculatedY ,
                        // 									lpDDSOffJump2, &rcRectJump2,
                        //                   			DDBLTFAST_WAIT |
                        //                  			 DDBLTFAST_SRCCOLORKEY );
                     }
    					}
   	}

	// jump 1
	for (int n=firstx; n<=lastx; ++n)         // jump1 range
          {
          if (  (star[n].x > minX-80) && (star[n].x < maxX+40) &&
            		(star[n].y > minY-40) && (star[n].y < maxY+80)  )
            		{
                  	rcRectJump1.top=0; rcRectJump1.bottom=79;
                     rcRectJump1.left=0; rcRectJump1.right=79;

                     calculatedX=(((star[n].x -minX)*MapSet)-40);
                     calculatedY=(((star[n].y -minY)*MapSet)+100-40);

                     if (  (calculatedX>-80) && (calculatedY>-80)  )
                     {
                     	if  (calculatedX<0)
                        	{rcRectJump1.left=abs(calculatedX); calculatedX=0;}
                        if  (calculatedY<0)
                        	{rcRectJump1.top=abs(calculatedY);calculatedY=0;}
                        if  (calculatedX>480-80+(12))
                        	{rcRectJump1.right=80+(12)+(480-80-calculatedX);}
                        if  (calculatedY>599-80)
                        	{rcRectJump1.bottom=80+(599-80-calculatedY);}
                        //lpDDSOffScreen->BltFast( calculatedX, calculatedY ,
                        //									lpDDSOffJump1, &rcRectJump1,
                        //                   			DDBLTFAST_WAIT |
                        //                   			DDBLTFAST_SRCCOLORKEY );
                     }
    					}
			}
}

void Map8xBackground(int ZoomXposition,int ZoomYposition)
{
	// large map stars on smalle map ( background stars )
		 double MapAjuster=GalaxySize/280; float minX, minY, maxX, maxY, Xpos, Ypos;
		/*
		minX= (ZoomXposition-513-14)*MapAjuster;
		 minY= (ZoomYposition-313-14)*MapAjuster;
		 maxX= (ZoomXposition-513+28-1)*MapAjuster;
		 maxY= (ZoomYposition-313+28-1)*MapAjuster;
	   */

		 //minX= ((ZoomXposition-513.0-14.0)/Small_Place  )*MapAjuster;
		 minX= ((ZoomXposition-113.0-14.0)/Small_Place  )*MapAjuster;

		 //minY= ((ZoomYposition-313.0-14.0)/Small_Place  )*MapAjuster;
		 minY= ((ZoomYposition-113.0-14.0)/Small_Place  )*MapAjuster;
		 //maxX= ((ZoomXposition-513+7-1)/Small_Place  )*MapAjuster;
		 //maxY= ((ZoomYposition-313+7-1)/Small_Place  )*MapAjuster;

		 int dice;

		 for (int n=0; n<NumberStars; n++)
			{
			//////////////// tile 2*2 //////////////
			for (int nx=0; nx<6 ; nx++)
			  {
				 for (int ny=0; ny<6 ; ny++)
				 {
					dice=1+(random(1000));             //  thousand sided die
					//if (  (star[n].x > minX-2)  &&   (star[n].y > minY-2)  )
					{
					   Xpos= ( (star[n].x -minX )*4     )+(nx * X_size *4);
					   Ypos= ( ((star[n].y -minY)*4)    )+(ny * Y_size *4);

					   if (star[n].size==TINY_STAR)
							{
								if (dice<998)
									{
										lpDDSOffScreen->BltFast( Xpos,
															Ypos,
														lpDDSOffSmaleStars,
														&rcRectAstar, // left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY);
									}
								else
									{
										lpDDSOffScreen->BltFast( Xpos,
															Ypos,
													   lpDDSOffSmaleStars,
													   &rcRectCstar, // left
													   DDBLTFAST_WAIT |
													   DDBLTFAST_SRCCOLORKEY );
									}
							}
            				if (star[n].size==SMALLE_STAR)
						   {
								if (dice<998)
									{
										lpDDSOffScreen->BltFast( Xpos,
														   Ypos,
													  lpDDSOffSmaleStars,
													  &rcRectBstar, // left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY );
									}
								else
									{
										lpDDSOffScreen->BltFast( Xpos,
															Ypos,
													  lpDDSOffSmaleStars,
													  &rcRectDstar,// left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY );
									}
               				}
							if (star[n].size==MEDIUM_STAR)
						   {
								if (dice<998)
									{
										lpDDSOffScreen->BltFast( Xpos,
															Ypos,
													   lpDDSOffSmaleStars,
													   &rcRectCstar, // left
													   DDBLTFAST_WAIT |
													   DDBLTFAST_SRCCOLORKEY );
									}
								else
									{
										lpDDSOffScreen->BltFast( Xpos,
															Ypos,
														lpDDSOffSmaleStars,
														&rcRectAstar, // left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY);
									}
							}
							if (star[n].size==LARGE_STAR)
						   {
								if (dice<998)
									{
										lpDDSOffScreen->BltFast( Xpos,
															Ypos,
													  lpDDSOffSmaleStars,
													  &rcRectDstar,// left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY );
									}
								else
									{
										lpDDSOffScreen->BltFast( Xpos,
														   Ypos,
													  lpDDSOffSmaleStars,
													  &rcRectBstar, // left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY );
									}
							}
						}
			 //////////////////
				   }
			   }

			}
}

void StarBackground(int Xposition,int Yposition)
{
	// large map stars on smalle map ( background stars for worlds)


		 int Xpos;
		 int Ypos;
		 int dice;

		 for (int n=NumberStars; n>0; n--)
			{
			//////////////// tile 2*2 //////////////
			for (int nx=0; ; nx++)
			  {
				 if  ( Xposition +(nx * X_size *3) > screen_x ) break;
				 for (int ny=0;  ; ny--)
				 {
					//if  ( Yposition +(ny * Y_size *3) < ((ny * Y_size *3) ) )break;
					//if (  (star[n].x > minX-2)  &&   (star[n].y > minY-2)  )
					{
					   Xpos= (( (star[n].x  )*3    )) + Xposition +(nx * X_size *3)  ;
					   Ypos= (( ((star[n].y)*3)    )) + Yposition +(ny * Y_size *3)  ;
						dice=1+(random(1000));             //  thousand sided die
						if (star[n].size==TINY_STAR)
							{
								if (dice<999)
									{
										lpDDSBack->BltFast( Xpos,
															Ypos,
														lpDDSOffSmaleStars,
														&rcRectAstar, // left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY);
									}
								else
									{
										lpDDSBack->BltFast( Xpos,
															Ypos,
													   lpDDSOffSmaleStars,
													   &rcRectCstar, // left
													   DDBLTFAST_WAIT |
													   DDBLTFAST_SRCCOLORKEY );
									}
							}
            				if (star[n].size==SMALLE_STAR)
						   {
								if (dice<999)
									{
										lpDDSBack->BltFast( Xpos,
														   Ypos,
													  lpDDSOffSmaleStars,
													  &rcRectBstar, // left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY );
									}
								else
									{
										lpDDSBack->BltFast( Xpos,
															Ypos,
													  lpDDSOffSmaleStars,
													  &rcRectDstar,// left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY );
									}
               				}
							if (star[n].size==MEDIUM_STAR)
						   {
								if (dice<999)
									{
										lpDDSBack->BltFast( Xpos,
															Ypos,
													   lpDDSOffSmaleStars,
													   &rcRectCstar, // left
													   DDBLTFAST_WAIT |
													   DDBLTFAST_SRCCOLORKEY );
									}
								else
									{
										lpDDSBack->BltFast( Xpos,
															Ypos,
														lpDDSOffSmaleStars,
														&rcRectAstar, // left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY);
									}
							}
							if (star[n].size==LARGE_STAR)
						   {
								if (dice<999)
									{
										lpDDSBack->BltFast( Xpos,
															Ypos,
													  lpDDSOffSmaleStars,
													  &rcRectDstar,// left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY );
									}
								else
									{
										lpDDSBack->BltFast( Xpos,
														   Ypos,
													  lpDDSOffSmaleStars,
													  &rcRectBstar, // left
														DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY );
									}
							}
							if  ( (Ypos<0) && (ny< -1) )break;
						}
			 //////////////////
				   }
			   }

			}
}


void Map8xStarsWorlds(float minX,float minY,float maxX,float maxY)
{
	int WorldClickedOn=false;
	int NumWorldClickedOn;

	for (int n=0; n<70; n++)                    // set screen map to zero
	{
			for (int m=0; m<70; m++)
				{   screenMap[n][m]=0;  }
	}
	// first place huge worlds, then big, then meduim then smalle
	for (int doing_size = 1; doing_size <= 5; doing_size++)
	{
		for (int n=firstx; n<=lastx; ++n)        			// stars or worlds

		  if ( star [n].worldSize ==  doing_size)
		  {
			if (  (star[n].x > minX-2) && (((star[n].x -minX)*MapSet)-GlobeSet<(screen_x+170)) &&
				  (star[n].y > minY-2) && (((star[n].y -minY)*MapSet)-GlobeSet<(screen_y+170)  ) )
					{
               		      /*
                               lpDDSOffScreen->BltFast( ((star[n].x -minX)*MapSet)-3,
                     										((star[n].y -minY)*MapSet)+100-3,
                                                   	lpDDSOffSmaleStars,
                                                      &rcRectHstar,
                                           				DDBLTFAST_WAIT |
														DDBLTFAST_SRCCOLORKEY );
							*/
							rcRectHstar.top=     (star[n].globeY) * (170);
							rcRectHstar.bottom= ((star[n].globeY) * (170))+170;
							rcRectHstar.left=    (star[n].globeX) * (170);
							rcRectHstar.right=   ((star[n].globeX)* (170))+170;

							//rcRect.left=   ((star[n].x -minX)*MapSet)-GlobeSet;
							//rcRect.top=  ((star[n].y -minY)*MapSet)-GlobeSet;
							rcRect.left=   ((star[n].x -minX)*MapSet)-(170/star [n].worldSize)/2;
							rcRect.top=  ((star[n].y -minY)*MapSet)-(170/star [n].worldSize)/2;
							rcRect.bottom=   rcRect.top+(170/star [n].worldSize);
							rcRect.right=    rcRect.left+(170/star [n].worldSize);

							if (rcRect.left<0 && rcRect.right>0)
							{
								 rcRectHstar.left =rcRectHstar.left+((0+(rcRect.left*-1))*star [n].worldSize);
								 rcRect.left=0;
							}
							if (rcRect.bottom>0 && rcRect.top<0  )
							{

								 rcRectHstar.top= rcRectHstar.top+((0+(rcRect.top*-1))*star [n].worldSize);
								 rcRect.top=0;
							}
							if (rcRect.bottom>screen_y  &&  rcRect.top<screen_y)
							{
								 rcRectHstar.bottom= rcRectHstar.bottom-((rcRect.bottom-screen_y)*star [n].worldSize);
								 rcRect.bottom=screen_y;
							}
							if (rcRect.right>screen_x && rcRect.left<screen_x)
							{
								 rcRectHstar.right=rcRectHstar.right-((rcRect.right-screen_x)*star [n].worldSize);
								 rcRect.right=screen_x;
							}

							//// see if clicked cursor over world ///////
								if  (LMouseDown==true)          	// if click on star
							{
								if (    (xPos<rcRect.right ) && (xPos>rcRect.left)  &&
										(yPos<rcRect.bottom) && (yPos>rcRect.top )     )
								{
									 WorldClickedOn=true;
									 NumWorldClickedOn=n;
									 //LMouse_triger=false;
								}

							}

							 /*
							 if (rcRect.right>screen_x  &&  rcRect.left<screen_x)
					{rcRectGet.right =240-((rcRect.right-screen_x)*ZooM);rcRect.right=screen_x;}
			if (rcRect.right>0  &&  rcRect.left<0)
					{rcRectGet.left =((0+(rcRect.left*-1))*ZooM);rcRect.left=0; }

							if (rcRect.bottom>screen_y  &&  rcRect.top<screen_y)
					{rcRectGet.bottom =240-((rcRect.bottom-screen_y)*ZooM);rcRect.bottom=screen_y;}
				  if (rcRect.bottom>0  &&  rcRect.top<0)



							 lpDDSBack->Blt( &rcRect , lpDDSOffPlain, &rcRectGet,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );

								dice=(1+(random(3)));
								star [n].worldSize=dice;
							rcRectHstar.top=     0;
							rcRectHstar. bottom= 171;
							rcRectHstar.left=    0;
							rcRectHstar.right=   171;
							  */
							if (star [n].planet_surface->planet_type==TEMP)
							{
									lpDDSOffScreen->Blt(   &rcRect,
															lpDDSOffWorlds1,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC,NULL );
							}

							if (star [n].planet_surface->planet_type==LAVA)
							{
									lpDDSOffScreen->Blt( 	&rcRect,
															lpDDSOffWorlds2,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC,NULL );
							}

							if (star [n].planet_surface->planet_type==ICE)
							{
									lpDDSOffScreen->Blt( 	&rcRect,
															lpDDSOffWorlds3,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC, NULL );
							}

							if (star [n].planet_surface->planet_type==DESERT)
							{
									lpDDSOffScreen->Blt( 	&rcRect,
															lpDDSOffWorlds4,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC, NULL );
							}
							if (star [n].planet_surface->planet_type==OASIS)
							{
									lpDDSOffScreen->Blt( 	&rcRect,
															lpDDSOffWorlds4,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC, NULL );
							}

							if (star [n].planet_surface->planet_type==EXOTIC)
							{
									lpDDSOffScreen->Blt( 	&rcRect,
															lpDDSOffWorlds5,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC, NULL );
							}

							if (star [n].planet_surface->planet_type==SWAMP)
							{
									lpDDSOffScreen->Blt( 	&rcRect,
															lpDDSOffWorlds7,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC, NULL );
							}

							if (star [n].planet_surface->planet_type==JUNGLE)
							{
									lpDDSOffScreen->Blt( 	&rcRect,
															lpDDSOffWorlds8,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC, NULL );
							}

							if (star [n].planet_surface->planet_type==ISLE)
							{
									lpDDSOffScreen->Blt( 	&rcRect,
															lpDDSOffWorlds6,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC, NULL );
							}

							if (star [n].planet_surface->planet_type==MOON)
							{
									lpDDSOffScreen->Blt( 	&rcRect,
															lpDDSOffWorlds9,
															&rcRectHstar,
															DDBLT_WAIT |
															DDBLT_KEYSRC, NULL );
							}
														/*
								lpDDSOffScreen->BltFast( ((star[n].x -minX)*MapSet)-GlobeSet,
																							((star[n].y -minY)*MapSet)-GlobeSet,
																					lpDDSOffGlobes,
																					  &rcRectHstar,
																						DDBLTFAST_WAIT |
																						DDBLTFAST_SRCCOLORKEY );
                            */

          				int temp_intx= (star[n].x -minX+1);int temp_inty= (star[n].y -minY+1);
                		screenMap[temp_intx][temp_inty]=n;

                     // world names
                     //if (star[n].alien==true)    // print only if alien world
                     {
					 for (int letterNumber=0; letterNumber< strlen(star[n].name); ++letterNumber)
						{
						   if (star[n].name[letterNumber]>='0' && star[n].name[letterNumber]<='9' )
						   {
								rcRectLetters.left=(star[n].name[letterNumber]-47)*9+1;
								rcRectLetters.right=
											(star[n].name[letterNumber]+1-47)*9+1;
						   }
						   else if (star[n].name[letterNumber]>='A' && star[n].name[letterNumber]<='Z' )
						   {
								rcRectLetters.left=(star[n].name[letterNumber]-47-7)*9+1;
								rcRectLetters.right=
											(star[n].name[letterNumber]+1-47-7)*9+1;
						   }
						   else if (star[n].name[letterNumber]>='a' && star[n].name[letterNumber]<='z' )
						   {
								rcRectLetters.left=(star[n].name[letterNumber]-47-7-6)*9+1;
								rcRectLetters.right=
											(star[n].name[letterNumber]+1-47-7-6)*9+1;
						   }
						   else
						   {
								rcRectLetters.left=0;
								rcRectLetters.right=9;

                           }

						   rcRectLetters.top=0;      ///default
						   rcRectLetters.bottom=15;  ///default

						   if (star[n].owner==NUTRAL)
						   {
							   rcRectLetters.top=84;
							   rcRectLetters.bottom=97;
						   }
						   if (star[n].owner==HIGH_STEWARD)
						   {
							   rcRectLetters.top=56;
							   rcRectLetters.bottom=69;
						   }
						   if (star[n].owner==GUILD)
						   {
							   rcRectLetters.top=140;
							   rcRectLetters.bottom=153;
						   }
						   if (star[n].owner==RED)
						   {
							   rcRectLetters.top=14;
							   rcRectLetters.bottom=27;
						   }
						   if (star[n].owner==ALIEN)
						   {
							   rcRectLetters.top=70;
							   rcRectLetters.bottom=83;
						   }
						   if (star[n].owner==BLEU)
						   {
							   rcRectLetters.top=42;
							   rcRectLetters.bottom=55;
						   }
						   if (star[n].owner==YELLOW)
						   {
							   rcRectLetters.top=28;
							   rcRectLetters.bottom=41;
						   }
						   if (star[n].owner==ORANGE)
						   {
							   rcRectLetters.top=98;
							   rcRectLetters.bottom=111;
						   }
						   if (star[n].owner==GREEN)
						   {
							   rcRectLetters.top=112;
							   rcRectLetters.bottom=125;
						   }
						   //rcRectLetters.left=star[n].name[letterNumber]*9+1;
						   //rcRectLetters.right=
						   //					(star[n].name[letterNumber]+1)*9+1;
                           lpDDSOffScreen->BltFast( ((star[n].x -minX)*MapSet)
                           						+4+(letterNumber*9)
                                             -(((strlen(star[n].name)+1)*9)/2),
											 ((star[n].y -minY)*MapSet)-3+8,
                                             lpDDSOffLetters, &rcRectLetters,
                                           	DDBLTFAST_WAIT |
                                           	DDBLTFAST_SRCCOLORKEY );
                        }
                     }

               	}
			  }
		  }

	if (WorldClickedOn==true)
	{
           JUST_ONCE=true;
		   ORBITAL_VIEW=true;
		   DRAWN_PLANET_MAP=false;

		   ScreenType=WORLD;

		   LMouse_triger      = false;

		   planet_see_x= screen_x;
		   planet_see_y= screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);
		   //planet_see_x= 1240;
		   //planet_see_y= -240;
		   planet_draw=NumWorldClickedOn;
		   LPplanet planet=star[planet_draw].planet_surface;
		   Draw_the_World(planet,planet_see_x,planet_see_y);

		   DRAWN_PLANET_MAP=true;

		   return;
	}
}

void PlaceMap8x(int ZoomXpos,int ZoomYpos)
{
/*
   double MapAjuster=(GalaxySize/280);
   int minX= ((ZoomXpos-513-14)*MapAjuster);
   ((ZoomXpos-513-14)/Small_Place  )*MapAjuster;
   int minY= ((ZoomYpos-313-14)*MapAjuster);
   int maxX= ((ZoomXpos-513+7-1)*MapAjuster);
   int maxY= ((ZoomYpos-313+7-1)*MapAjuster);
 */

   double MapAjuster=(GalaxySize/280);
   float minX= 1.0*((ZoomXpos-513.0-14.0)/Small_Place  )*MapAjuster;
   float minY= 1.0*((ZoomYpos-313.0-14.0)/Small_Place  )*MapAjuster;
   float maxX= 1.0*((ZoomXpos-513.0+7.0-1.0)/Small_Place  )*MapAjuster;
   float maxY= 1.0*((ZoomYpos-313.0+7.0-1.0)/Small_Place  )*MapAjuster;

   Jump(minX,minY,maxX,maxY);
   Place_Nebula (ZoomXpos,ZoomYpos);
   Map8xBackground(ZoomXpos,ZoomYpos);
   Place_GasGiant (ZoomXpos,ZoomYpos);
   Map8xStarsWorlds(minX,minY,maxX,maxY);

}



/////////////////////////////////
int Zoom_Routine_on_Selection (int T)
{

	double Time_at= 0.0+(dwCopy_time - dwCursor_Zoom_Time_Start) ;
	if ( (Cursor_Type != NONE ) && ( ZooM<2 ) )
		{
			ZooM = 1.0 + (Time_at/1000);
			if (ZooM > 2) { ZooM=2;}
			//ZooM = 2;
			return true;
		}
	else {return false;}

}
