void SetUpSystem (void)
{
    SolarSystem(true);
   //PlaceSmalleMap( Zoomx,Zoomy  );
   GetWorldInfo(CheckSystem.starSeed,CheckSystem.StarNumber);
   GetWorldTerre(CheckSystem.starSeed,CheckSystem.StarNumber);
}

void UpdateSystem (void)
{
	int py; int px;
	float typeOfMap=480.0/277.0;
   int MapXCenter=(480/2+6);	int MapYCenter=(480/2+110);
 // if mouse in smalle screen
	if  (( xPos>513 && yPos>313 ))
   	{
        ScreenType=MAP;
        SetUpMap (Zoomx,Zoomy);
        UpdateMap ();
        return;
      }

   // if mouse in large screen
/*
       if (  (xPos<486) && (yPos>109) )
    	{  for (int n=1;n<5;n++)
    		{
    			if (  (xPos<CheckSystem.posNOWx[n]+10) && (xPos>CheckSystem.posNOWx[n]-10)
    				&&	(yPos<CheckSystem.posNOWy[n]+10) && (yPos>CheckSystem.posNOWy[n]-10)	)
    			  { // draw world map
    				  DrawWorld(CheckSystem.StarNumber);
    			  }
			 }
		  }
*/

   // place czars screen memory into back buffer, ready for flip
   lpDDSBack->BltFast( 0,0 , lpDDSOffScreen, NULL,
                                           DDBLTFAST_WAIT |
                                           DDBLTFAST_SRCCOLORKEY );

   // animation here........

   py=((yPos-110)+22)/MapSet; px=((xPos)+12)/MapSet;
   InSolar(typeOfMap, MapXCenter, MapYCenter,px,py);
}

 ////////////////////ScreenType=WORLD////////////////
void UpdateWorld (void)
{


	int LMousexDif=0;
	int LMouseyDif=0;

	if  ( space_key_down==true )
	{
		space_key_down=false;
		town_view_on_off=false;
		work_view_on_off=false;
		LMouseBeenUsed=false;
		Cursor_Type=NONE;
		ScreenType=MAP;
		return;
	}

	if  ( LMouseDown==true )     //the scroll
	{


		   //	LMousexPos=xPos;
		   //	LMouseyPos=yPos;

		   if (Mouse_Start_Move==true)
		   {
				Old_LMousexPos=xPos;
				Old_LMouseyPos=yPos;
				Mouse_Start_Move=false;
		   }

		   LMousexDif=xPos-Old_LMousexPos;
		   LMouseyDif=yPos-Old_LMouseyPos;

		   planet_see_x= planet_see_x+LMousexDif;
		   planet_see_y= planet_see_y+LMouseyDif;
		   Old_LMousexPos=xPos;
		   Old_LMouseyPos=yPos;

	}
	else
	{
			Old_LMousexPos=xPos;
			Old_LMouseyPos=yPos;
			LMousexDif=0;
			LMouseyDif=0;
			Mouse_Start_Move=true;
	}
	//planet_see_x= screen_x*2;

	if (planet_see_x<screen_x)  // if need dawing on x coordinats beyond
	{

		//int planet_see_x_tile=planet_see_x+(hex_size_x*planet_size_x);
		//Draw_the_World ( star [planet_draw].planet_surface, planet_see_x, planet_see_y );
		int num_rolls=0;
		int see_for_rolls=planet_see_x;
		for ( ; ; )
		{

			if (see_for_rolls>=screen_x)
			{
				break;
			}
			else
            {
				num_rolls++;
				see_for_rolls=see_for_rolls+((210/ZooM)*planet_size_x);
			}

		}

		Draw_the_World ( star [planet_draw].planet_surface, planet_see_x+(((210/ZooM)*planet_size_x)*num_rolls), planet_see_y );
	}

	else Draw_the_World ( star [planet_draw].planet_surface, planet_see_x, planet_see_y );

}
