void GetStarSystem(int Rnumber,int worldnumber)
	{
      srand(Rnumber);
   	  int dice; int binarySize;int binaryBrightness; int difsize;
      int starOrbit; int BstarOrbit;
      int orbit[5];
      int worldsorbit= star[worldnumber].worldOrbit;
      int TypeOfWorld= star[worldnumber].worldType;
      int starsize=    star[worldnumber].size;
      int starsizeAjust;

      if (starsize==TINY_STAR)	{	starsizeAjust=1;	}
      if (starsize==SMALLE_STAR)	{	starsizeAjust=2;	}
      if (starsize==MEDIUM_STAR)	{	starsizeAjust=3;	}
      if (starsize==LARGE_STAR)	{	starsizeAjust=4;	}
      //star companion
      dice=(1+(random(6)))+(1+(random(6)));   //  two six sided die
      if (dice>=8)
      	{
      	//companion size
      	binarySize=((1+random(3))*4);
      	if (binarySize>starsize) { binarySize=starsize;}
         difsize=starsize-binarySize;
         if (difsize==0) { BstarOrbit=starsize/1.5;starOrbit=starsize/1.5;}
         else {BstarOrbit=binarySize*1.8; starOrbit= 0;}

      	// companion spectrum
      	dice=1+(random(100));             //  hundred sided die
      	if (dice<60)                      //  simple spectral generater
      		{
     	 			binaryBrightness=1;               // red
      		}
         if (dice>=60 && dice<85)
      		{
     				 binaryBrightness=2;               // orange
      		}
         if (dice>=85 && dice<95)
      		{
      			binaryBrightness=3;               // yellow
      		}
         if (dice>=95 && dice<99)
      		{
      			binaryBrightness=4;             // blue

      		}
         if (dice>=99)
      		{
      			binaryBrightness=5;              // white

      		}

      	}
      else {binaryBrightness=0;binarySize=0;starOrbit=0;}

      // world orbit and moon
      int worldmoon=false;
      orbit[worldsorbit]=TypeOfWorld;
      dice=(1+(random(6)))+(1+(random(6)));   //  two six sided die
      if (dice>10)	{ worldmoon=true;}

      // gas giant
      int gasgiant=0; int ggmoons=0;
      dice=(1+(random(6)))+(1+(random(6)));   //  two six sided die
      if (dice>8)
       	{
            gasgiant= (random(6)) + starsizeAjust;
            if (gasgiant>4) {gasgiant=4;}
            // gas giant moons
            ggmoons= (random(3));
            if (gasgiant==worldsorbit) {ggmoons=0;}
            orbit[gasgiant]=8;        // gas giant
       	}
      int orbitplace[5];
      for (int n=1;n<5;n++)                // orbit by orbit
      	{
            dice=(random(360)); orbitplace[n]=dice;
       		if ((n!=worldsorbit) && (n!=gasgiant))
       		{
               dice=(1+(random(6)))+starsizeAjust-n;   //   six sided die
               if (dice>3) {  orbit[n]=0;	} // empty orbit
               if (dice==2) {  orbit[n]=10;	} // asteroides
               if (dice<2) {  orbit[n]=9;	} // moon
       		}
      	}
      orbitplace[3]=225+ (random(90));
      orbitplace[4]=80 + (random(20));
          // set checksystem
      CheckSystem.StarNumber=worldnumber;
      CheckSystem.starSeed=Rnumber;
      CheckSystem.AlphaSunSize=starsize;
      CheckSystem.BetaSunSize=binarySize;
      CheckSystem.AlphaSunType=star[worldnumber].spectrum;
      CheckSystem.BetaSunType=binaryBrightness;
      CheckSystem.AlphaSunOrbit=starOrbit;
      CheckSystem.BetaSunOrbit=BstarOrbit;
      CheckSystem.orbit[1]=orbit[1];
      CheckSystem.orbitstart[1]=orbitplace[1];
      CheckSystem.orbit[2]=orbit[2];
      CheckSystem.orbitstart[2]=orbitplace[2];
      CheckSystem.orbit[3]=orbit[3];
      CheckSystem.orbitstart[3]=orbitplace[3];
      CheckSystem.orbit[4]=orbit[4];
      CheckSystem.orbitstart[4]=orbitplace[4];
      CheckSystem.GGmoon=ggmoons;
      CheckSystem.worldmoon=worldmoon;
      CheckSystem.world=TypeOfWorld;
   }

void GetWorldInfo(int Rnumber,int worldnumber)
{

	srand(Rnumber); 								// set seed
   int diceA, diceB;  int TotalHydro=0;
   int TypeOfWorld=CheckSystem.world;     // world type
   world.number=worldnumber;
   if (TypeOfWorld<20)                    // default (add types CZAR)
   {
      // atmo here CZAR
      // world.areaatmo[8]=...;

      //Hydro percentage
      diceA=(1+(random(6)))+(1+(random(6)));   //  two six sided die
      world.hydrosize=diceA-2;
      //Hydro type
      world.hydrotype=1;  //h�o  // default (add types CZAR)
      //section by section
      for (int n=0; n<NUM_SECTIONS ;n++)
      {
         world.area[HYDRO][n]=0;   // set to zero
			world.area[PLAIN][n]=0;
			world.area[PLANT_PLAIN][n]=0;
			world.area[PLANT_HILL][n]=0;
			world.area[HILL ][n]=0;
			world.area[MOUNT][n]=0;
			world.area[MARCH][n]=0;
         diceA=(1+(random(6)))+(1+(random(6)))+1;   //  two six sided die
         if ( world.hydrosize>=diceA )                               // hydro
         {
         	TotalHydro++; world.areatype[n]=HYDRO;
            world.area[HYDRO][n]=10;      // default: 100%
            // islands add in here CZAR
         }
         else
         {
         	diceA=(1+(random(6)))+(1+(random(6)));  //  two six sided die
            diceB=(1+(random(4)))+ 5;  //60% to 90% //  four sided die + five
            if (diceA<=8)
            	{
                  world.areatype[n]=PLAIN;                    	  // plain
						world.area[PLAIN][n]=diceB; // percent plain

			   }
			if (diceA==9)
				{
				  world.areatype[n]=PLANT_PLAIN;                 // Plant life
						world.area[PLANT_PLAIN][n]=diceB; // percent forrest

			   }
			if (diceA==10)
				{
				  world.areatype[n]=PLANT_HILL;                    	  // Plant life
						world.area[PLANT_HILL][n]=diceB; // percent forrest

			   }
			if (diceA==11)
            	{
                  world.areatype[n]=HILL;                    	  // hill
						world.area[HILL][n]=diceB; // percent hills
               }
			if (diceA==12)
            	{
                  world.areatype[n]=MOUNT;                    	  // mount
                  world.area[MOUNT][n]=diceB; // percent mounts
               }
			if (diceA>=13)
            	{
                  world.areatype[n]=MARCH;                    	  // march
                  world.area[MARCH][n]= diceB; // percent march
               }
            //left over percent terrain//latter add two or three or joker(1-3%)
            diceA=(1+(random(NUM_TERRAINS)));		// (1 to number of terrains)
            world.area[diceA][n]= (10-diceB)*10;
            // coast hydro CZAR  here

            // resourses   simplefied   (to define later CZAR)
            diceA=(1+(random(6)))+(1+(random(6)));   //  two six sided die
            world.arearesourses[n]= diceA;
         }
      }
	world.hydrosize=TotalHydro;
	world.landsections=NUM_SECTIONS-TotalHydro;
   }
}

void GetWorldTerre(int Rnumber,int worldnumber)
{
   srand(Rnumber);                 	// set seed

   int diceA, diceB, n, x, y, nt, nntt;
   for (n=0; n<NUM_SECTIONS ; n++)
   {
   	for (x=0; x<10 ; x++)
   	{
      	for (y=0; y<10 ; y++)
   		{
         	slot [n][x][y]= world.areatype[n];	// set all terrain to default
   		}
   	}
      for (nt=0; nt<NUM_TERRAINS ; nt++)   // go through terrains
      {
      	if (world.area[nt][n]>0 && world.areatype[n]!=nt) // if earea exists
         {
         	 for (nntt=1; nntt<=world.area[nt][n] ; nntt++) // terrain percent
             {                                          // if type not default
             	 diceA=random(9); diceB=random(9);
                if (slot [n][diceA][diceB] == world.areatype[n])
                {
                	slot [n][diceA][diceB]=nt;
                }
                else  { nntt--; }    // try again!
             }
         }
      }
   }
}
/*
void DrawWorld(void)///////////////////////////////////////////////////////////////
{
   int nx, ny, x, y;
   RECT rcRectTile;
   rcRectTile.top=50; rcRectTile. bottom=55;
   rcRectTile.left=0; rcRectTile.right=5;     // ++8 right left
   									// black out smalle map
   ZeroMemory( &ddbltfx, sizeof( ddbltfx ) );
   ddbltfx.dwSize = sizeof( ddbltfx );
   ddbltfx.dwFillColor = dwBackground;
   lpDDSOffScreen->Blt( &rcRectSection2, NULL,
   										NULL,
   										DDBLT_COLORFILL |
                                 DDBLT_WAIT, &ddbltfx );
   int section=0;
   for ( nx=0; nx<NUM_SECTIONS/3 ;nx++)
   {
       for ( ny=0; ny<NUM_SECTIONS/4 ;ny++)
       {
   		for ( x=0; x<10 ; x++)
   		{
      		for ( y=0; y<10 ; y++)
   			{
              rcRectTile.left=0+(slot[section][x][y])*8;
              rcRectTile.right=4+(slot[section][x][y])*8;

              lpDDSOffScreen->BltFast( (x*5)+513+(nx*50),   // basic system for now
             									(y*5)+313+(ny*50),
                                       lpDDSOffLetters,
                                       &rcRectTile,
                                       DDBLTFAST_WAIT |
                                       DDBLTFAST_SRCCOLORKEY );
   			}
   		}
         section++;
       }
   }
}
*/
void galaxy(void)
	{
      void randomname();
   	//randomize();                                 // set RND seed


      struct                           // tempory star system structure
		{
      	unsigned char	spectrum;
      	unsigned char	size;
      	unsigned char	Bspectrum;
      	unsigned char	Bsize;
      	short	int x;
      	short	int y;
		 int alien;
		 char name[20];
   	} temp;            					// max 1

      int life;
	int n;                                       // set local variables
	int ii;
      int dice;
      int diceajust;
      unsigned char brightness;
      unsigned char binaryBrightness;

      float xxx; float yyy;
      float      	angle;
      float      	diceR;
		float			diceRO;
		float      	diceA;
		int      	diceM;
      unsigned char	starsize;
	  unsigned char binarySize;
	  int			star_on_star;

	  int			diceint;

	for (n=0; n<NumberStars; ++n) //find star location x and y
		{
            xxx= random(X_size);
			yyy= random(Y_size);
			star [n].x = xxx;   		  //   star n's x location
			star [n].y = yyy;   		  //   star n's y location
        }

	for (n=0; n<NumberStars; ++n)
		{
			for ( ; ; )    // loop breaks if not on another star
			{
				xxx= star [n].x;
				yyy= star [n].y;
				star_on_star=false;
				for (ii = 0; ii < NumberStars; ii++)
				{
					// if star on another star...(but not including itself!)
					if ( (xxx==star [ii].x) && ( yyy==star [ii].y) && (n!=ii) )
					{
						star_on_star=true;
					}
				}
				if (star_on_star==false)
				{
					break;
				}
				else
				{
					// re find location if on another star
					star [n].x= random(X_size);
					star [n].y= random(Y_size);
                }
			}

		}

	for (n=0; n<NumberStars; ++n)              //  1000 is number of stars
		{
         	diceajust=-1;

     /*
             diceint= random(1000000);
             diceR= 1.0+  ( pow((diceint/1000000.0),shapeN) ) * (NumberStars/2);
             diceRO= random ((NumberStars/4)*5);
             diceint= random(1000000);
             diceA=  (diceint/1000000.0)*(2.0*M_PI);
             diceM=  random (arms);
             angle= ( (2.0*M_PI) * diceM / ( 1.0 * arms )) + (  shapeL * M_PI * diceR / NumberStars );
        //   angle= (0.00001*abs(angle*40000));
             xxx= ((diceR*cos(angle))+(spread*diceRO/((300.0)+diceR))*cos(diceA)+416.0);
             yyy= ((diceR*sin(angle))+(spread*diceRO/((300.0)+diceR))*sin(diceA)+416.0);
      //     sqrt ((xxx)2+(yyy)2)= 0 center, 2000 border

           */
			xxx= star [n].x;
			yyy= star [n].y;

      		if (  (xxx > NumberStars/4) && (xxx < NumberStars-NumberStars/4) &&
            		(yyy > NumberStars/4) && (yyy < NumberStars-NumberStars/4)  )
            			{
                     	diceajust=5;
                        if (  (xxx > 375) && (xxx < NumberStars-375) &&
            						(yyy > 375) && (yyy < NumberStars-375)  )
                        {diceajust=10;}
                     }
			if ( n < GREATER_RACES )
            			{
                     life=true;
					 }

			else { life=false; }

            dice=1+(random(100))+diceajust;             //  hundred sided die

            if (dice<80)                           //  simple size generater
            	{
                  starsize=TINY_STAR;
               }
            if (dice>=80 && dice<95)
            	{
                  starsize=SMALLE_STAR;
               }
            if (dice>=95 && dice<99)
            	{
                  starsize=MEDIUM_STAR;
               }
            if (dice>=99)
            	{
                  starsize=LARGE_STAR;
               }

            dice=1+(random(100))+diceajust;             //  hundred sided die
            if (dice<60)                      //  simple spectral generater
            	{
                  brightness=1;               // red
               }
            if (dice>=60 && dice<85)
            	{
                  brightness=2;               // orange
               }
            if (dice>=85 && dice<95)
            	{
                  brightness=3;               // yellow
               }
            if (dice>=95 && dice<99)
            	{
                  brightness=4;              // blue
               }

            if (dice>=99)
            	{
                  brightness=5;              // white
               }


               // star worlds
               // world type

			   dice=(1+(random(7)));
			   star [n].worldType=dice;
               			// world size
			   dice=(1+(random(5)));
               star [n].worldSize=dice;
               			// world orbit
               dice=(1+(random(4)));
               star [n].worldOrbit=dice;

               ///   ///  ///   new globe pic   ///  ///  ///
			   dice=random(3);
               star [n].globeX=dice;

               dice=random(3);
               star [n].globeY=dice;

			// star name
			// first give default random name
            for (int ii = 0; ii<8 ; ++ii) { star [n].name[ii] =0; Name[ii]=0; }
            randomname();
			for (int ii = 0; ii<8 ; ++ii) { star [n].name[ii] =Name[ii]; }
			star [n].name[8] ='\n';
			//then check inputs
            world_type_names ();


            star [n].spectrum = brightness;
            star [n].size = starsize;
            star [n].Bspectrum = binaryBrightness;
			star [n].Bsize = binarySize;
			star [n].x = xxx;   					 			//   star n's x location
			star [n].y = yyy;   					 			//   star n's y location
			star [n].seed = rand();
			star [n].alien = life;
            star [n].owner = NUTRAL;


         }

         //   sort stars by x then y

	  for (int i = 0; i<NumberStars ; ++i)
		{
         	for (int j = 1; j<=i ; ++j)
            {
            	if ( star [i].x <  star [j].x)
               {
               	temp.spectrum= star [i].spectrum;
                  temp.size= star [i].size;
                  temp.Bspectrum= star [i].Bspectrum;
                  temp.Bsize= star [i].Bsize;
				  temp.x= star [i].x;
                  temp.y= star [i].y;
				  temp.alien= star [i].alien;
				  strcpy (temp.name, star [i].name); //temp.name = star [n].name ;

                  star [i].spectrum = star [j].spectrum;
                  star [i].size = star [j].size;
                  star [i].Bspectrum = star [j].Bspectrum;
                  star [i].Bsize = star [j].Bsize;
                  star [i].x = star [j].x;
                  star [i].y = star [j].y;
				  star [i].alien = star [j].alien;
				  strcpy (star [i].name, star [j].name);

                  star [j].spectrum = temp.spectrum;
                  star [j].size = temp.size;
                  star [j].Bspectrum = temp.Bspectrum;
                  star [j].Bsize = temp.Bsize;
                  star [j].x = temp.x;
                  star [j].y = temp.y;
				  star [j].alien = temp.alien;
				  strcpy (star [j].name, temp.name);
               }
               if ( (star [i].x ==  star [j].x) && (star [i].y <  star [j].y) )
               {
				  temp.spectrum= star [i].spectrum;
                  temp.size= star [i].size;
                  temp.Bspectrum= star [i].Bspectrum;
                  temp.Bsize= star [i].Bsize;
                  temp.x= star [i].x;
                  temp.y= star [i].y;
				  temp.alien= star [i].alien;
				  strcpy (temp.name, star [i].name);

                  star [i].spectrum = star [j].spectrum;
                  star [i].size = star [j].size;
                  star [i].Bspectrum = star [j].Bspectrum;
                  star [i].Bsize = star [j].Bsize;
                  star [i].x = star [j].x;
                  star [i].y = star [j].y;
				  star [i].alien = star [j].alien;
				  strcpy (star [i].name, star [j].name);

                  star [j].spectrum = temp.spectrum;
                  star [j].size = temp.size;
                  star [j].Bspectrum = temp.Bspectrum;
                  star [j].Bsize = temp.Bsize;
                  star [j].x = temp.x;
                  star [j].y = temp.y;
				  star [j].alien = temp.alien;
				  strcpy (star [j].name, temp.name);
               }
            }
         }
      // once sorted find 10 closest worlds to each system for AI movement
     	long distance[10];  long nowDistance;
	  long xdist; long ydist;
	  for (short int ia = 0; ia<NumberStars ; ++ia)
		{
			distance[0]=1000000;      // set distances to very far indeed
			distance[1]=1000000;
			distance[2]=1000000;
			distance[3]=1000000;
			distance[4]=1000000;
			distance[5]=1000000;
			distance[6]=1000000;
			distance[7]=1000000;
			distance[8]=1000000;
			distance[9]=1000000;
			for (short int ja = 0; ja<NumberStars ; ++ja)
				{
				  xdist=  (star[ia].x+4000) - (star[ja].x+4000) ;
				  ydist=  (star[ia].y+4000) - (star[ja].y+4000) ;
				  xdist= abs ( xdist );
				  ydist= abs ( ydist );
				  nowDistance=  sqrt ( (xdist*xdist)+(ydist*ydist)+ 0.0000001 );
				  if  ( (nowDistance<distance[9]) && (ja != ia) )
				  {
					distance[9]= nowDistance;
					 star[ia].Neighbour[9]=ja;
					 if (nowDistance<distance[8])
					 {
						distance[9]= distance[8];
						distance[8]= nowDistance;
						star[ia].Neighbour[9]= star[ia].Neighbour[8];
						star[ia].Neighbour[8]=ja;
						if (nowDistance<distance[7])
						{
							distance[8]= distance[7];
							distance[7]= nowDistance;
							star[ia].Neighbour[8]= star[ia].Neighbour[7];
							star[ia].Neighbour[7]=ja;
						   if (nowDistance<distance[6])
							{
								distance[7]= distance[6];
								distance[6]= nowDistance;
                        		star[ia].Neighbour[7]= star[ia].Neighbour[6];
								star[ia].Neighbour[6]=ja;
                              if (nowDistance<distance[5])
                     			{
                     				distance[6]= distance[5];
									distance[5]= nowDistance;
                        			star[ia].Neighbour[6]= star[ia].Neighbour[5];
                        			star[ia].Neighbour[5]=ja;
                                 if (nowDistance<distance[4])
									{
                     					distance[5]= distance[4];
                        				distance[4]= nowDistance;
                        				star[ia].Neighbour[5]= star[ia].Neighbour[4];
										star[ia].Neighbour[4]=ja;
                                    if (nowDistance<distance[3])
                     					{
                     						distance[4]= distance[3];
                        					distance[3]= nowDistance;
                        					star[ia].Neighbour[4]= star[ia].Neighbour[3];
                        					star[ia].Neighbour[3]=ja;
                                       if (nowDistance<distance[2])
                     						{
                     							distance[3]= distance[2];
                        						distance[2]= nowDistance;
												star[ia].Neighbour[3]= star[ia].Neighbour[2];
												star[ia].Neighbour[2]=ja;
										  if (nowDistance<distance[1])
												{
													distance[2]= distance[1];
													distance[1]= nowDistance;
													star[ia].Neighbour[2]= star[ia].Neighbour[1];
													star[ia].Neighbour[1]=ja;
											 if (nowDistance<distance[0])
													{
														distance[1]= distance[0];
														distance[0]= nowDistance;
														star[ia].Neighbour[1]= star[ia].Neighbour[0];
														star[ia].Neighbour[0]=ja;
													}
												}
											}
										}
									}
								}
							}
						}
					 }
				  }
				}

				//check that closest worlds are not same size
                 for (short int ia = 0; ia<NumberStars ; ++ia)
				{

						if (star[star[ia].Neighbour[0]].worldSize==star[ia].worldSize)
						{
							star[ia].worldSize=star[ia].worldSize+1;
							if (star[ia].worldSize>5)
							{
                               star[ia].worldSize=5;
							}
						}

                }
		 }
    // set home worlds//
	home_world_set_up ();
   	for (short int jb = 0; jb<NumberStars ; ++jb)
   	{
        creat_world (jb);
	}

    ai_setup();       // alien set up

   }


