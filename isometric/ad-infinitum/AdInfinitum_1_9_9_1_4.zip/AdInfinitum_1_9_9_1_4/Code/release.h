//release graphic memory//

static void ReleaseObjects( void )
{
    debugfile ("releasing \n",1 );
    DeleteObject( hBrushGreen );
    DeleteObject( hBrushRed );
    CloseLinkedList();
    Remove_all_Planets();
    if ( lpDD != NULL )
    {
        if ( lpDDSPrimary != NULL )
        {
            if ( lpDDSOffScreen != NULL )
            {
                lpDDSOffScreen->Release();
                lpDDSOffScreen = NULL;
			}

            if ( lpDDSOffBar1 != NULL )
			{
			lpDDSOffBar1->Release();
			lpDDSOffBar1 = NULL;
			}

            if ( lpDDSOffOne != NULL )
            {
                lpDDSOffOne->Release();
                lpDDSOffOne = NULL;
			}



            if ( lpDDSOffButtons != NULL )
            {
                lpDDSOffButtons->Release();
                lpDDSOffButtons = NULL;
            }

            if ( lpDDSOffThree != NULL )
            {
                lpDDSOffThree->Release();
                lpDDSOffThree = NULL;
            }

            if ( lpDDSOffCursor != NULL )
            {
                lpDDSOffCursor->Release();
                lpDDSOffCursor = NULL;
            }

            if ( lpDDSOffSmaleStars != NULL )
            {
                lpDDSOffSmaleStars->Release();
                lpDDSOffSmaleStars = NULL;
            }

            if ( lpDDSOffJump1 != NULL )
            {
                lpDDSOffJump1->Release();
                lpDDSOffJump1 = NULL;
            }

            if ( lpDDSOffJump2 != NULL )
            {
                lpDDSOffJump2->Release();
                lpDDSOffJump2 = NULL;
            }

            if ( lpDDSOffJump3 != NULL )
            {
                lpDDSOffJump3->Release();
                lpDDSOffJump3 = NULL;
            }

            if ( lpDDSOffSuns != NULL )
            {
                lpDDSOffSuns->Release();
                lpDDSOffSuns = NULL;
            }

			if ( lpDDSOffMap != NULL )
			{
				lpDDSOffMap->Release();
				lpDDSOffMap = NULL;
			}

			if ( lpDDSOffMap_color != NULL )
			{
				lpDDSOffMap_color->Release();
				lpDDSOffMap_color = NULL;
			}

            if ( lpDDSOffLetters != NULL )
            {
                lpDDSOffLetters->Release();
                lpDDSOffLetters = NULL;
            }

            if ( lpDDSOffWorlds != NULL )
            {
                lpDDSOffWorlds->Release();
                lpDDSOffWorlds = NULL;
            }

            if ( lpDDSOffGlobes != NULL )
            {
                lpDDSOffGlobes->Release();
                lpDDSOffGlobes = NULL;
            }

            if ( lpDDSOffNebula1 != NULL )
            {
                lpDDSOffNebula1->Release();
                lpDDSOffNebula1 = NULL;
			}
			//////////////////
			if ( lpDDSOffIcons1 != NULL )
            {
				lpDDSOffIcons1->Release();
				lpDDSOffIcons1 = NULL;
			}
			if ( lpDDSOffFactions1 != NULL )
            {
				lpDDSOffFactions1->Release();
				lpDDSOffFactions1 = NULL;
			}
			/////////////////
			if ( lpDDSOffPlain != NULL )
            {
				lpDDSOffPlain->Release();
				lpDDSOffPlain = NULL;
			}
			//
			if ( lpDDSOffPlain_Desert1 != NULL )
            {
				lpDDSOffPlain_Desert1->Release();
				lpDDSOffPlain_Desert1 = NULL;
			}
			if ( lpDDSOffPlain_Desert2 != NULL )
            {
				lpDDSOffPlain_Desert2->Release();
				lpDDSOffPlain_Desert2 = NULL;
			}
			if ( lpDDSOffPlain_Desert3 != NULL )
            {
				lpDDSOffPlain_Desert3->Release();
				lpDDSOffPlain_Desert3 = NULL;
			}
			if ( lpDDSOffPlain_Desert4 != NULL )
            {
				lpDDSOffPlain_Desert4->Release();
				lpDDSOffPlain_Desert4 = NULL;
			}
			if ( lpDDSOffPlain_Desert5 != NULL )
            {
				lpDDSOffPlain_Desert5->Release();
				lpDDSOffPlain_Desert5 = NULL;
			}
			//
			if ( lpDDSOffPlain_Dry1 != NULL )
            {
				lpDDSOffPlain_Dry1->Release();
				lpDDSOffPlain_Dry1 = NULL;
			}
			if ( lpDDSOffPlain_Dry2 != NULL )
            {
				lpDDSOffPlain_Dry2->Release();
				lpDDSOffPlain_Dry2 = NULL;
			}
			if ( lpDDSOffPlain_Dry3 != NULL )
            {
				lpDDSOffPlain_Dry3->Release();
				lpDDSOffPlain_Dry3 = NULL;
			}
			if ( lpDDSOffPlain_Dry4 != NULL )
            {
				lpDDSOffPlain_Dry4->Release();
				lpDDSOffPlain_Dry4 = NULL;
			}
			if ( lpDDSOffPlain_Dry5 != NULL )
            {
				lpDDSOffPlain_Dry5->Release();
				lpDDSOffPlain_Dry5 = NULL;
			}
			//
			if ( lpDDSOffDunes_Desert1 != NULL )
            {
				lpDDSOffDunes_Desert1->Release();
				lpDDSOffDunes_Desert1 = NULL;
			}
			if ( lpDDSOffDunes_Desert2 != NULL )
            {
				lpDDSOffDunes_Desert2->Release();
				lpDDSOffDunes_Desert2 = NULL;
			}
			if ( lpDDSOffDunes_Desert3 != NULL )
            {
				lpDDSOffDunes_Desert3->Release();
				lpDDSOffDunes_Desert3 = NULL;
			}
			if ( lpDDSOffDunes_Desert4 != NULL )
            {
				lpDDSOffDunes_Desert4->Release();
				lpDDSOffDunes_Desert4 = NULL;
			}
			if ( lpDDSOffDunes_Desert5 != NULL )
            {
				lpDDSOffDunes_Desert5->Release();
				lpDDSOffDunes_Desert5 = NULL;
			}
			//
			if ( lpDDSOffRocky_Plain_Desert1 != NULL )
            {
				lpDDSOffRocky_Plain_Desert1->Release();
				lpDDSOffRocky_Plain_Desert1 = NULL;
			}
			if ( lpDDSOffRocky_Plain_Desert2 != NULL )
            {
				lpDDSOffRocky_Plain_Desert2->Release();
				lpDDSOffRocky_Plain_Desert2 = NULL;
			}
			if ( lpDDSOffRocky_Plain_Desert3 != NULL )
            {
				lpDDSOffRocky_Plain_Desert3->Release();
				lpDDSOffRocky_Plain_Desert3 = NULL;
			}
			if ( lpDDSOffRocky_Plain_Desert4 != NULL )
            {
				lpDDSOffRocky_Plain_Desert4->Release();
				lpDDSOffRocky_Plain_Desert4 = NULL;
			}
			if ( lpDDSOffRocky_Plain_Desert5 != NULL )
            {
				lpDDSOffRocky_Plain_Desert5->Release();
				lpDDSOffRocky_Plain_Desert5 = NULL;
			}
			//
			if ( lpDDSOffPlain_Ice != NULL )
            {
				lpDDSOffPlain_Ice->Release();
				lpDDSOffPlain_Ice = NULL;
			}
			if ( lpDDSOffPlain_Lava != NULL )
			{
				lpDDSOffPlain_Lava->Release();
				lpDDSOffPlain_Lava = NULL;
			}
			if ( lpDDSOffPlain_Moon != NULL )
			{
				lpDDSOffPlain_Moon->Release();
				lpDDSOffPlain_Moon = NULL;
			}
			if ( lpDDSOffPlain_Exotic != NULL )
			{
				lpDDSOffPlain_Exotic->Release();
				lpDDSOffPlain_Exotic = NULL;
			}
			if ( lpDDSOffSwamp != NULL )
            {
				lpDDSOffSwamp->Release();
				lpDDSOffSwamp = NULL;
			}
			if ( lpDDSOffSea != NULL )
			{
				lpDDSOffSea->Release();
				lpDDSOffSea = NULL;
			}

			if ( lpDDSOffDeep_Sea != NULL )
            {
				lpDDSOffDeep_Sea->Release();
				lpDDSOffDeep_Sea = NULL;
			}

			if ( lpDDSOffShalow_Sea != NULL )
            {
				lpDDSOffShalow_Sea->Release();
				lpDDSOffShalow_Sea = NULL;
			}
			////////new sea/////////
			if ( lpDDSOffSea1 != NULL )
			{
				lpDDSOffSea1->Release();
				lpDDSOffSea1 = NULL;
			}
			if ( lpDDSOffSea2 != NULL )
			{
				lpDDSOffSea2->Release();
				lpDDSOffSea2 = NULL;
			}
			if ( lpDDSOffSea3 != NULL )
			{
				lpDDSOffSea3->Release();
				lpDDSOffSea3 = NULL;
			}
			if ( lpDDSOffSea4 != NULL )
			{
				lpDDSOffSea4->Release();
				lpDDSOffSea4 = NULL;
			}
			if ( lpDDSOffSea5 != NULL )
			{
				lpDDSOffSea5->Release();
				lpDDSOffSea5 = NULL;
			}
			if ( lpDDSOffSea6 != NULL )
			{
				lpDDSOffSea6->Release();
				lpDDSOffSea6 = NULL;
			}
			if ( lpDDSOffSea7 != NULL )
			{
				lpDDSOffSea7->Release();
				lpDDSOffSea7 = NULL;
			}
			if ( lpDDSOffSea8 != NULL )
			{
				lpDDSOffSea8->Release();
				lpDDSOffSea8 = NULL;
			}
			if ( lpDDSOffSea9 != NULL )
			{
				lpDDSOffSea9->Release();
				lpDDSOffSea9 = NULL;
			}
			if ( lpDDSOffSea10 != NULL )
			{
				lpDDSOffSea10->Release();
				lpDDSOffSea10 = NULL;
			}
			//
			if ( lpDDSOffSea_deep1 != NULL )
			{
				lpDDSOffSea_deep1->Release();
				lpDDSOffSea_deep1 = NULL;
			}
			if ( lpDDSOffSea_deep2 != NULL )
			{
				lpDDSOffSea_deep2->Release();
				lpDDSOffSea_deep2 = NULL;
			}
			if ( lpDDSOffSea_deep3 != NULL )
			{
				lpDDSOffSea_deep3->Release();
				lpDDSOffSea_deep3 = NULL;
			}
			if ( lpDDSOffSea_deep4 != NULL )
			{
				lpDDSOffSea_deep4->Release();
				lpDDSOffSea_deep4 = NULL;
			}
			if ( lpDDSOffSea_deep5 != NULL )
			{
				lpDDSOffSea_deep5->Release();
				lpDDSOffSea_deep5 = NULL;
			}
			if ( lpDDSOffSea_deep6 != NULL )
			{
				lpDDSOffSea_deep6->Release();
				lpDDSOffSea_deep6 = NULL;
			}
			if ( lpDDSOffSea_deep7 != NULL )
			{
				lpDDSOffSea_deep7->Release();
				lpDDSOffSea_deep7 = NULL;
			}
			if ( lpDDSOffSea_deep8 != NULL )
			{
				lpDDSOffSea_deep8->Release();
				lpDDSOffSea_deep8 = NULL;
			}
			if ( lpDDSOffSea_deep9 != NULL )
			{
				lpDDSOffSea_deep9->Release();
				lpDDSOffSea_deep9 = NULL;
			}
			if ( lpDDSOffSea_deep10 != NULL )
			{
				lpDDSOffSea_deep10->Release();
				lpDDSOffSea_deep10 = NULL;
			}
			////////////////////////
			if ( lpDDSOffSea_desert1 != NULL )
			{
				lpDDSOffSea_desert1->Release();
				lpDDSOffSea_desert1 = NULL;
			}
			if ( lpDDSOffSea_desert2 != NULL )
			{
				lpDDSOffSea_desert2->Release();
				lpDDSOffSea_desert2 = NULL;
			}
			if ( lpDDSOffSea_desert3 != NULL )
			{
				lpDDSOffSea_desert3->Release();
				lpDDSOffSea_desert3 = NULL;
			}
			if ( lpDDSOffSea_desert4 != NULL )
			{
				lpDDSOffSea_desert4->Release();
				lpDDSOffSea_desert4 = NULL;
			}
			if ( lpDDSOffSea_desert5 != NULL )
			{
				lpDDSOffSea_desert5->Release();
				lpDDSOffSea_desert5 = NULL;
			}
			////////////////////////
			if ( lpDDSOffSea_ice_1 != NULL )
			{
				lpDDSOffSea_ice_1->Release();
				lpDDSOffSea_ice_1 = NULL;
			}
			if ( lpDDSOffSea_ice_2 != NULL )
			{
				lpDDSOffSea_ice_2->Release();
				lpDDSOffSea_ice_2 = NULL;
			}
			////////////
			if ( lpDDSOffSea_lava != NULL )
			{
				lpDDSOffSea_lava->Release();
				lpDDSOffSea_lava = NULL;
			}

			if ( lpDDSOffDeep_Sea_lava != NULL )
			{
				lpDDSOffDeep_Sea_lava->Release();
				lpDDSOffDeep_Sea_lava = NULL;
			}

			if ( lpDDSOffShalow_Sea_lava != NULL )
			{
				lpDDSOffShalow_Sea_lava->Release();
				lpDDSOffShalow_Sea_lava = NULL;
			}
			if ( lpDDSOffSea_exotic != NULL )
			{
				lpDDSOffSea_exotic->Release();
				lpDDSOffSea_exotic = NULL;
			}

			if ( lpDDSOffDeep_Sea_exotic != NULL )
			{
				lpDDSOffDeep_Sea_exotic->Release();
				lpDDSOffDeep_Sea_exotic = NULL;
			}

			if ( lpDDSOffShalow_Sea_exotic != NULL )
			{
				lpDDSOffShalow_Sea_exotic->Release();
				lpDDSOffShalow_Sea_exotic = NULL;
			}
			///////
			if ( lpDDSOffTrees != NULL )
			{
				lpDDSOffTrees->Release();
				lpDDSOffTrees = NULL;
			}

			if ( lpDDSOffHill_Trees != NULL )
			{
				lpDDSOffHill_Trees->Release();
				lpDDSOffHill_Trees = NULL;
			}

			if ( lpDDSOffSwamp_Trees != NULL )
			{
				lpDDSOffSwamp_Trees->Release();
				lpDDSOffSwamp_Trees = NULL;
			}
			//////
			if ( lpDDSOffTrees_a_1 != NULL )
			{
				lpDDSOffTrees_a_1->Release();
				lpDDSOffTrees_a_1 = NULL;
			}
			if ( lpDDSOffTrees_a_2 != NULL )
			{
				lpDDSOffTrees_a_2->Release();
				lpDDSOffTrees_a_2 = NULL;
			}
			if ( lpDDSOffTrees_a_3 != NULL )
			{
				lpDDSOffTrees_a_3->Release();
				lpDDSOffTrees_a_3 = NULL;
			}
			if ( lpDDSOffTrees_a_4 != NULL )
			{
				lpDDSOffTrees_a_4->Release();
				lpDDSOffTrees_a_4 = NULL;
			}
			if ( lpDDSOffTrees_a_5 != NULL )
			{
				lpDDSOffTrees_a_5->Release();
				lpDDSOffTrees_a_5 = NULL;
			}
			///////
			if ( lpDDSOffDesert_Trees1 != NULL )
			{
				lpDDSOffDesert_Trees1->Release();
				lpDDSOffDesert_Trees1 = NULL;
			}
			if ( lpDDSOffDesert_Trees2 != NULL )
			{
				lpDDSOffDesert_Trees2->Release();
				lpDDSOffDesert_Trees2 = NULL;
			}
			if ( lpDDSOffDesert_Trees3 != NULL )
			{
				lpDDSOffDesert_Trees3->Release();
				lpDDSOffDesert_Trees3 = NULL;
			}
			if ( lpDDSOffDesert_Trees4 != NULL )
			{
				lpDDSOffDesert_Trees4->Release();
				lpDDSOffDesert_Trees4 = NULL;
			}
			if ( lpDDSOffDesert_Trees5 != NULL )
			{
				lpDDSOffDesert_Trees5->Release();
				lpDDSOffDesert_Trees5 = NULL;
			}
			///////
			if ( lpDDSOffHill1 != NULL )
			{
				lpDDSOffHill1->Release();
				lpDDSOffHill1 = NULL;
			}
			if ( lpDDSOffHill2 != NULL )
			{
				lpDDSOffHill2->Release();
				lpDDSOffHill2 = NULL;
			}
			if ( lpDDSOffHill3 != NULL )
			{
				lpDDSOffHill3->Release();
				lpDDSOffHill3 = NULL;
			}
			if ( lpDDSOffHill4 != NULL )
			{
				lpDDSOffHill4->Release();
				lpDDSOffHill4 = NULL;
			}
			if ( lpDDSOffHill5 != NULL )
			{
				lpDDSOffHill5->Release();
				lpDDSOffHill5 = NULL;
			}
			///
			if ( lpDDSOffHill_Ice1 != NULL )
			{
				lpDDSOffHill_Ice1->Release();
				lpDDSOffHill_Ice1 = NULL;
			}
			if ( lpDDSOffHill_Ice2 != NULL )
			{
				lpDDSOffHill_Ice2->Release();
				lpDDSOffHill_Ice2 = NULL;
			}
			if ( lpDDSOffHill_Ice3 != NULL )
			{
				lpDDSOffHill_Ice3->Release();
				lpDDSOffHill_Ice3 = NULL;
			}
			if ( lpDDSOffHill_Ice4 != NULL )
			{
				lpDDSOffHill_Ice4->Release();
				lpDDSOffHill_Ice4 = NULL;
			}
			if ( lpDDSOffHill_Ice5 != NULL )
			{
				lpDDSOffHill_Ice5->Release();
				lpDDSOffHill_Ice5 = NULL;
			}
			///
			if ( lpDDSOffHill_Desert1 != NULL )
			{
				lpDDSOffHill_Desert1->Release();
				lpDDSOffHill_Desert1= NULL;
			}
			if ( lpDDSOffHill_Desert2 != NULL )
			{
				lpDDSOffHill_Desert2->Release();
				lpDDSOffHill_Desert2 = NULL;
			}
			if ( lpDDSOffHill_Desert3 != NULL )
			{
				lpDDSOffHill_Desert3->Release();
				lpDDSOffHill_Desert3 = NULL;
			}
			if ( lpDDSOffHill_Desert4 != NULL )
			{
				lpDDSOffHill_Desert4->Release();
				lpDDSOffHill_Desert4 = NULL;
			}
			if ( lpDDSOffHill_Desert5 != NULL )
			{
				lpDDSOffHill_Desert5->Release();
				lpDDSOffHill_Desert5 = NULL;
			}
			//
			if ( lpDDSOffRocky_Hill_Desert1 != NULL )
			{
				lpDDSOffRocky_Hill_Desert1->Release();
				lpDDSOffRocky_Hill_Desert1= NULL;
			}
			if ( lpDDSOffRocky_Hill_Desert2 != NULL )
			{
				lpDDSOffRocky_Hill_Desert2->Release();
				lpDDSOffRocky_Hill_Desert2= NULL;
			}
			if ( lpDDSOffRocky_Hill_Desert3 != NULL )
			{
				lpDDSOffRocky_Hill_Desert3->Release();
				lpDDSOffRocky_Hill_Desert3= NULL;
			}
			if ( lpDDSOffRocky_Hill_Desert4 != NULL )
			{
				lpDDSOffRocky_Hill_Desert4->Release();
				lpDDSOffRocky_Hill_Desert4= NULL;
			}
			if ( lpDDSOffRocky_Hill_Desert5 != NULL )
			{
				lpDDSOffRocky_Hill_Desert5->Release();
				lpDDSOffRocky_Hill_Desert5= NULL;
			}
			//
			if ( lpDDSOffHill_Lava != NULL )
			{
				lpDDSOffHill_Lava->Release();
				lpDDSOffHill_Lava = NULL;
			}
			if ( lpDDSOffHill_Moon != NULL )
			{
				lpDDSOffHill_Moon->Release();
				lpDDSOffHill_Moon = NULL;
			}
			if ( lpDDSOffHill_Exotic != NULL )
			{
				lpDDSOffHill_Exotic->Release();
				lpDDSOffHill_Exotic = NULL;
			}
			///
			if ( lpDDSOffMount1 != NULL )
			{
				lpDDSOffMount1->Release();
				lpDDSOffMount1 = NULL;
			}
			if ( lpDDSOffMount2 != NULL )
			{
				lpDDSOffMount2->Release();
				lpDDSOffMount2 = NULL;
			}
			if ( lpDDSOffMount3 != NULL )
			{
				lpDDSOffMount3->Release();
				lpDDSOffMount3 = NULL;
			}
			if ( lpDDSOffMount4 != NULL )
			{
				lpDDSOffMount4->Release();
				lpDDSOffMount4 = NULL;
			}
			if ( lpDDSOffMount5 != NULL )
			{
				lpDDSOffMount5->Release();
				lpDDSOffMount5 = NULL;
			}
			///
			if ( lpDDSOffMount_Desert1 != NULL )
			{
				lpDDSOffMount_Desert1->Release();
				lpDDSOffMount_Desert1 = NULL;
			}
			if ( lpDDSOffMount_Desert2 != NULL )
			{
				lpDDSOffMount_Desert2->Release();
				lpDDSOffMount_Desert2 = NULL;
			}
			if ( lpDDSOffMount_Desert3 != NULL )
			{
				lpDDSOffMount_Desert3->Release();
				lpDDSOffMount_Desert3 = NULL;
			}
			if ( lpDDSOffMount_Desert4 != NULL )
			{
				lpDDSOffMount_Desert4->Release();
				lpDDSOffMount_Desert4 = NULL;
			}
			if ( lpDDSOffMount_Desert5 != NULL )
			{
				lpDDSOffMount_Desert5->Release();
				lpDDSOffMount_Desert5 = NULL;
			}
			//
			if ( lpDDSOffMount_Ice != NULL )
			{
				lpDDSOffMount_Ice->Release();
				lpDDSOffMount_Ice = NULL;
			}
			if ( lpDDSOffMount_Lava != NULL )
			{
				lpDDSOffMount_Lava->Release();
				lpDDSOffMount_Lava = NULL;
			}
			if ( lpDDSOffMount_Moon != NULL )
			{
				lpDDSOffMount_Moon->Release();
				lpDDSOffMount_Moon = NULL;
			}
			if ( lpDDSOffMount_Exotic != NULL )
			{
				lpDDSOffMount_Exotic->Release();
				lpDDSOffMount_Exotic = NULL;
			}
			//////////////
			if ( lpDDSOffRoad_E != NULL )
			{
				lpDDSOffRoad_E->Release();
				lpDDSOffRoad_E = NULL;
			}

			if ( lpDDSOffRoad_W != NULL )
			{
				lpDDSOffRoad_W->Release();
				lpDDSOffRoad_W = NULL;
			}
			if ( lpDDSOffRoad_W_NE != NULL )
			{
				lpDDSOffRoad_W_NE->Release();
				lpDDSOffRoad_W_NE = NULL;
			}
			if ( lpDDSOffRoad_NE != NULL )
			{
				lpDDSOffRoad_NE->Release();
				lpDDSOffRoad_NE = NULL;
			}

			if ( lpDDSOffRoad_NW_SW != NULL )
			{
				lpDDSOffRoad_NW_SW->Release();
				lpDDSOffRoad_NW_SW = NULL;
			}
			if ( lpDDSOffRoad_NW != NULL )
			{
				lpDDSOffRoad_NW->Release();
				lpDDSOffRoad_NW = NULL;
			}

			if ( lpDDSOffRoad_SE != NULL )
			{
				lpDDSOffRoad_SE->Release();
				lpDDSOffRoad_SE = NULL;
			}

			if ( lpDDSOffRoad_SW != NULL )
			{
				lpDDSOffRoad_SW->Release();
				lpDDSOffRoad_SW = NULL;
			}
			//////////////
			if ( lpDDSOffRiver_E != NULL )
			{
				lpDDSOffRiver_E->Release();
				lpDDSOffRiver_E = NULL;
			}

			if ( lpDDSOffRiver_W != NULL )
			{
				lpDDSOffRiver_W->Release();
				lpDDSOffRiver_W = NULL;
			}

			if ( lpDDSOffRiver_NE != NULL )
			{
				lpDDSOffRiver_NE->Release();
				lpDDSOffRiver_NE = NULL;
			}

			if ( lpDDSOffRiver_NW != NULL )
			{
				lpDDSOffRiver_NW->Release();
				lpDDSOffRiver_NW = NULL;
			}

			if ( lpDDSOffRiver_SE != NULL )
			{
				lpDDSOffRiver_SE->Release();
				lpDDSOffRiver_SE = NULL;
			}

			if ( lpDDSOffRiver_SW != NULL )
			{
				lpDDSOffRiver_SW->Release();
				lpDDSOffRiver_SW = NULL;
			}
			//////////////
			if ( lpDDSOffRiver_E_swamp != NULL )
			{
				lpDDSOffRiver_E_swamp->Release();
				lpDDSOffRiver_E_swamp = NULL;
			}

			if ( lpDDSOffRiver_W_swamp != NULL )
			{
				lpDDSOffRiver_W_swamp->Release();
				lpDDSOffRiver_W_swamp = NULL;
			}

			if ( lpDDSOffRiver_NE_swamp != NULL )
			{
				lpDDSOffRiver_NE_swamp->Release();
				lpDDSOffRiver_NE_swamp = NULL;
			}

			if ( lpDDSOffRiver_NW_swamp != NULL )
			{
				lpDDSOffRiver_NW_swamp->Release();
				lpDDSOffRiver_NW_swamp = NULL;
			}

			if ( lpDDSOffRiver_SE_swamp != NULL )
			{
				lpDDSOffRiver_SE_swamp->Release();
				lpDDSOffRiver_SE_swamp = NULL;
			}

			if ( lpDDSOffRiver_SW_swamp != NULL )
			{
				lpDDSOffRiver_SW_swamp->Release();
				lpDDSOffRiver_SW_swamp = NULL;
			}
			//////////////
			if ( lpDDSOffRiver_E_desert != NULL )
			{
				lpDDSOffRiver_E_desert->Release();
				lpDDSOffRiver_E_desert = NULL;
			}

			if ( lpDDSOffRiver_W_desert != NULL )
			{
				lpDDSOffRiver_W_desert->Release();
				lpDDSOffRiver_W_desert = NULL;
			}

			if ( lpDDSOffRiver_NE_desert != NULL )
			{
				lpDDSOffRiver_NE_desert->Release();
				lpDDSOffRiver_NE_desert = NULL;
			}

			if ( lpDDSOffRiver_NW_desert != NULL )
			{
				lpDDSOffRiver_NW_desert->Release();
				lpDDSOffRiver_NW_desert = NULL;
			}

			if ( lpDDSOffRiver_SE_desert != NULL )
			{
				lpDDSOffRiver_SE_desert->Release();
				lpDDSOffRiver_SE_desert = NULL;
			}

			if ( lpDDSOffRiver_SW_desert != NULL )
			{
				lpDDSOffRiver_SW_desert->Release();
				lpDDSOffRiver_SW_desert = NULL;
			}
			////////////
			if ( lpDDSOffRiver_E_lava != NULL )
			{
				lpDDSOffRiver_E_lava->Release();
				lpDDSOffRiver_E_lava = NULL;
			}

			if ( lpDDSOffRiver_W_lava != NULL )
			{
				lpDDSOffRiver_W_lava->Release();
				lpDDSOffRiver_W_lava = NULL;
			}

			if ( lpDDSOffRiver_NE_lava != NULL )
			{
				lpDDSOffRiver_NE_lava->Release();
				lpDDSOffRiver_NE_lava = NULL;
			}

			if ( lpDDSOffRiver_NW_lava != NULL )
			{
				lpDDSOffRiver_NW_lava->Release();
				lpDDSOffRiver_NW_lava = NULL;
			}

			if ( lpDDSOffRiver_SE_lava != NULL )
			{
				lpDDSOffRiver_SE_lava->Release();
				lpDDSOffRiver_SE_lava = NULL;
			}

			if ( lpDDSOffRiver_SW_lava != NULL )
			{
				lpDDSOffRiver_SW_lava->Release();
				lpDDSOffRiver_SW_lava = NULL;
			}
			////////////
			if ( lpDDSOffRiver_E_exotic != NULL )
			{
				lpDDSOffRiver_E_exotic->Release();
				lpDDSOffRiver_E_exotic = NULL;
			}

			if ( lpDDSOffRiver_W_exotic != NULL )
			{
				lpDDSOffRiver_W_exotic->Release();
				lpDDSOffRiver_W_exotic = NULL;
			}

			if ( lpDDSOffRiver_NE_exotic != NULL )
			{
				lpDDSOffRiver_NE_exotic->Release();
				lpDDSOffRiver_NE_exotic = NULL;
			}

			if ( lpDDSOffRiver_NW_exotic != NULL )
			{
				lpDDSOffRiver_NW_exotic->Release();
				lpDDSOffRiver_NW_exotic = NULL;
			}

			if ( lpDDSOffRiver_SE_exotic != NULL )
			{
				lpDDSOffRiver_SE_exotic->Release();
				lpDDSOffRiver_SE_exotic = NULL;
			}

			if ( lpDDSOffRiver_SW_exotic != NULL )
			{
				lpDDSOffRiver_SW_exotic->Release();
				lpDDSOffRiver_SW_exotic = NULL;
			}

			if ( lpDDSOffWorlds1 != NULL )
			{
				lpDDSOffWorlds1->Release();
				lpDDSOffWorlds1 = NULL;
			}

			if ( lpDDSOffWorlds2 != NULL )
			{
				lpDDSOffWorlds2->Release();
				lpDDSOffWorlds2 = NULL;
			}

			if ( lpDDSOffWorlds3 != NULL )
			{
				lpDDSOffWorlds3->Release();
				lpDDSOffWorlds3 = NULL;
			}

						if ( lpDDSOffWorlds4 != NULL )
			{
				lpDDSOffWorlds4->Release();
				lpDDSOffWorlds4 = NULL;
			}

			if ( lpDDSOffWorlds5 != NULL )
			{
				lpDDSOffWorlds5->Release();
				lpDDSOffWorlds5 = NULL;
			}

			if ( lpDDSOffWorlds6 != NULL )
			{
				lpDDSOffWorlds6->Release();
				lpDDSOffWorlds6 = NULL;
			}

						if ( lpDDSOffWorlds7 != NULL )
			{
				lpDDSOffWorlds7->Release();
				lpDDSOffWorlds7 = NULL;
			}

			if ( lpDDSOffWorlds8 != NULL )
			{
				lpDDSOffWorlds8->Release();
				lpDDSOffWorlds8 = NULL;
			}

			if ( lpDDSOffWorlds9 != NULL )
			{
				lpDDSOffWorlds9->Release();
				lpDDSOffWorlds9 = NULL;
			}
			////
			if ( lpDDSOffRes_radioactive != NULL )
			{
				lpDDSOffRes_radioactive->Release();
				lpDDSOffRes_radioactive = NULL;
			}
			if ( lpDDSOffRes_metal != NULL )
			{
				lpDDSOffRes_metal->Release();
				lpDDSOffRes_metal = NULL;
			}
			if ( lpDDSOffRes_oil != NULL )
			{
				lpDDSOffRes_oil->Release();
				lpDDSOffRes_oil = NULL;
			}
			if ( lpDDSOffRes_trace != NULL )
			{
				lpDDSOffRes_trace->Release();
				lpDDSOffRes_trace = NULL;
			}
			if ( lpDDSOffRes_gem != NULL )
			{
				lpDDSOffRes_gem->Release();
				lpDDSOffRes_gem = NULL;
			}
			if ( lpDDSOffRes_spice != NULL )
			{
				lpDDSOffRes_spice->Release();
				lpDDSOffRes_spice = NULL;
			}
			if ( lpDDSOffRes_chemy != NULL )
			{
				lpDDSOffRes_chemy->Release();
				lpDDSOffRes_chemy = NULL;
			}
			if ( lpDDSOffRes_hyper_steel != NULL )
			{
				lpDDSOffRes_hyper_steel->Release();
				lpDDSOffRes_hyper_steel = NULL;
			}
			if ( lpDDSOffRes_gold != NULL )
			{
				lpDDSOffRes_gold->Release();
				lpDDSOffRes_gold = NULL;
			}
			/////
			if ( lpDDSOffStruct_town1 != NULL )
			{
				lpDDSOffStruct_town1->Release();
				lpDDSOffStruct_town1 = NULL;
			}
			if ( lpDDSOffStruct_town2 != NULL )
			{
				lpDDSOffStruct_town2->Release();
				lpDDSOffStruct_town2 = NULL;
			}
			if ( lpDDSOffStruct_town3 != NULL )
			{
				lpDDSOffStruct_town3->Release();
				lpDDSOffStruct_town3 = NULL;
			}
			if ( lpDDSOffStruct_town4 != NULL )
			{
				lpDDSOffStruct_town4->Release();
				lpDDSOffStruct_town4 = NULL;
			}
			if ( lpDDSOffStruct_town5 != NULL )
			{
				lpDDSOffStruct_town5->Release();
				lpDDSOffStruct_town5 = NULL;
			}
			if ( lpDDSOffStruct_town_ice != NULL )
			{
				lpDDSOffStruct_town_ice->Release();
				lpDDSOffStruct_town_ice = NULL;
			}
			//
			if ( lpDDSOffStruct_town_desert1 != NULL )
			{
				lpDDSOffStruct_town_desert1->Release();
				lpDDSOffStruct_town_desert1 = NULL;
			}
			if ( lpDDSOffStruct_town_desert2 != NULL )
			{
				lpDDSOffStruct_town_desert2->Release();
				lpDDSOffStruct_town_desert2 = NULL;
			}
			if ( lpDDSOffStruct_town_desert3 != NULL )
			{
				lpDDSOffStruct_town_desert3->Release();
				lpDDSOffStruct_town_desert3 = NULL;
			}
			if ( lpDDSOffStruct_town_desert4 != NULL )
			{
				lpDDSOffStruct_town_desert4->Release();
				lpDDSOffStruct_town_desert4 = NULL;
			}
			if ( lpDDSOffStruct_town_desert5 != NULL )
			{
				lpDDSOffStruct_town_desert5->Release();
				lpDDSOffStruct_town_desert5 = NULL;
			}
			//

			if ( lpDDSOffStruct_chemy != NULL )
			{
				lpDDSOffStruct_chemy->Release();
				lpDDSOffStruct_chemy = NULL;
			}
			if ( lpDDSOffStruct_steel != NULL )
			{
				lpDDSOffStruct_steel->Release();
				lpDDSOffStruct_steel = NULL;
			}
			if ( lpDDSOffStruct_elec != NULL )
			{
				lpDDSOffStruct_elec->Release();
				lpDDSOffStruct_elec = NULL;
			}
			if ( lpDDSOffStruct_church != NULL )
			{
				lpDDSOffStruct_church->Release();
				lpDDSOffStruct_church = NULL;
			}
			if ( lpDDSOffStruct_palace != NULL )
			{
				lpDDSOffStruct_palace->Release();
				lpDDSOffStruct_palace = NULL;
			}
			if ( lpDDSOffStruct_ruins != NULL )
			{
				lpDDSOffStruct_ruins->Release();
				lpDDSOffStruct_ruins = NULL;
			}
			if ( lpDDSOffStruct_well != NULL )
			{
				lpDDSOffStruct_well->Release();
				lpDDSOffStruct_well = NULL;
			}
			if ( lpDDSOffStruct_offshore_well != NULL )
			{
				lpDDSOffStruct_offshore_well->Release();
				lpDDSOffStruct_offshore_well = NULL;
			}
			if ( lpDDSOffStruct_mine != NULL )
			{
				lpDDSOffStruct_mine->Release();
				lpDDSOffStruct_mine = NULL;
			}
			if ( lpDDSOffStruct_farm != NULL )
			{
				lpDDSOffStruct_farm->Release();
				lpDDSOffStruct_farm = NULL;
			}
			if ( lpDDSOffStruct_farm_land != NULL )
			{
				lpDDSOffStruct_farm_land->Release();
				lpDDSOffStruct_farm_land = NULL;
			}
			if ( lpDDSOffStruct_factory != NULL )
			{
				lpDDSOffStruct_factory->Release();
				lpDDSOffStruct_factory = NULL;
			}
			if ( lpDDSOffStruct_starport != NULL )
			{
				lpDDSOffStruct_starport->Release();
				lpDDSOffStruct_starport = NULL;
			}
			if ( lpDDSOffStruct_fort != NULL )
			{
				lpDDSOffStruct_fort->Release();
				lpDDSOffStruct_fort = NULL;
			}
			if ( lpDDSOffStruct_barracks != NULL )
			{
				lpDDSOffStruct_barracks->Release();
				lpDDSOffStruct_barracks = NULL;
			}
			if ( lpDDSOffStruct_uni != NULL )
			{
				lpDDSOffStruct_uni->Release();
				lpDDSOffStruct_uni = NULL;
			}
			if ( lpDDSOffStruct_lab != NULL )
			{
				lpDDSOffStruct_lab->Release();
				lpDDSOffStruct_lab = NULL;
			}
			if ( lpDDSOffStruct_farm_enc != NULL )
			{
				lpDDSOffStruct_farm_enc->Release();
				lpDDSOffStruct_farm_enc = NULL;
			}
			/////////
			if ( lpDDSOffCoast_a_1 != NULL )
			{
				lpDDSOffCoast_a_1->Release();
				lpDDSOffCoast_a_1 = NULL;
			}
			if ( lpDDSOffCoast_b_1 != NULL )
			{
				lpDDSOffCoast_b_1->Release();
				lpDDSOffCoast_b_1 = NULL;
			}
			if ( lpDDSOffCoast_a_2 != NULL )
			{
				lpDDSOffCoast_a_2->Release();
				lpDDSOffCoast_a_2 = NULL;
			}
			if ( lpDDSOffCoast_b_2 != NULL )
			{
				lpDDSOffCoast_b_2->Release();
				lpDDSOffCoast_b_2 = NULL;
			}
			if ( lpDDSOffCoast_a_3 != NULL )
			{
				lpDDSOffCoast_a_3->Release();
				lpDDSOffCoast_a_3 = NULL;
			}
			if ( lpDDSOffCoast_b_3 != NULL )
			{
				lpDDSOffCoast_b_3->Release();
				lpDDSOffCoast_b_3 = NULL;
			}
			////////
			if ( lpDDSOffCoast_a_1_ice != NULL )
			{
				lpDDSOffCoast_a_1_ice->Release();
				lpDDSOffCoast_a_1_ice = NULL;
			}
			if ( lpDDSOffCoast_b_1_ice != NULL )
			{
				lpDDSOffCoast_b_1_ice->Release();
				lpDDSOffCoast_b_1_ice = NULL;
			}
			if ( lpDDSOffCoast_a_2_ice != NULL )
			{
				lpDDSOffCoast_a_2_ice->Release();
				lpDDSOffCoast_a_2_ice = NULL;
			}
			if ( lpDDSOffCoast_b_2_ice != NULL )
			{
				lpDDSOffCoast_b_2_ice->Release();
				lpDDSOffCoast_b_2_ice = NULL;
			}
			if ( lpDDSOffCoast_a_3_ice != NULL )
			{
				lpDDSOffCoast_a_3_ice->Release();
				lpDDSOffCoast_a_3_ice = NULL;
			}
			if ( lpDDSOffCoast_b_3_ice != NULL )
			{
				lpDDSOffCoast_b_3_ice->Release();
				lpDDSOffCoast_b_3_ice = NULL;
			}
			/////////
			if ( lpDDSOffCoast_a_1_desert != NULL )
			{
				lpDDSOffCoast_a_1_desert->Release();
				lpDDSOffCoast_a_1_desert = NULL;
			}
			if ( lpDDSOffCoast_b_1_desert != NULL )
			{
				lpDDSOffCoast_b_1_desert->Release();
				lpDDSOffCoast_b_1_desert = NULL;
			}
			if ( lpDDSOffCoast_a_2_desert != NULL )
			{
				lpDDSOffCoast_a_2_desert->Release();
				lpDDSOffCoast_a_2_desert = NULL;
			}
			if ( lpDDSOffCoast_b_2_desert != NULL )
			{
				lpDDSOffCoast_b_2_desert->Release();
				lpDDSOffCoast_b_2_desert = NULL;
			}
			if ( lpDDSOffCoast_a_3_desert != NULL )
			{
				lpDDSOffCoast_a_3_desert->Release();
				lpDDSOffCoast_a_3_desert = NULL;
			}
			if ( lpDDSOffCoast_b_3_desert != NULL )
			{
				lpDDSOffCoast_b_3_desert->Release();
				lpDDSOffCoast_b_3_desert = NULL;
			}
			//////
			if ( lpDDSOffCoast_a_1_lava != NULL )
			{
				lpDDSOffCoast_a_1_lava->Release();
				lpDDSOffCoast_a_1_lava = NULL;
			}
			if ( lpDDSOffCoast_b_1_lava != NULL )
			{
				lpDDSOffCoast_b_1_lava->Release();
				lpDDSOffCoast_b_1_lava = NULL;
			}
			if ( lpDDSOffCoast_a_2_lava != NULL )
			{
				lpDDSOffCoast_a_2_lava->Release();
				lpDDSOffCoast_a_2_lava = NULL;
			}
			if ( lpDDSOffCoast_b_2_lava != NULL )
			{
				lpDDSOffCoast_b_2_lava->Release();
				lpDDSOffCoast_b_2_lava = NULL;
			}
			if ( lpDDSOffCoast_a_3_lava != NULL )
			{
				lpDDSOffCoast_a_3_lava->Release();
				lpDDSOffCoast_a_3_lava = NULL;
			}
			if ( lpDDSOffCoast_b_3_lava != NULL )
			{
				lpDDSOffCoast_b_3_lava->Release();
				lpDDSOffCoast_b_3_lava = NULL;
			}
			////////
			if ( lpDDSOffCoast_a_1_exotic != NULL )
			{
				lpDDSOffCoast_a_1_exotic->Release();
				lpDDSOffCoast_a_1_exotic = NULL;
			}
			if ( lpDDSOffCoast_b_1_exotic != NULL )
			{
				lpDDSOffCoast_b_1_exotic->Release();
				lpDDSOffCoast_b_1_exotic = NULL;
			}
			if ( lpDDSOffCoast_a_2_exotic != NULL )
			{
				lpDDSOffCoast_a_2_exotic->Release();
				lpDDSOffCoast_a_2_exotic = NULL;
			}
			if ( lpDDSOffCoast_b_2_exotic != NULL )
			{
				lpDDSOffCoast_b_2_exotic->Release();
				lpDDSOffCoast_b_2_exotic = NULL;
			}
			if ( lpDDSOffCoast_a_3_exotic != NULL )
			{
				lpDDSOffCoast_a_3_exotic->Release();
				lpDDSOffCoast_a_3_exotic = NULL;
			}
			if ( lpDDSOffCoast_b_3_exotic != NULL )
			{
				lpDDSOffCoast_b_3_exotic->Release();
				lpDDSOffCoast_b_3_exotic = NULL;
			}
			////////
			if ( lpDDSOffAdInfinitum != NULL )
            {
				lpDDSOffAdInfinitum->Release();
				lpDDSOffAdInfinitum = NULL;
			}
			/////
				if ( lpDDSOffGasGiant1 != NULL )
			{
				lpDDSOffGasGiant1->Release();
				lpDDSOffGasGiant1 = NULL;
			}
			////
			if ( lpDDSOffAtmos1 != NULL )
			{
				lpDDSOffAtmos1->Release();
				lpDDSOffAtmos1 = NULL;
			}
			if ( lpDDSOffAtmos2 != NULL )
			{
				lpDDSOffAtmos2->Release();
				lpDDSOffAtmos2 = NULL;
			}
			if ( lpDDSOffAtmos3 != NULL )
			{
				lpDDSOffAtmos3->Release();
				lpDDSOffAtmos3 = NULL;
			}
			if ( lpDDSOffAtmos4 != NULL )
			{
				lpDDSOffAtmos4->Release();
				lpDDSOffAtmos4 = NULL;
			}
			if ( lpDDSOffAtmos5 != NULL )
			{
				lpDDSOffAtmos5->Release();
				lpDDSOffAtmos5 = NULL;
			}
			if ( lpDDSOffAtmos6 != NULL )
			{
				lpDDSOffAtmos6->Release();
				lpDDSOffAtmos6 = NULL;
			}
			//
			if ( lpDDSOffflags1 != NULL )
			{
				lpDDSOffflags1->Release();
				lpDDSOffflags1 = NULL;
			}
			if ( lpDDSOffflags2 != NULL )
			{
				lpDDSOffflags2->Release();
				lpDDSOffflags2 = NULL;
			}
			if ( lpDDSOffflagpole != NULL )
			{
				lpDDSOffflagpole->Release();
				lpDDSOffflagpole = NULL;
			}

			if ( lpDDSOffNoble != NULL )
			{
				lpDDSOffNoble->Release();
				lpDDSOffNoble = NULL;
			}
			if ( lpDDSOffInfantry_1 != NULL )
			{
				lpDDSOffInfantry_1->Release();
				lpDDSOffInfantry_1 = NULL;
			}
			if ( lpDDSOffInfantry_2 != NULL )
			{
				lpDDSOffInfantry_2->Release();
				lpDDSOffInfantry_2 = NULL;
			}
			if ( lpDDSOffInfantry_3 != NULL )
			{
				lpDDSOffInfantry_3->Release();
				lpDDSOffInfantry_3 = NULL;
			}
			if ( lpDDSOffInfantry_4 != NULL )
			{
				lpDDSOffInfantry_4->Release();
				lpDDSOffInfantry_4 = NULL;
			}
			if ( lpDDSOffInfantry_5 != NULL )
			{
				lpDDSOffInfantry_5->Release();
				lpDDSOffInfantry_5 = NULL;
			}



            lpDDSPrimary->Release();
            lpDDSPrimary = NULL;
        }
        lpDD->Release();
        lpDD = NULL;
    }


}

BOOL Fail( HWND hwnd,  char *szMsg )
{
    debugfile ("...FAIL...\n",1 );
    ReleaseObjects();
	OutputDebugString( szMsg );
    DestroyWindow( hwnd );
    return FALSE;
}
