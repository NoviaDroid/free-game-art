
void UpdateFrame(void)
	{
	cursorOff=false;

   if (regenerate==true)  {CloseLinkedList(); Remove_all_Planets(); galaxy(); Creat_Nebula (); Creat_GasGiant (); regenerate=false;}

   if (startgame==true)                   // if start: black out screen
   	{                                     // and map blt
      	FillScreen();
         FillMap();
         debugfile ( "Source color keying...\n",1 );
         SmalleStarsOnMap();

		 ///test ai set up with high steward
		 Steward_setup ( );
      }

   waiting_list();
   Unit_Task_waiting_list();

   if      (ScreenType==WORLD)   {	UpdateWorld ();	}
   else if (ScreenType==MAP)     {	UpdateMap ();	}
   else if (ScreenType==SYSTEM)  {	UpdateSystem ();	}





   // check if button pressed  in region of buttons
/*
       if  ((LMouseDown==1 && xPos>490 && yPos<180)||(startgame==true))
       	{
          	buttonsStatus();
		  }
*/

	// cursor (artificial !!) note size = 32x32   and set for NULL
   if (Cursor_Type!=NONE)
	{
		if (Cursor_Type == FLAG_ICON_CURSOR)
		{
			Draw_cursor_unit_select ();
		}
		else
		{
			RECT rcRect_get_icon;
			RECT rcRect_put_icon;
			int icon_type=Cursor_Type;
			if (icon_type>100)
			{
            		icon_type=icon_type-100;
			}
			rcRect_get_icon.left=0+((icon_type-1)*30);
			rcRect_get_icon.right=30+((icon_type-1)*30);
			rcRect_get_icon.top=0;
			rcRect_get_icon.bottom=30;

			rcRect_put_icon.left= xPos+10;
			rcRect_put_icon.right= (xPos)+((10+30));
			rcRect_put_icon.top= yPos+10;
			rcRect_put_icon.bottom= yPos+((10+30));


			lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffIcons1, &rcRect_get_icon,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
		}
	}
	//lpDDSBack->BltFast( xPos,yPos , lpDDSOffCursor, NULL,
	//									   DDBLTFAST_WAIT |
	//									   DDBLTFAST_SRCCOLORKEY );


					//LMouse_triger=false;


					//debug///images to see actions here///
					/*
					if ( LMouseDown==true )
					{
						lpDDSBack->BltFast( 0,0, lpDDSOffIcons1, NULL,
										   DDBLTFAST_WAIT |
										   DDBLTFAST_SRCCOLORKEY );
					}
					if ( LMouseDown==false )
					{

					lpDDSBack->BltFast ( 0,0 , lpDDSOffStruct_barracks, NULL,
												    DDBLTFAST_WAIT |
										   			DDBLTFAST_SRCCOLORKEY );
					}
					if ( LMouse_triger==false )
					{

					lpDDSBack->BltFast ( 120,0 , lpDDSOffStruct_fort, NULL,
													DDBLTFAST_WAIT |
										   			DDBLTFAST_SRCCOLORKEY );
					}
					if ( LMouse_triger==true )
					{

					lpDDSBack->BltFast ( 120,0 , lpDDSOffStruct_starport, NULL,
													DDBLTFAST_WAIT |
										   			DDBLTFAST_SRCCOLORKEY );
					}

					*/
	// Finally, perform the flip.
    lpDDSPrimary->Flip( NULL, DDFLIP_WAIT );

    return ;
	}

