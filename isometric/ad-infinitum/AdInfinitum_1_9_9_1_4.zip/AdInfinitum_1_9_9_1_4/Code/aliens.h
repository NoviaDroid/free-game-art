void ai_task(short int alien_number)
{
   long Distance;
   long xdist; long ydist; short int n=0;
   short int time;
   short int start_time;
	// go through interesting planets
	do												 // do closest worlds
   	{
      	if (  worldlist[alien_number].status[n]==UNEXPLORED  )
         {
         	worldlist[alien_number].status[n]=COLONISSED; // basic system
            short int location= worldlist[alien_number].number[n];
            short int build_at= worldlist[alien_number].capital;
            // now give task to waiting_list
            short int doing=COLONISSED;
			xdist= (star[worldlist[alien_number].capital].x+4000)
					- (star[worldlist[alien_number].number[n]].x+4000) ;
			ydist= (star[worldlist[alien_number].capital].y+4000)
					- (star[worldlist[alien_number].number[n]].y+4000) ;
			xdist= abs ( xdist );
			ydist= abs ( ydist );
			Distance=  (sqrt ( (xdist*xdist)+(ydist*ydist)+ 0.0000001 ) );
			if (n==9)
			{
				time= ( TotalSec+(Distance)*100 );
			}
			else {time= ( TotalSec+(Distance)*5 );}   // add distance
			start_time=TotalSec;
			CreateShip( location, build_at, doing, time, start_time );
            CreateTask( alien_number, location, doing, time, start_time );
            n=10;
         }
		 n++;
      }
      while ( n<10 );
}

void ai_setup()
{
    InitLinkedList();
    //long Distance;
    //long xdist; long ydist;
    short int NextRace=0;
    for ( short int m=0; m<NumberStars; m++ )   // find new home world locations
    {
    	if ( star[m].alien == true ) { worldlist[NextRace].capital=m; NextRace++; }
    }
    for ( short int n=0; n<GREATER_RACES; n++ )
    {
         for (short int nn=0; nn<10; nn++) // closest worlds
         {
         	worldlist[n].number[nn]=star[worldlist[n].capital].Neighbour[nn];
            worldlist[n].status[nn]=UNEXPLORED;
         }  // ten closest worlds are now on to see list
         short int location= worldlist[n].number[0];
		 worldlist[n].status[0]=COLONISSED; // basic system

		 int xdist= (star[worldlist[n].capital].x+4000)
					- (star[worldlist[n].number[0]].x+4000) ;
		 int ydist= (star[worldlist[n].capital].y+4000)
					- (star[worldlist[n].number[0]].y+4000) ;
		 xdist= abs ( xdist );
		 ydist= abs ( ydist );
		 long Distance=  (sqrt ( (xdist*xdist)+(ydist*ydist)+ 0.0000001 ) );
		 short int time= ( TotalSec+(Distance)*5 );   // add distance



		 unsigned int fin_time	=time;
         short int race_number=n;
         unsigned int start_time=TotalSec;
         short int doing=COLONISSED;
         CreateTask( race_number, location, doing,
								fin_time, start_time );
         CreateShip( location, worldlist[n].capital, doing,
							fin_time, start_time );
    }

}

void waiting_list()
{
   short int alien_num;
   if ( g_top_task != (LPTASK) NULL  )
   {
		if ( (g_top_task->time) <= TotalSec  )
   	{
		alien_num = g_top_task->alien_id;
   		star [g_top_task->location].alien=true;
      	RemoveTask( g_top_task );
      	ai_task(alien_num);
   	}
   }
   //else  ai_setup();
}


////////////////////////////////////////////////
///slip task set up and use for now by ai here

///task: wait
int Unit_Wait_Random_Time (
								LPunit TheUnit    // the unit to be added
			  				)
{
	//debugfile ("HS waiting\n", 1 );
	//return false;   /////debug

	DWORD 	Finish_Time;
    DWORD 	Start_Time;

	Start_Time=  dwCopy_time;
	Finish_Time= (random(UNIT_WAIT_TIME)*1000)+dwCopy_time;

	TheUnit->task = get_doing_task	( 	        TheUnit,
												(LPunit) NULL,
												(LPUNIT_DOING_TASK) NULL,
												(LPUNIT_DOING_TASK) NULL,
												TheUnit->hex_x_loc,
												TheUnit->hex_y_loc,
												TheUnit->hex_x_loc,
												TheUnit->hex_y_loc,
												WAITING,
												Finish_Time,
												Start_Time

												   				 			);
	//debugfile ("HS going to add wait task\n", dwCopy_time );

	Add_unit_Task ( TheUnit->task );

	//debugfile ("HS added task to wait\n", Finish_Time );

	return true;
}


///task: go to random location

int Unit_Go_Random_Location (
								LPunit TheUnit    // the unit to be added
			  				)
{
	int dice;
	int type_of_desty=10;
	//find random destination
	dice=random(10)+1;
	if (dice==1)
		{
			type_of_desty=FACTORY;
		}
	if (dice==2)
		{
			type_of_desty=CHEMY;
		}
	if (dice==3)
		{
			type_of_desty=STEEL;
		}
	if (dice==4)
		{
			type_of_desty=ELEC;
		}
	if (dice==5)
		{
			type_of_desty=FARM;
		}
	if (dice==6)
		{
			type_of_desty=MINE;
		}
	if (dice==7)
		{
			type_of_desty=WELL;
		}
	if (dice==8)
		{
			type_of_desty=STARPORT;
		}
	if (dice==9)
		{
			type_of_desty=FORT;
		}
	if (dice==10)
		{
			type_of_desty=TOWN;
		}

	//TOWN=1

/////FACTORY=2;
/////CHURCH=3;
/////PALACE=4;
/////CHEMY=6;
//const unsigned char STEEL=5;
/////ELEC=7;
/////FARM=8;
/////FARM_LAND=9;
/////MINE=10;
//////WELL=11;
//////OFFSHORE_WELL=12;
//////RUINS=13;
//////STARPORT=14;
//////FORT=15;
///////BARRACKS=16;
//////UNI=17;
//////LAB=18;
//////ENCLOSED_FARM=19;


	if (find_path_ai_patrol (TheUnit, type_of_desty, TheUnit->hex->planet ) ==true)

	  {return true;}

	return false;
}

void Steward_setup ( )

{
	//return;
	int dice;
	if ( unit_first_in_list != (LPunit) NULL )
	{
		for ( LPunit theunit=unit_first_in_list; theunit!=(LPunit)NULL; theunit=theunit->next )
		{
			if (theunit->aligence == HIGH_STEWARD )
				{
					dice=dice=random(100)+1;
					if (dice>90)
					{
						if ( Unit_Go_Random_Location (theunit) == false )
						{
							Unit_Wait_Random_Time ( theunit );
						}
					}
					else
					{
							Unit_Wait_Random_Time ( theunit );
					}
				}
		}

	}


}

