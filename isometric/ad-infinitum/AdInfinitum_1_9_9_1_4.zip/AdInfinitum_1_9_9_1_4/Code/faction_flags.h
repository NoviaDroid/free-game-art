////////////plag placement////////////

/////flag draw////////
///
void flag_draw( LPhex hex_with_units, int x_location, int y_location )
{
   RECT			rcRect_put_flag;
   RECT			rcRect_get_flag;
   RECT			rcRect_put_pole;
   RECT			rcRect_get_pole;
   unsigned char Flag_size=LARGE;
   int flag_frame=1;//default
   int Flag_row=1 ;//default
   int number_of_flags=1;//default
   int units_location_x;
   int units_location_y;
   int units_aligence;
   //
   LPunit Next_Unit_as_flag= (LPunit)NULL;
   LPunit Unit_as_flag;
   for ( Unit_as_flag=hex_with_units->unit_in_hex; Unit_as_flag != (LPunit)NULL ; Unit_as_flag=Next_Unit_as_flag )
   {
		//set variables
		Next_Unit_as_flag= Unit_as_flag->next_in_hex;
		units_aligence	 = Unit_as_flag->aligence;
		units_location_x = Unit_as_flag->hex_x_loc;
		units_location_y = Unit_as_flag->hex_y_loc;

		////flag colour///
		if (units_aligence==NUTRAL)
		{
			Flag_row=0   ;
		}
		if (units_aligence==RED)
		{
			Flag_row=1   ;
		}
		if (units_aligence==BLEU)
		{
			Flag_row=2   ;
		}
		if (units_aligence==YELLOW)
		{
			Flag_row=3   ;
		}
		if (units_aligence==GUILD)
		{
			Flag_row=4   ;
		}
		if (units_aligence==GREEN)
		{
			Flag_row=5   ;
		}
		if (units_aligence==HIGH_STEWARD)
		{
			Flag_row=6   ;
		}
		if (units_aligence==ORANGE)
		{
			Flag_row=8   ;
		}
		///flag size///
		//if (Unit_as_flag->blank1!=NULL)
		//{
			 //////officer see/////
		//}

		// rect for flag pole//
		rcRect_put_pole.left= x_location+(units_location_x-1)/ZooM;
		rcRect_put_pole.right= x_location+(units_location_x+1)/ZooM;
		rcRect_put_pole.top= y_location+(units_location_y-40)/ZooM;
		rcRect_put_pole.bottom= y_location+(units_location_y)/ZooM;

		rcRect_get_pole.left=0;
		rcRect_get_pole.right=2;
		rcRect_get_pole.top=0;
		rcRect_get_pole.bottom=39;

		// rect for flag//
		rcRect_put_flag.left= x_location+(units_location_x)/ZooM;
		rcRect_put_flag.right= x_location+(units_location_x+60)/ZooM;
		rcRect_put_flag.top= y_location+(units_location_y-40)/ZooM;
		rcRect_put_flag.bottom= y_location+(units_location_y-40+26)/ZooM;

		flag_frame= (animation1-1)*26;

		rcRect_get_flag.left=0+(Flag_row*60);
		rcRect_get_flag.right=59+(Flag_row*59);
		rcRect_get_flag.top=flag_frame;
		rcRect_get_flag.bottom=flag_frame+26;
		//

		lpDDSBack->Blt ( &rcRect_put_pole , lpDDSOffflagpole, &rcRect_get_pole,
		DDBLT_WAIT |
		DDBLT_KEYSRC, NULL );

		lpDDSBack->Blt ( &rcRect_put_flag , lpDDSOffflags1, &rcRect_get_flag,
		DDBLT_WAIT |
		DDBLT_KEYSRC, NULL );

		// see if mouse click on flag//
		if 	(		(LMousexPos >  rcRect_put_flag.left )
				&&  (LMousexPos <= rcRect_put_flag.right)
				&&  (LMouseyPos >  rcRect_put_flag.top )
				&&  (LMouseyPos <= rcRect_put_flag.bottom)
				&&	(LMouse_Hex_Click!=false) && ( LMouse_triger==true))
		{
			Cursor_Type = FLAG_ICON_CURSOR;
			//turn off for debug
			unit_selected=Unit_as_flag;
			LMouse_triger=false;
		}

   }

}

//LPDIRECTDRAWSURFACE     lpDDSOffflagpole;
//LPDIRECTDRAWSURFACE     lpDDSOffflags1;
//LPDIRECTDRAWSURFACE     lpDDSOffflags2;

void unit_draw( LPhex hex_with_units, int x_location, int y_location )
{
   RECT			rcRect_put_unit;
   RECT			rcRect_get_unit;

   //unsigned char Flag_size=LARGE;
   int flag_frame=1;//default
   int manikin_row=1 ;//default
   int number_of_flags=1;//default
   int units_location_x;
   int units_location_y;
   int units_direction;
   int going_x ;
	int going_y  ;
	int start_x  ;
	int start_y  ;
	int Unit_Stoped=true;
	int Unit_Attacking=false;
   //
   LPunit Next_Unit_as_flag= (LPunit)NULL;
   LPunit Unit_as_flag;
   for ( Unit_as_flag=hex_with_units->unit_in_hex; Unit_as_flag != (LPunit)NULL ; Unit_as_flag=Next_Unit_as_flag )
   {
		//set variables
		Next_Unit_as_flag= Unit_as_flag->next_in_hex;
		units_direction	 = Unit_as_flag->aligence;
		units_location_x = Unit_as_flag->hex_x_loc;
		units_location_y = Unit_as_flag->hex_y_loc;
		// work out direction
		if ( Unit_as_flag->task !=  (LPUNIT_DOING_TASK) NULL )
			{

				if ( (Unit_as_flag->task->doing !=  WAITING) && (Unit_as_flag->task->doing !=  ATTACKING) )
				{
					Unit_Stoped=false;
					going_x = Unit_as_flag->task->going_to_x ;
					going_y = Unit_as_flag->task->going_to_y ;
					start_x = Unit_as_flag->task->start_at_x ;
					start_y = Unit_as_flag->task->start_at_y ;

					//eastern travel
					if (going_x > start_x)
					{
		 				//northern travel
						if (going_y >= start_y)
						{
							manikin_row= 3;
						}
						else //southern travel
						{
							manikin_row= 1;
						}
					}

					else //western travel
					{
						//northern travel
						if (going_y >= start_y)
						{
							manikin_row= 2;
						}
						else //southern travel
						{
							manikin_row= 0;
						}

					}

				}
				else ///task true but waiting or attacking
				{
					Unit_Stoped=true;
					manikin_row= 3;

					if ( ( Unit_as_flag->task->doing ==  ATTACKING ) )
					{
						//manikin_row= 4;
						Unit_Attacking=true;
						Unit_Stoped=true;
					}
				}
			}
		else //no task
			{
				Unit_Stoped=true;
				manikin_row= 3;
			}


		// rect for unit// 32x 49y
		rcRect_put_unit.left= x_location+(units_location_x-16)/ZooM;
		rcRect_put_unit.right= x_location+(units_location_x+32-16)/ZooM;
		rcRect_put_unit.top= y_location+(units_location_y-49)/ZooM;
		rcRect_put_unit.bottom= y_location+(units_location_y)/ZooM;

		if (Unit_Stoped!=true)
			{
				flag_frame= (animation2-1)*32;

			}
		else
			{
				flag_frame= 0;

				if ( (Unit_Attacking!=true) || (Unit_as_flag->type==NOBLE) )
				{

					if (Unit_as_flag->facing==EAST)
					{
						manikin_row= 3;
					}
					if (Unit_as_flag->facing==WEST)
					{
						manikin_row= 2;
					}
					if (Unit_as_flag->facing==NORTH_EAST)
					{
						manikin_row= 3;
					}
					if (Unit_as_flag->facing==NORTH_WEST)
					{
						manikin_row= 2;
					}
					if (Unit_as_flag->facing==SOUTH_EAST)
					{
						manikin_row= 1;
					}
					if (Unit_as_flag->facing==SOUTH_WEST)
					{
						manikin_row= 0;
					}

				}




			}



		//debugfile ("rcRect_get_unit.left\n", rcRect_get_unit.left );
		//debugfile ("rcRect_get_unit.right\n", rcRect_get_unit.right );

	//
		if ( (Unit_Attacking==true) && (Unit_as_flag->type!=NOBLE) )
		{
				int mirror_image=false;

					if (Unit_as_flag->facing==EAST)
					{
						flag_frame= 2;
						mirror_image=true;
					}
					if (Unit_as_flag->facing==WEST)
					{
						flag_frame= 2;
						mirror_image=false;
					}
					if (Unit_as_flag->facing==NORTH_EAST)
					{
						flag_frame= 0;
						mirror_image=true;
					}
					if (Unit_as_flag->facing==NORTH_WEST)
					{
						flag_frame= 0;
						mirror_image=false;
					}
					if (Unit_as_flag->facing==SOUTH_EAST)
					{
						flag_frame= 1;
						mirror_image=false;
					}
					if (Unit_as_flag->facing==SOUTH_WEST)
					{
						flag_frame= 1;
						mirror_image=true;
					}

			flag_frame=flag_frame*32;

			rcRect_get_unit.top   =  0 + (  2  *49);
			rcRect_get_unit.bottom= 48 + (  2  *48);
			rcRect_get_unit.left  =flag_frame;
			rcRect_get_unit.right =flag_frame+32;

			if ( Unit_as_flag->type == INFANTRY_1 )
			{
				if (mirror_image==false)
					{
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_1, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
					}

				else
					{
						ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_1, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
					}
			}
			if ( Unit_as_flag->type == INFANTRY_2 )
			{
				if (mirror_image==false)
					{
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_2, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
					}

				else
					{
						ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_2, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
					}
			}
			if ( Unit_as_flag->type == INFANTRY_3 )
			{
				if (mirror_image==false)
					{
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_3, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
					}

				else
					{
						ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_3, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
					}
			}
			if ( Unit_as_flag->type == INFANTRY_4 )
			{
				if (mirror_image==false)
					{
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_4, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
					}

				else
					{
						ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_4, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
					}
			}
			if ( Unit_as_flag->type == INFANTRY_5 )
			{
				if (mirror_image==false)
					{
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_5, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
					}

				else
					{
						ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
						lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_5, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
					}
			}
		}
		else if (manikin_row==1 || manikin_row==2)
		{
			rcRect_get_unit.top   =  0 + ( ( manikin_row -1 ) *49);
			rcRect_get_unit.bottom= 48 + ( ( manikin_row -1 ) *48);
			rcRect_get_unit.left  =flag_frame;
			rcRect_get_unit.right =flag_frame+32;

			if ( Unit_as_flag->type == NOBLE )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffNoble, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}

			if ( Unit_as_flag->type == INFANTRY_1 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_1, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
			if ( Unit_as_flag->type == INFANTRY_2 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_2, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
			if ( Unit_as_flag->type == INFANTRY_3 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_3, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
			if ( Unit_as_flag->type == INFANTRY_4 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_4, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
			if ( Unit_as_flag->type == INFANTRY_5 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_5, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
	    }
		else
		{
			if (manikin_row==3) {manikin_row=1;}

			rcRect_get_unit.top   =0+(manikin_row*49);
			rcRect_get_unit.bottom=48+(manikin_row*48);
			rcRect_get_unit.left  =flag_frame;
			rcRect_get_unit.right =flag_frame+32;

			if ( Unit_as_flag->type == NOBLE )
			{
				ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffNoble, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
			}

			if ( Unit_as_flag->type == INFANTRY_1 )
			{
				ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_1, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
			}
			if ( Unit_as_flag->type == INFANTRY_2 )
			{
				ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_2, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
			}
			if ( Unit_as_flag->type == INFANTRY_3 )
			{
				ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_3, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
			}
			if ( Unit_as_flag->type == INFANTRY_4 )
			{
				ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_4, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
			}
			if ( Unit_as_flag->type == INFANTRY_5 )
			{
				ddbltfx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT;
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_5, &rcRect_get_unit,
									DDBLT_DDFX | DDBLT_WAIT |
									DDBLT_KEYSRC, &ddbltfx );
			}
	    }


		// see if mouse click on flag//
		if 	(		(LMousexPos >  rcRect_put_unit.left )
				&&  (LMousexPos <= rcRect_put_unit.right)
				&&  (LMouseyPos >  rcRect_put_unit.top )
				&&  (LMouseyPos <= rcRect_put_unit.bottom)
				&&	(LMouse_Hex_Click!=false) && ( LMouse_triger==true)
				&&  (  Cursor_Type != FLAG_ICON_CURSOR   ) )
		{
			Cursor_Type = FLAG_ICON_CURSOR;
			//turn off for debug
			unit_selected=Unit_as_flag;
			LMouse_triger=false;
			dwCursor_Zoom_Time_Start=dwCopy_time;
			//find_screen_unit_x=planet_see_x;
			//find_screen_unit_y=planet_see_y;
		}

   }

}

int Draw_cursor_unit_select (void)
{
		    int manikin_row=1;

			LPunit Unit_as_flag;

			RECT			rcRect_put_unit;
   			RECT			rcRect_get_unit;

			rcRect_put_unit.left= xPos+10;
			rcRect_put_unit.right= (xPos)+((10+16));
			rcRect_put_unit.top= yPos+10;
			rcRect_put_unit.bottom= yPos+((10+24));

			rcRect_get_unit.top   =  0 + ( manikin_row   * 48);
			rcRect_get_unit.bottom= 48 + ( manikin_row   * 48);
			rcRect_get_unit.left  =0;
			rcRect_get_unit.right =32;

			Unit_as_flag=unit_selected;

			if (Unit_as_flag==(LPunit)NULL) {return;}

			if ( Unit_as_flag->type == NOBLE )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffNoble, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}

			if ( Unit_as_flag->type == INFANTRY_1 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_1, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
			if ( Unit_as_flag->type == INFANTRY_2 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_2, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
			if ( Unit_as_flag->type == INFANTRY_3 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_3, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
			if ( Unit_as_flag->type == INFANTRY_4 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_4, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
			if ( Unit_as_flag->type == INFANTRY_5 )
			{
				lpDDSBack->Blt ( &rcRect_put_unit , lpDDSOffInfantry_5, &rcRect_get_unit,
									DDBLT_WAIT |
									DDBLT_KEYSRC, NULL );
			}
}
