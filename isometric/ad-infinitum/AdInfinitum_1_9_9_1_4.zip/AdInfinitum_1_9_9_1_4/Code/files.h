// prototype
//BOOL Fail( HWND hwnd,  char *szMsg );

// set debugger
int Debug_write=false;

int debugfile (char *szMsg, long number)
{
   if 	(Debug_write == false)
   {
		return false;
   }
	FILE *stream;
   //char string[40];
   //char mesg[20];

   /* open a file for update */
   stream = fopen("debug/debug.txt", "a");
   if (stream==NULL)
   {
   	  return false;
   }


   /* seek to the end of the file */
   fseek(stream, 0, SEEK_END);

   /* write a string to the file */
   //fputs(string, stream);

   fprintf(stream, "%-8ld %s", number, szMsg);

   fclose(stream);

   return true;
}




// global for input file  //set defauts
//int Debug_write=true;
int GalaxySize=1000;
int NumberStars=250;
int X_size=200;
int Y_size=200;
int MapSet=24;
int GlobeSet=12;
int Small_Place=4;
int Color_bits=32;
int screen_x=800;
int screen_y=600;
int hex_size_x=120;
int hex_size_y=60;
float ZooM=1.0;
int Num_Nebulas=1;
int hills_adjust=15;
int plant_adjust=5;

int lava_world=5;
int ice_world=10;
int temp_world=50;
int iles_world=20;
int jungle_world=10;
int moon_world=20;
int gaseous_world=10;
int desert_world=10;
int oasis_world=10;
int rocky_world=0;
int dune_world=10;
int water_world=5;

int nebula_size=3;

int resourse_rarety=4;

int Num_GasGiant=1;

int Num_workers=4;

int Unit_Speed=120;

int UNIT_WAIT_TIME=300;
int ATTACK_TIME=10;

// files loaded and saved

// load input variable file

int get_vars ()
{
   debugfile (" opening get vars ", 1 );///////////

   FILE *stream;
   char string[40];
   char stringB [40];
   char mesg[40];
   int getnum;
   //int blank;	// used for blank entrees (changed)
   //double getnum_long;

   /* open a file for update */
   stream = fopen("debug/input.txt", "r");
   if (stream==NULL)
   {

	debugfile (" could not open get vars ", 1 );///////////
	return 0;
   }

   /* seek to the start of the file */
   fseek(stream, 0, SEEK_SET);

   debugfile (" seek to the start of the file ", 1 );///////////

   /* read a string from the file */
   //fgets(mesg, strlen(string), stream);

   //debugfile (" read a string from the file ", 1 );///////////

   /* set value for the string */
   fscanf(stream,"%s %d", stringB, &getnum);
   GalaxySize = getnum;

   debugfile (" GalaxySize ", GalaxySize );///////////

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   NumberStars = getnum;

   debugfile (" NumberStars ", NumberStars );///////////


   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   X_size = getnum;


   debugfile (" X_size ", X_size );

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   Y_size = getnum;


   debugfile (" Y_size ", getnum );


	fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   MapSet= getnum;

   debugfile (" MapSet ", getnum );

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   GlobeSet= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   Small_Place= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   Color_bits= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   screen_x= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   screen_y= getnum;

   debugfile (" screen_y ", getnum );

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   hex_size_x= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   hex_size_y= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   //ZooM= 1.000*getnum;
   ZooM= (101.0*48.0)/screen_x;

   debugfile (" ZooM ", getnum );

	fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   Num_Nebulas= getnum;

	fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   hills_adjust= getnum;

   	fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   plant_adjust= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   lava_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   ice_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   temp_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   iles_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   jungle_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   moon_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   gaseous_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   desert_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   oasis_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   dune_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   rocky_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   water_world= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   nebula_size= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   resourse_rarety= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   Num_GasGiant= getnum;



   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   Num_workers= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   Unit_Speed= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   UNIT_WAIT_TIME= getnum;

   fgets(mesg, strlen(string), stream);
   fscanf(stream,"%s %d", stringB, &getnum);
   ATTACK_TIME= getnum;


   //fgets(mesg, strlen(string), stream);
   //fscanf(stream,"%s %d", stringB, &getnum);
   Debug_write= false;

   debugfile (" Debug_write ", Debug_write );


   fclose(stream);

   debugfile (" closing get vars ", 1 );///////////

   return 0;
}
