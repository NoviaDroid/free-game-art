//hex list was here


//########################################

LPHEX_LIST CreateHexPath( int xxx, int yyy, LPHEX_LIST next, LPHEX_LIST prev, int terre_value, LPHEX_LIST pt_to_last_hexlist, int direction  )
{
    // creat new list node
    LPHEX_LIST list_now;
    list_now = (LPHEX_LIST) malloc( sizeof(HEX_LIST) );
    if ( list_now == NULL )
    	{
		 debugfile ("NO MEM path list\n", terre_value );

      }
	creat_nodes++;
	list_now->x_location =   	xxx;
	list_now->y_location =   	yyy;
    list_now->next =			next;
    list_now->prev = 		prev;
	list_now->value = 		terre_value;
    list_now->creater = 	pt_to_last_hexlist;
	list_now->creater_direction= direction;

	//debugfile ("created hex list.\n", terre_value); //#/#/#/
    return list_now;
}
//#####################################
int road_value (LPplanet planet_view, LPhex terre_type)
{
	int value_adjust=0;
	if ( planet_view->planet_type==OASIS)
	{
        if ( terre_type->flag != NONE         ) { value_adjust=value_adjust+40 ;}

		if ( terre_type->road != NONE && turn_off_road_value!=true ) { return (5) ;}
		if ( terre_type->road != NONE && turn_off_road_value==true ) { return (10) ;}

		if ( terre_type->type == MOUNT         ) { return (200+value_adjust) ;}
		if ( terre_type->type == EDGE_OF_WORLD ) { return NONE ;}
		if ( terre_type->type == 255           ) { return NONE ;}
		if ( terre_type->type == HILL          ) { return (60+value_adjust) ;}
		if ( terre_type->type == PLAIN         ) { return (20+value_adjust) ;}
		if ( terre_type->type == PLANT_PLAIN   ) { return (30+value_adjust) ;}
		if ( terre_type->type == PLANT_HILL    ) { return (70+value_adjust) ;}
		if ( terre_type->type == PLANT_SWAMP    ){ return (15+value_adjust) ;}
		if ( terre_type->type == SWAMP    )      { return (12+value_adjust) ;}
		if ( terre_type->type == RIVER         ) { return (200+value_adjust) ;}
		if ( terre_type->type == HYDRO         ) { return NONE ;}
		if ( terre_type->type == SHALOW       ) { return NONE ;}
	}
	 else if ( planet_view->planet_type==DESERT)
	{
		if ( terre_type->road != NONE  && turn_off_road_value!=true ) { return (5) ;}
		if ( terre_type->road != NONE && turn_off_road_value==true  ) { return (10);}
		if ( terre_type->type == MOUNT         ) { return (200+value_adjust) ;}
		if ( terre_type->type == EDGE_OF_WORLD ) { return NONE ;}
		if ( terre_type->type == 255           ) { return NONE ;}
		if ( terre_type->type == HILL          ) { return (60+value_adjust) ;}
		if ( terre_type->type == PLAIN         ) { return (20+value_adjust) ;}
		if ( terre_type->type == PLANT_PLAIN   ) { return (30+value_adjust) ;}
		if ( terre_type->type == PLANT_HILL    ) { return (70+value_adjust) ;}
		if ( terre_type->type == PLANT_SWAMP   ) { return (15+value_adjust) ;}
		if ( terre_type->type == SWAMP         ) { return (10+value_adjust) ;}
		if ( terre_type->type == RIVER         ) { return (200+value_adjust);}
		if ( terre_type->type == HYDRO         ) { return (40+value_adjust) ;}
		if ( terre_type->type == SHALOW        ) { return (40+value_adjust) ;}
		if ( terre_type->type == DEEP          ) { return (40+value_adjust) ;}
	}
	else
	{
		if ( terre_type->flag != NONE         ) { value_adjust=value_adjust+40 ;}

		if ( terre_type->road != NONE   && turn_off_road_value!=true      ) { return (5) ;}
		if ( terre_type->road != NONE && turn_off_road_value==true ) { return (10) ;}

		if ( terre_type->type == MOUNT         ) { return (200+value_adjust) ;}
		if ( terre_type->type == EDGE_OF_WORLD ) { return NONE ;}
		if ( terre_type->type == 255           ) { return NONE ;}//river loop
		if ( terre_type->type == HILL          ) { return (60+value_adjust) ;}
		if ( terre_type->type == PLAIN         ) { return (12+value_adjust) ;}
		if ( terre_type->type == PLANT_PLAIN   ) { return (30+value_adjust) ;}
		if ( terre_type->type == PLANT_HILL    ) { return (70+value_adjust) ;}
		if ( terre_type->type == PLANT_SWAMP   ) { return (120+value_adjust) ;}
		if ( terre_type->type == SWAMP         ) { return (100+value_adjust) ;}
		if ( terre_type->type == RIVER         ) { return (200+value_adjust) ;}
		if ( terre_type->type == HYDRO         ) { return NONE ;}
		if ( terre_type->type == SHALOW       ) { return NONE ;}
		if ( terre_type->type == DEEP       ) { return NONE ;}
	}
	return NONE ;
}
///////////////////////////////////////////////////////////
int transport_value (LPplanet planet_view, LPhex terre_type)
{
	int value_adjust=0;
	if ( planet_view->planet_type==OASIS)
	{
        if ( terre_type->flag != NONE         ) { value_adjust=value_adjust+40 ;}

		if ( terre_type->road != NONE && turn_off_road_value!=true ) { return (1) ;}
		if ( terre_type->road != NONE && turn_off_road_value==true ) { return (1) ;}

		if ( terre_type->type == MOUNT         ) { return (200+value_adjust) ;}
		if ( terre_type->type == EDGE_OF_WORLD ) { return NONE ;}
		if ( terre_type->type == 255           ) { return NONE ;}
		if ( terre_type->type == HILL          ) { return (60+value_adjust) ;}
		if ( terre_type->type == PLAIN         ) { return (20+value_adjust) ;}
		if ( terre_type->type == PLANT_PLAIN   ) { return (30+value_adjust) ;}
		if ( terre_type->type == PLANT_HILL    ) { return (70+value_adjust) ;}
		if ( terre_type->type == PLANT_SWAMP   ) { return (15+value_adjust) ;}
		if ( terre_type->type == SWAMP         ) { return (12+value_adjust) ;}
		if ( terre_type->type == RIVER         ) { return (200+value_adjust) ;}
		if ( terre_type->type == HYDRO         ) { return 250 ;}
		if ( terre_type->type == SHALOW        ) { return 250 ;}
	}
	 else if ( planet_view->planet_type==DESERT)
	{
		if ( terre_type->road != NONE  && turn_off_road_value!=true       ) { return (1) ;}
		if ( terre_type->road != NONE && turn_off_road_value==true ) { return (1) ;}
		if ( terre_type->type == MOUNT         ) { return (200+value_adjust) ;}
		if ( terre_type->type == EDGE_OF_WORLD ) { return NONE ;}
		if ( terre_type->type == 255           ) { return NONE ;}
		if ( terre_type->type == HILL          ) { return (60+value_adjust) ;}
		if ( terre_type->type == PLAIN         ) { return (20+value_adjust) ;}
		if ( terre_type->type == PLANT_PLAIN   ) { return (30+value_adjust) ;}
		if ( terre_type->type == PLANT_HILL    ) { return (70+value_adjust) ;}
		if ( terre_type->type == PLANT_SWAMP    ){ return (15+value_adjust) ;}
		if ( terre_type->type == SWAMP    )      { return (10+value_adjust) ;}
		if ( terre_type->type == RIVER         ) { return (200+value_adjust) ;}
		if ( terre_type->type == HYDRO         ) { return (40+value_adjust) ;}
		if ( terre_type->type == SHALOW       ) { return (40+value_adjust) ;}
		if ( terre_type->type == DEEP       ) { return (40+value_adjust) ;}
	}
	else
	{
		if ( terre_type->flag != NONE         ) { value_adjust=value_adjust+40 ;}

		if ( terre_type->road != NONE   && turn_off_road_value!=true      ) { return (1) ;}
		if ( terre_type->road != NONE && turn_off_road_value==true ) { return (1) ;}

		if ( terre_type->type == MOUNT         ) { return (200+value_adjust) ;}
		if ( terre_type->type == EDGE_OF_WORLD ) { return NONE ;}
		if ( terre_type->type == 255           ) { return NONE ;}//river loop
		if ( terre_type->type == HILL          ) { return (60+value_adjust) ;}
		if ( terre_type->type == PLAIN         ) { return (12+value_adjust) ;}
		if ( terre_type->type == PLANT_PLAIN   ) { return (30+value_adjust) ;}
		if ( terre_type->type == PLANT_HILL    ) { return (70+value_adjust) ;}
		if ( terre_type->type == PLANT_SWAMP    ){ return (120+value_adjust) ;}
		if ( terre_type->type == SWAMP    )      { return (100+value_adjust) ;}
		if ( terre_type->type == RIVER         ) { return (200+value_adjust) ;}
		if ( terre_type->type == HYDRO         ) { return 100 ;}
		if ( terre_type->type == SHALOW       ) { return 200 ;}
		if ( terre_type->type == DEEP       ) { return 100 ;}
	}
	return NONE ;
}
//######################################
int hex_list_add (LPHEX_LIST pt_creater, int xxx, int yyy, int current_value, int dest_xxx, int dest_yyy, int desti_type, LPplanet planet_creat, int direction, int value_type )
{
	  //debugfile (" adding to hex list.\n", 1 ); //#/#/#/
	  LPHEX_LIST list_temp;   // temp hex_list for "for (;;)"
	  int the_terrain_value ;

	 // first check if not allready got hex
      for ( list_temp=g_top_hex_list; list_temp != (LPHEX_LIST)NULL; list_temp=list_temp->next )
      {
		  if ( (list_temp->x_location == xxx) && (list_temp->y_location == yyy) )
		  {
			//debugfile ("already got hex.\n", 1 ); //#/#/#/
			return false;
		  }
      }
	  //debugfile ("not already got hex X.\n", xxx ); //#/#/#/
	  //debugfile ("not already got hex Y.\n", yyy ); //#/#/#/

	  LPHEX_LIST list_now;

	  //find value
	  if (value_type==ROAD)
	  {
		the_terrain_value=road_value (planet_creat,planet_creat->planet_matrice[xxx][yyy]);
	  }
	  if (value_type==TRANSPORT)
	  {
		the_terrain_value=transport_value (planet_creat,planet_creat->planet_matrice[xxx][yyy]);
	  }

	  // if terraine is no go, return
	  if (the_terrain_value == NONE)
	  {
		//debugfile ("road value is NONE.\n", 1 ); //#/#/#/
		return false;
	  }
	  // else creat node and add value to current
	  else
	  {
			// creat new list node
			list_now = CreateHexPath( xxx, yyy, (LPHEX_LIST) NULL, (LPHEX_LIST) NULL, current_value, pt_creater, direction  );

			// give node value
			list_now->value = the_terrain_value;

			//add value
			list_now->value=list_now->value+current_value;

	  }

      if (g_bottom_hex_list == (LPHEX_LIST) NULL )
		{
		// if no other but start
		//debugfile ("no other but start.\n", 1 ); //#/#/#/
        g_bottom_hex_list = list_now;
        list_now->prev = g_top_hex_list;
        list_now->next = (LPHEX_LIST) NULL;
        g_top_hex_list->next = list_now;
    	}

	  else if ( list_now->value >= g_bottom_hex_list->value )
      {          // if greater value than the bottom of list
		//debugfile ("value is greter or equal thal bottom.\n", g_bottom_hex_list->value ); //#/#/#/
		list_now->prev = g_bottom_hex_list;
        list_now->next = (LPHEX_LIST) NULL;
        g_bottom_hex_list->next = list_now;
        g_bottom_hex_list = list_now;
      }

    	else           // else add in descending value
    	{
			for ( list_temp=g_top_hex_list; list_temp != (LPHEX_LIST)NULL; list_temp=list_temp->next )
			{
				if ( list_now->value <= list_temp->value ) // if smaller value then insert
				{
					list_temp->prev->next = list_now;
					list_now->prev = list_temp->prev;
					list_now->next = list_temp;
					list_temp->prev = list_now;
					break;
				}
			}
    	}

	  // see if hex is not desti hex
	  //debugfile ("see if not desti hex.\n", 1 ); //#/#/#/
      if ( desti_type == NONE )  //if going to a specific hex
      {
		 if ( (list_now->x_location == dest_xxx) && (list_now->y_location == dest_yyy) )
		 { desti_hex_list=list_now; return true; } ///found desti place
      }

      //else  if going to a built type of place
	  else
	  {
		 //special routine to find closest road
			if ( desti_type == ROAD )  //if going to road
			{
				//check if not farm land
				if ( (planet_creat->planet_matrice[xxx][yyy]->road !=NONE) )
				{
					//found desti
					desti_hex_list=list_now;

					return true;
				}
			}

		 if (planet_creat->planet_matrice[xxx][yyy]->build_in_hex!= (LPbuilding) NULL)
		 {
			if (planet_creat->planet_matrice[xxx][yyy]->build_in_hex->type == desti_type)
			{
				//found desti type

				desti_hex_list=list_now;

				return true;
			}
			//special routine to find any neibour
			if ( desti_type == ANY_STRUCTURE )  //if going to neibour
			{
				//check if not farm land
				if ( (planet_creat->planet_matrice[xxx][yyy]->build_in_hex->type != FARM_LAND) )
				{
					//found desti
					desti_hex_list=list_now;

					return true;
				}
			}

			///special routine to find unemployed in town, if yes, return true
			if ( desti_type == UNEMPLOYED )  //if going to an unemployed
			{
				//check if town hex
				if ( (planet_creat->planet_matrice[xxx][yyy]->build_in_hex->type == TOWN) )
				{
					//if one popu is unemployed
					//go through town popu
					for ( 	LPLABOUR town_labour=planet_creat->planet_matrice[xxx][yyy]->build_in_hex->worker;
							town_labour != (LPLABOUR)NULL;
							town_labour  = town_labour->next 			)
					{
						if (town_labour->type==UNEMPLOYED)
						{
							desti_hex_list=list_now;

							return true;
						}
					}
				}
			}
		 }
	  }
	//debugfile ("return false to loop desti.\n", 1 ); //#/#/#/
    return false;
}

//#########################################
int scan_hexes (LPHEX_LIST list_loc, int nx, int ny, int value_now, int dest_xxx, int dest_yyy, int desti_type, LPplanet planet_now , int value_type)
{
	//debugfile (" scaning hexes....\n", 1 ); //#/#/#/
	int check_hex_x = nx;
	int check_hex_y = ny;
	int odd_even = (ny+1) % 2;

	 /// //check east hex
	check_hex_x = nx+1;
	if ( check_hex_x >= planet_size_x )
		{ check_hex_x = 0; 	}  //go round world if over
	if ( hex_list_add (list_loc, check_hex_x, check_hex_y , value_now, dest_xxx , dest_yyy, desti_type, planet_now, WEST, value_type) == true)
		{	return true;	}


	/// //check west  hex
	check_hex_x = nx-1;
    if ( check_hex_x < 0 )
		{ check_hex_x = planet_size_x-1; }  //go round world if over
	if ( hex_list_add (list_loc, check_hex_x, check_hex_y , value_now, dest_xxx , dest_yyy, desti_type, planet_now, EAST, value_type) == true)
		{	return true;	}

	/// check north west hex
	check_hex_x = nx;
    check_hex_y = ny-1;
	if ( check_hex_y >= 0 ) //only check if not over top
		{
            if ( odd_even != 1 )
				{
					check_hex_x = nx-1;
                    if ( check_hex_x < 0 )
						{ check_hex_x = planet_size_x-1; }  //go round world if over
				}

			if ( hex_list_add (list_loc, check_hex_x, check_hex_y , value_now, dest_xxx , dest_yyy, desti_type, planet_now, SOUTH_EAST, value_type) == true)
				{	return true;	}
		}

	/// check north east hex
	check_hex_x = nx;
    check_hex_y = ny-1;
    if ( check_hex_y >= 0 ) //only check if not over top
		{
			if ( odd_even != 0 )
                {
					check_hex_x = nx+1;
					if ( check_hex_x >= planet_size_x )
						{ check_hex_x = 0; }  //go round world if over
                }
			if ( hex_list_add (list_loc, check_hex_x, check_hex_y , value_now, dest_xxx , dest_yyy, desti_type, planet_now, SOUTH_WEST, value_type) == true)
				{	return true;	}
        }

	/// check South west hex
	check_hex_x = nx;
    check_hex_y = ny+1;
	if ( check_hex_y < planet_size_y ) //only check if not over bottom
		{
            if ( odd_even != 1 )
                {
					check_hex_x = nx-1;
					if ( check_hex_x < 0 )
                        { check_hex_x = planet_size_x-1; }  //go round world if over
				}
			if ( hex_list_add (list_loc, check_hex_x, check_hex_y , value_now, dest_xxx , dest_yyy, desti_type, planet_now, NORTH_EAST, value_type) == true)
				{	return true;	}
        }

	/// check South east hex
	check_hex_x = nx;
	check_hex_y = ny+1;
	if ( check_hex_y < planet_size_y ) //only check if not over bottom
        {
			if ( odd_even != 0 )
                {
					check_hex_x = nx+1;
					if ( check_hex_x >= planet_size_x )
						{ check_hex_x = 0; }  //go round world if over
				}
			if ( hex_list_add (list_loc, check_hex_x, check_hex_y , value_now, dest_xxx , dest_yyy, desti_type, planet_now , NORTH_WEST, value_type) == true)
				{	return true;	}
		}
	//return without destination
	return false;
}


//###################################
int set_up_path (int  start_xxx, int  start_yyy, int dest_xxx, int dest_yyy, int desti_type,  LPplanet planet_doing, int search_lengh, int value_type  )
{
	 int  value_now_at;

	 //place start
	 g_top_hex_list = CreateHexPath ( start_xxx, start_yyy, (LPHEX_LIST) NULL, (LPHEX_LIST) NULL, NONE, (LPHEX_LIST) NULL, NONE  );
	 g_bottom_hex_list = (LPHEX_LIST) NULL;

	 //loop to scan , check and add

	LPHEX_LIST pointer_on_list =  g_top_hex_list;
    //debugfile ("find path starting loop\n", desti_type );
    // search loop
	for( int n=1; n<= search_lengh; n++ )
    {
	   //debugfile ("  loop num at......\n", n ); //#/#/#/
	   value_now_at = pointer_on_list-> value;


	   if ( scan_hexes ( pointer_on_list,
	                     pointer_on_list->x_location,pointer_on_list->y_location,
	                     value_now_at,
					     dest_xxx,  dest_yyy, desti_type, planet_doing, value_type) == true )
		{

			return true;
		}
	   if ( pointer_on_list->next == (LPHEX_LIST) NULL )
		 {
		 //debugfile ("NO found desti.\n", 1 );
		 return false;
		 }
	   else  {pointer_on_list = pointer_on_list->next;}

    }

	//debugfile ("NO found desti.\n", 2 ); return false;
    return false;
}

//######################################
int connect_roads ( LPHEX_LIST road_path, LPplanet planet_with_road )
{
	//debugfile ("conecting roads.\n", 1 ); //#/#/#/
	//LPhex the_hex;
	int go_to_next_hext=NONE;
	for ( LPHEX_LIST temp_path=road_path; temp_path != (LPHEX_LIST) NULL; temp_path=temp_path->creater )
		{

			//the_hex = planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location];
			//planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road = 1; // 00000001
			////
			if (go_to_next_hext==EAST)
                {
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_EAST;       // 10000000  // set flag to: west

                }
			if (go_to_next_hext==WEST)
                {
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_WEST;       // 01000000
                }
            if (go_to_next_hext==NORTH_EAST)
                {
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_SOUTH_EAST; // 00000100
                }
            if (go_to_next_hext==NORTH_WEST)
                {
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_SOUTH_WEST; // 00001000
                }
            if (go_to_next_hext==SOUTH_EAST)
                {
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_NORTH_EAST; // 00010000
                }
            if (go_to_next_hext==SOUTH_WEST)
                {
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_NORTH_WEST; // 00100000
				}
			 ////
            if (temp_path->creater_direction==EAST)
                {
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_WEST;       // 10000000  // set flag to: west

					go_to_next_hext= EAST;       // 01000000
                }
            if (temp_path->creater_direction==WEST)
                {
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_EAST;       // 01000000
					go_to_next_hext=WEST;       // 10000000
                }
			if (temp_path->creater_direction==NORTH_EAST)
				{
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_NORTH_WEST; // 00000100
					go_to_next_hext=NORTH_EAST; // 00100000
                }
            if (temp_path->creater_direction==NORTH_WEST)
                {
					planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_NORTH_EAST; // 00001000
					go_to_next_hext=NORTH_WEST; // 00010000
				}
            if (temp_path->creater_direction==SOUTH_EAST)
                {
                	planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_SOUTH_WEST; // 00010000
					go_to_next_hext=SOUTH_EAST; // 00001000
                }
            if (temp_path->creater_direction==SOUTH_WEST)
				{
					planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location]->road
					= planet_with_road->planet_matrice[temp_path->x_location][temp_path->y_location] -> road | FLAG_SOUTH_EAST; // 00100000
					go_to_next_hext=SOUTH_WEST; // 00000100
				}

		}

		return true;
}

//#######################################
void find_planet_roads ( LPplanet planet )
{
	//debugfile ("  finding roads......\n", 1 ); //#/#/#/
	///debug test: connect fort to closest town
	//find fort
	int start_x;
	int start_y;
	int dest_x;
	int dest_y;
	int desty_type=NONE;
	LPtown town_temp;
	LPtown town_temp2;

	LPbuilding building_temp;

	//////palace/////////
	for (  building_temp=planet->palace; building_temp != (LPbuilding)NULL; building_temp=building_temp->next )
	{
	  //debugfile ("  finding palace roads......\n", 1 ); //#/#/#/
	  start_x=building_temp->location_x;
	  start_y=building_temp->location_y;
	  desty_type=TOWN;
	  dest_x=NONE;
	  dest_y=NONE;

	  if ( desty_type!=NONE )
		{
			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,2000, ROAD )==true)
			{
				connect_roads ( desti_hex_list, planet );
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}


	//////star ports/////////
	for (  building_temp=planet->starports; building_temp != (LPbuilding)NULL; building_temp=building_temp->next )
	{
	  //debugfile ("finding starport roads......\n", 1 ); //#/#/#/
	  start_x=building_temp->location_x;
	  start_y=building_temp->location_y;
	  desty_type=TOWN;
	  dest_x=NONE;
	  dest_y=NONE;

	  if ( desty_type!=NONE )
		{
			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1400, ROAD )==true)
			{
				connect_roads ( desti_hex_list, planet );
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////churches/////////
	for (  building_temp=planet->churches; building_temp != (LPbuilding)NULL; building_temp=building_temp->next )
	{
	  //debugfile ("finding church roads......\n", 1 ); //#/#/#/
	  start_x=building_temp->location_x;
	  start_y=building_temp->location_y;
	  desty_type=TOWN;
	  dest_x=NONE;
	  dest_y=NONE;

	  if ( desty_type!=NONE )
		{
			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1400, ROAD )==true)
			{
				connect_roads ( desti_hex_list, planet );
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}

	///////////roads in towns///////////
	///////////part 1: housing//////////
	//debugfile ("  finding housing roads......\n", 1 ); //#/#/#/
	for (  town_temp=planet->first_town; town_temp != (LPtown)NULL; town_temp=town_temp->next )
	{
		for (  building_temp=town_temp->housing; building_temp != (LPbuilding)NULL; building_temp=building_temp->next )
		{
			start_x=building_temp->location_x;
			start_y=building_temp->location_y;
			desty_type=NONE;
			dest_x=town_temp->housing->location_x;
			dest_y=town_temp->housing->location_y;

			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,100, ROAD )==true)
			{
							connect_roads ( desti_hex_list, planet );
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
			{
							next_path = temp_path->next;
							free( temp_path );
							free_nodes++;
			}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

			turn_off_road_value=false;
		}
	}
	///////////roads in towns///////////
	///////////part 2: industry//////////
	//debugfile ("  finding industry roads......\n", 1 ); //#/#/#/
	for (  town_temp=planet->first_town; town_temp != (LPtown)NULL; town_temp=town_temp->next )
	{
		for (  building_temp=town_temp->industry; building_temp != (LPbuilding)NULL; building_temp=building_temp->next )
		{
			start_x=building_temp->location_x;
			//debugfile ("industry location x......\n", start_x ); //#/#/#/
			start_y=building_temp->location_y;
			//debugfile ("industry location x......\n", start_y ); //#/#/#/
			desty_type=NONE;
			dest_x=town_temp->housing->location_x; ///go to main house
			//debugfile ("industry go x......\n", dest_x ); //#/#/#/
			dest_y=town_temp->housing->location_y; ///go to main house
			//debugfile ("industry go y ......\n", dest_y ); //#/#/#/

			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,100, ROAD )==true)
			{
							connect_roads ( desti_hex_list, planet );
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
			{
							next_path = temp_path->next;
							free( temp_path );
							free_nodes++;
			}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

			turn_off_road_value=false;
		}
	}


	//////town to town/////////
  if (star [planet->number].owner!=HIGH_STEWARD)//debug,,,too slow!
  {
	//debugfile ("  finding tow to town roads......\n", 1 ); //#/#/#/
	for (  town_temp=planet->first_town; town_temp != (LPtown)NULL; town_temp=town_temp->next )
	{
		for (  town_temp2=planet->first_town; town_temp2 != (LPtown)NULL; town_temp2=town_temp2->next )
		{
			 if ( town_temp != town_temp2 )
			 {
				if (town_temp->housing!=(LPbuilding)NULL)
				{
					if (town_temp2->housing!=(LPbuilding)NULL)
					{
						turn_off_road_value=true;

						start_x=town_temp->housing->location_x;
						start_y=town_temp->housing->location_y;
						desty_type=NONE;
						dest_x=town_temp2->housing->location_x;
						dest_y=town_temp2->housing->location_y;

						if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,3400, ROAD )==true)
						{
							connect_roads ( desti_hex_list, planet );
						}
						// free the search list
						LPHEX_LIST next_path = (LPHEX_LIST) NULL;
						for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
						{
							next_path = temp_path->next;
							free( temp_path );
							free_nodes++;
						}
						g_bottom_hex_list= (LPHEX_LIST) NULL;
						g_top_hex_list= (LPHEX_LIST) NULL;
						desti_hex_list= (LPHEX_LIST) NULL;

						turn_off_road_value=false;

					}
				}
			 }

		}
	}
  } //###########

	//////forts/////////
	//debugfile ("  finding fort roads......\n", 1 ); //#/#/#/
	for ( LPbuilding fort_temp=planet->forts; fort_temp != (LPbuilding)NULL; fort_temp=fort_temp->next )
	{

	  start_x=fort_temp->location_x;
	  start_y=fort_temp->location_y;
	  desty_type=TOWN;
	  dest_x=NONE;
	  dest_y=NONE;

	  if ( desty_type!=NONE )
		{
			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1400, ROAD )==true)
			{
				connect_roads ( desti_hex_list, planet );
			}
			else
			{
				desty_type= ROAD;
				if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,500, ROAD )==true)
				{
					connect_roads ( desti_hex_list, planet );
				}
				else
				{
					desty_type= ANY_STRUCTURE;
					if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,600, ROAD )==true)
					{
						connect_roads ( desti_hex_list, planet );
					}
				}
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////wells/////////
	 //debugfile ("finding well roads......\n", 1 ); //#/#/#/
	for ( LPbuilding well_temp=planet->wells; well_temp != (LPbuilding)NULL; well_temp=well_temp->next )
	{

	  start_x=well_temp->location_x;
	  start_y=well_temp->location_y;
	  desty_type=TOWN;
	  dest_x=NONE;
	  dest_y=NONE;

	  if ( desty_type!=NONE )
		{
			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1400, ROAD )==true)
			{
				connect_roads ( desti_hex_list, planet );
			}
			else
			{
				desty_type= ROAD;
				if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,500, ROAD )==true)
				{
					connect_roads ( desti_hex_list, planet );
				}
				else
				{
					desty_type= ANY_STRUCTURE;
					if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,600, ROAD )==true)
					{
						connect_roads ( desti_hex_list, planet );
					}
				}
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////mines/////////
	//debugfile ("finding mine roads......\n", 1 ); //#/#/#/
	for ( LPbuilding mine_temp=planet->mines; mine_temp != (LPbuilding)NULL; mine_temp=mine_temp->next )
	{

	  start_x=mine_temp->location_x;
	  start_y=mine_temp->location_y;
	  desty_type=TOWN;
	  dest_x=NONE;
	  dest_y=NONE;

	  if ( desty_type!=NONE )
		{
			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1400, ROAD )==true)
			{
				connect_roads ( desti_hex_list, planet );
			}
			else
			{
				desty_type= ROAD;
				if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,500, ROAD )==true)
				{
					connect_roads ( desti_hex_list, planet );
				}
				else
				{
					desty_type= ANY_STRUCTURE;
					if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,600, ROAD )==true)
					{
						connect_roads ( desti_hex_list, planet );
					}
				}
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////farms/////////
	//debugfile ("finding farm roads......\n", 1 ); //#/#/#/
	for ( LPbuilding farm_temp=planet->farms; farm_temp != (LPbuilding)NULL; farm_temp=farm_temp->next )
	{
	  start_x=farm_temp->location_x;
	  start_y=farm_temp->location_y;
	  desty_type=TOWN;
	  dest_x=NONE;
	  dest_y=NONE;

	  if ( desty_type!=NONE )
		{
			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1400, ROAD )==true)
			{
				connect_roads ( desti_hex_list, planet );
			}
			else
			{
				desty_type= ROAD;
				if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,500, ROAD )==true)
				{
					connect_roads ( desti_hex_list, planet );
				}
				else
				{
					desty_type= ANY_STRUCTURE;
					if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,600, ROAD )==true)
					{
						connect_roads ( desti_hex_list, planet );
					}
				}
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}

	//////labs/////////
	//debugfile ("  finding lab roads......\n", 1 ); //#/#/#/
	for (  building_temp=planet->labs; building_temp != (LPbuilding)NULL; building_temp=building_temp->next )
	{
	  start_x=building_temp->location_x;
	  start_y=building_temp->location_y;
	  desty_type=TOWN;
	  dest_x=NONE;
	  dest_y=NONE;

	  if ( desty_type!=NONE )
		{
			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,1400, ROAD )==true)
			{
				connect_roads ( desti_hex_list, planet );
			}
			else
			{
				desty_type= ROAD;
				if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,500, ROAD )==true)
				{
					connect_roads ( desti_hex_list, planet );
				}
				else
				{
					desty_type= ANY_STRUCTURE;
					if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,600, ROAD )==true)
					{
						connect_roads ( desti_hex_list, planet );
					}
				}
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}
	//////ruins/////////
    //debugfile ("  finding lab roads......\n", 1 ); //#/#/#/
	for (  building_temp=planet->ruins; building_temp != (LPbuilding)NULL; building_temp=building_temp->next )
	{
	  start_x=building_temp->location_x;
	  start_y=building_temp->location_y;
	  desty_type=TOWN;
	  dest_x=NONE;
	  dest_y=NONE;

	  if ( desty_type!=NONE )
		{
			if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,600, ROAD )==true)
			{
				connect_roads ( desti_hex_list, planet );
			}
			else
			{
				desty_type= ROAD;
				if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,500, ROAD )==true)
				{
					connect_roads ( desti_hex_list, planet );
				}
				else
				{
					desty_type= ANY_STRUCTURE;
					if (set_up_path ( start_x, start_y, dest_x, dest_y, desty_type, planet,600, ROAD )==true)
					{
						connect_roads ( desti_hex_list, planet );
					}
				}
			}
			// free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;

		}
	}

	///////////////////

}
