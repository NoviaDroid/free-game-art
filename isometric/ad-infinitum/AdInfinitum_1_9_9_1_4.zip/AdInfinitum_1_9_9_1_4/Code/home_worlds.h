
void home_world_set_up (void)
{
   FILE *stream;
   char string[20]="12345678901234567890";
   char stringB [20];
   char mesg[20];
   //int getnum;
   //int blank;	// used for blank entrees (changed)
   //double getnum_long;

   //find center
   // center point is X_size/2  Y_size/2
   int center_X= X_size/2;
   int center_Y= Y_size/2;
   // find sectors
   int sector_1_X= X_size/6;
   int sector_1_Y= Y_size/6;

   int sector_2_X= X_size/2;
   int sector_2_Y= 0;

   int sector_3_X= (X_size/6)*5;
   int sector_3_Y= Y_size/6;

   int sector_4_X= X_size/3;
   int sector_4_Y= Y_size/2;

   int sector_6_X= (X_size/3)*2;
   int sector_6_Y= Y_size/2;

   int sector_7_X= X_size/6;
   int sector_7_Y= (Y_size/6)*5;

   int sector_8_X= X_size/2;
   int sector_8_Y= (Y_size/6)*5;

   int sector_9_X= (X_size/6)*5;
   int sector_9_Y= (Y_size/6)*5;

   //now find losest planets to this point
   int xdist, ydist;
   int nowDistance;
   int distance[10];
   int distance_1=1000000;
   int distance_2=1000000;
   int distance_3=1000000;
   int distance_4=1000000;
   int distance_6=1000000;
   int distance_7=1000000;
   int distance_8=1000000;
   int distance_9=1000000;

   distance[0]=1000000;      // set distances to very far indeed
   distance[1]=1000000;
   distance[2]=1000000;
   distance[3]=1000000;
   distance[4]=1000000;
   distance[5]=1000000;
   distance[6]=1000000;
   distance[7]=1000000;
   distance[8]=1000000;
   distance[9]=1000000;

   int Neighbour[10];      // reference to ten closest Neighbours
   int sector_1;
   int sector_2;
   int sector_3;
   int sector_4;
   //  sector 5 is center, see Neighbour[10]
   int sector_6;
   int sector_7;
   int sector_8;
   int sector_9;
   short int ja;

   for ( ja = 0; ja<NumberStars ; ++ja)
				{

				  xdist=  (center_X) - (star[ja].x) ;
				  ydist=  (center_Y) - (star[ja].y) ;
				  xdist= abs ( xdist );
				  ydist= abs ( ydist );
				  nowDistance=  sqrt ( (xdist*xdist)+(ydist*ydist)+ 0.0000001 );
				  if  ( (nowDistance<distance[9]) )
				  {
					 distance[9]= nowDistance;
					 Neighbour[9]=ja;
					 if (nowDistance<distance[8])
					 {
						distance[9]= distance[8];
						distance[8]= nowDistance;
						Neighbour[9]= Neighbour[8];
						Neighbour[8]=ja;
						if (nowDistance<distance[7])
						{
							distance[8]= distance[7];
							distance[7]= nowDistance;
							Neighbour[8]= Neighbour[7];
							Neighbour[7]=ja;
						   if (nowDistance<distance[6])
							{
								distance[7]= distance[6];
								distance[6]= nowDistance;
								Neighbour[7]= Neighbour[6];
								Neighbour[6]=ja;
							  if (nowDistance<distance[5])
                     			{
									distance[6]= distance[5];
									distance[5]= nowDistance;
									Neighbour[6]= Neighbour[5];
									Neighbour[5]=ja;
								 if (nowDistance<distance[4])
									{
										distance[5]= distance[4];
                        				distance[4]= nowDistance;
										Neighbour[5]= Neighbour[4];
										Neighbour[4]=ja;
									if (nowDistance<distance[3])
                     					{
											distance[4]= distance[3];
                        					distance[3]= nowDistance;
											Neighbour[4]= Neighbour[3];
											Neighbour[3]=ja;
									   if (nowDistance<distance[2])
                     						{
												distance[3]= distance[2];
                        						distance[2]= nowDistance;
												Neighbour[3]= Neighbour[2];
												Neighbour[2]=ja;
										  if (nowDistance<distance[1])
												{
													distance[2]= distance[1];
													distance[1]= nowDistance;
													Neighbour[2]= Neighbour[1];
													Neighbour[1]=ja;
											 if (nowDistance<distance[0])
													{
														distance[1]= distance[0];
														distance[0]= nowDistance;
														Neighbour[1]= Neighbour[0];
														Neighbour[0]=ja;
													}
												}
											}
										}
									}
								}
							}
						}
					 }
				  }
				}
   int 	xdist_1, ydist_1, xdist_2, ydist_2, xdist_3, ydist_3;
   int	xdist_4, ydist_4, xdist_6, ydist_6, xdist_7, ydist_7;
   int	xdist_8, ydist_8, xdist_9, ydist_9;

   for (ja = 0; ja<NumberStars ; ++ja)
   {
		 xdist_1=  (sector_1_X) - (star[ja].x) ;
		 ydist_1=  (sector_1_Y) - (star[ja].y) ;
		 xdist_1= abs ( xdist_1 );
		 ydist_1= abs ( ydist_1 );

		 xdist_2=  (sector_2_X) - (star[ja].x) ;
		 ydist_2=  (sector_2_Y) - (star[ja].y) ;
		 xdist_2= abs ( xdist_2 );
		 ydist_2= abs ( ydist_2 );

		 xdist_3=  (sector_3_X) - (star[ja].x) ;
		 ydist_3=  (sector_3_Y) - (star[ja].y) ;
		 xdist_3= abs ( xdist_3 );
		 ydist_3= abs ( ydist_3 );

		 xdist_4=  (sector_4_X) - (star[ja].x) ;
		 ydist_4=  (sector_4_Y) - (star[ja].y) ;
		 xdist_4= abs ( xdist_4 );
		 ydist_4= abs ( ydist_4 );

		 xdist_6=  (sector_6_X) - (star[ja].x) ;
		 ydist_6=  (sector_6_Y) - (star[ja].y) ;
		 xdist_6= abs ( xdist_6 );
		 ydist_6= abs ( ydist_6 );

		 xdist_7=  (sector_7_X) - (star[ja].x) ;
		 ydist_7=  (sector_7_Y) - (star[ja].y) ;
		 xdist_7= abs ( xdist_7 );
		 ydist_7= abs ( ydist_7 );

		 xdist_8=  (sector_8_X) - (star[ja].x) ;
		 ydist_8=  (sector_8_Y) - (star[ja].y) ;
		 xdist_8= abs ( xdist_8 );
		 ydist_8= abs ( ydist_8 );

		 xdist_9=  (sector_9_X) - (star[ja].x) ;
		 ydist_9=  (sector_9_Y) - (star[ja].y) ;
		 xdist_9= abs ( xdist_9 );
		 ydist_9= abs ( ydist_9 );

		nowDistance=  sqrt ( (xdist_1*xdist_1)+(ydist_1*ydist_1)+ 0.0000001 );
		if  ( (nowDistance < distance_1) )
		{
			distance_1 = nowDistance;
			sector_1 = ja;
		}

		nowDistance=  sqrt ( (xdist_2*xdist_2)+(ydist_2*ydist_2)+ 0.0000001 );
		if  ( (nowDistance < distance_2) )
		{
			distance_2 = nowDistance;
			sector_2 = ja;
		}

		nowDistance=  sqrt ( (xdist_3*xdist_3)+(ydist_3*ydist_3)+ 0.0000001 );
		if  ( (nowDistance < distance_3) )
		{
			distance_3 = nowDistance;
			sector_3 = ja;
		}
		nowDistance=  sqrt ( (xdist_4*xdist_4)+(ydist_4*ydist_4)+ 0.0000001 );
		if  ( (nowDistance < distance_4) )
		{
			distance_4 = nowDistance;
			sector_4 = ja;
		}
		nowDistance=  sqrt ( (xdist_6*xdist_6)+(ydist_6*ydist_6)+ 0.0000001 );
		if  ( (nowDistance < distance_6) )
		{
			distance_6 = nowDistance;
			sector_6 = ja;
		}
		nowDistance=  sqrt ( (xdist_7*xdist_7)+(ydist_7*ydist_7)+ 0.0000001 );
		if  ( (nowDistance < distance_7) )
		{
			distance_7 = nowDistance;
			sector_7 = ja;
		}
		nowDistance=  sqrt ( (xdist_8*xdist_8)+(ydist_8*ydist_8)+ 0.0000001 );
		if  ( (nowDistance < distance_8) )
		{
			distance_8 = nowDistance;
			sector_8 = ja;
		}
		nowDistance=  sqrt ( (xdist_9*xdist_9)+(ydist_9*ydist_9)+ 0.0000001 );
		if  ( (nowDistance < distance_9) )
		{
			distance_9 = nowDistance;
			sector_9 = ja;
		}
   }

   /* open a file for update */
   stream = fopen("word_names/home_worlds.txt", "r");
   if (stream==NULL)
   {
	return;
   }

   /* seek to the start of the file */
   fseek(stream, 0, SEEK_SET);

   /* read a string from the file */
   fgets(mesg, 20, stream);
   //fscanf(stream,"%s", &mesg);

   //////capital////////
   fgets(star [Neighbour[0]].name, 20, stream);
   //fscanf(stream,"%s", &star [Neighbour[0]].name);
   star [Neighbour[0]].owner=HIGH_STEWARD;

   //fgets(star [Neighbour[1]].name, 20, stream);
   //fscanf(stream,"%s", &mesg);
   star [Neighbour[1]].owner=GUILD;

   //fgets(star [Neighbour[2]].name, 20, stream);
   //fscanf(stream,"%s", &mesg);
   star [Neighbour[2]].owner=GUILD;

   //fgets(star [Neighbour[3]].name, 20, stream);
   //fscanf(stream,"%s", &mesg);
   star [Neighbour[3]].owner=GUILD;

   fgets(star [sector_1].name, 20, stream);
   //fscanf(stream,"%s", &star [sector_1].name);
   star [sector_1].owner = RED;

   //fgets(star [sector_2].name, 20, stream);
   //fscanf(stream,"%s", &star [sector_2].name);
   star [sector_2].owner = ALIEN;

   fgets(star [sector_3].name, 20, stream);
   //fscanf(stream,"%s", &star [sector_3].name);
   star [sector_3].owner = BLEU;

   fgets(star [sector_7].name, 20, stream);
   //fscanf(stream,"%s", &star [sector_7].name);
   star [sector_7].owner = ORANGE;

   fgets(star [sector_8].name, 20, stream);
   //fscanf(stream,"%s", &star [sector_8].name);
   star [sector_8].owner = YELLOW;

   fgets(star [sector_9].name, 20, stream);
   //fscanf(stream,"%s", &star [sector_9].name);
   star [sector_9].owner = GREEN;

   fclose(stream);
}


void world_type_names (void)
{    /* open a file for update */
   FILE *stream;
   char msg[20];
   stream = fopen("word_names/temp_worlds.txt", "r");
   if (stream==NULL)
   {
	return;
   }

   /* seek to the start of the file */
   fseek(stream, 0, SEEK_SET);

   /* read a string from the file */
   fgets(msg, 20, stream);


 
   for (int i = 0; i<NumberStars ; ++i)
   {
		  fgets(star [i].name, 20, stream);

   }

   fclose(stream);
}

