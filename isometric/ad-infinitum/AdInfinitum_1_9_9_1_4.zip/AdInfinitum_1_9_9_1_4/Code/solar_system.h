float OrbitAngleX (int orbit,float mapsize,
							float position,int firstOrbit)
{
   float X;
	X=	(	(firstOrbit*orbit)*mapsize*2	)
   		*cos (
         		( (2.0*M_PI)/(360.0) )
               	*((position))
               );
   return X;
}

float OrbitAngleY (int orbit,float mapsize,
							float position,int firstOrbit)
{
   float Y;
	Y=	(	(firstOrbit*orbit)*mapsize/2	)
   		*sin (
         		( (2.0*M_PI)/(360.0) )
            		*((position))
               );
   return Y;
}


void PutSun(int centerX,int centerY,float angleX,float angleY,
							float mapsize,int size,int colour)
{
	RECT rcRectPutSun; RECT rcRectGetSun;
   rcRectPutSun.top   = 	(	((centerY)-(size*mapsize))+angleY  );
   rcRectPutSun.bottom=		(((centerY)+(size*mapsize))+angleY     );
   rcRectPutSun.left=		(((centerX)-(size*mapsize))+angleX     );
   rcRectPutSun.right=		(((centerX)+(size*mapsize))+angleX     );
   rcRectGetSun.top=    	((colour-1)*60    );
   rcRectGetSun.bottom=	(   (colour)*60   );
   rcRectGetSun.left=0;
   rcRectGetSun.right=60;
   lpDDSBack->Blt( &rcRectPutSun, lpDDSOffSuns,
   										&rcRectGetSun,
                                 DDBLT_WAIT |
                                 DDBLT_KEYSRC, NULL  );
}

void PutOrbit(int centerX,int centerY,float angleX,float angleY,
						float mapsize,int size,int type)
{
	RECT rcRectPutWorld; RECT rcRectGetWorld;
   int placeSize=size;
   if (type==8) {	placeSize+=2; }// gas giant
   if (type==9) {	placeSize-=4; type=3; }// moon
   if (type==10) { return; }// asteroides
   int TotalSize= ( (placeSize*mapsize) );
   int topPart=  ( ((centerY)-(TotalSize))+angleY );
   int leftPart = ( ((centerX)-(TotalSize))+angleX );
   rcRectPutWorld.top=   	topPart;
   rcRectPutWorld.bottom=	topPart+TotalSize;
   rcRectPutWorld.left=  	leftPart;
   rcRectPutWorld.right= 	leftPart+TotalSize;
   rcRectGetWorld.top=(type-1)*30;
   rcRectGetWorld.bottom=(type)*30;
   rcRectGetWorld.left=0;
   rcRectGetWorld.right=30; if (type==8) { rcRectGetWorld.right=77; rcRectPutWorld.right=(rcRectPutWorld.right+47);}// gas giant
   lpDDSBack->Blt( &rcRectPutWorld, lpDDSOffWorlds,
   										&rcRectGetWorld,
                                	DDBLT_WAIT |
                                 DDBLT_KEYSRC, NULL  );
}

void SystemBackground(float stretch,int x,int y)
{
	for (int n=0; n<60; n++)
         	{
            	for (int m=0; m<60; m++)
               	{
                  	if (screenMap[n][m]!=0)
                     	{
                        	lpDDSOffScreen->BltFast( x+(stretch*n*4.61),
                           							y+(stretch*m*4.61),
                                       			lpDDSOffSmaleStars,
                                                &rcRectBstar,
                                           		DDBLTFAST_WAIT |
                                           		DDBLTFAST_SRCCOLORKEY );
                        }
                  }
            }
}

float GetPosition (float rotation,int place)
{
   int DecTime= ( dwTime/100 );
	int OneTick=( 360/rotation );
   float secTick=360.0/rotation/60.0;
   float decTick=secTick/10.0;
   int NewTime=(  (((OneMinute)%OneTick)*rotation)/10  );
   float OrbitPossition=(NewTime*OneTick)+(OneSecond*secTick)+(DecTime*decTick)+place;
	if ( OrbitPossition>360 ) { OrbitPossition-=360.0;	}
   return  OrbitPossition;
}

void InSolar(float typeMap,int MapXCenter,int MapYCenter,int px,int py)
   {

         if (screenMap[px][py]!=CheckSystem.StarNumber) // get system details
         	{
            GetStarSystem(star[screenMap[px][py]].seed, screenMap[px][py]);
            }

         // place center sun
         float AngleX[2];
         float AngleY[2];
         float speedo=0.5;
         float OrbitPossition;
         if (CheckSystem.AlphaSunOrbit!=0)  //	if binary of same size
         	{
            	if  ( speedo!=0 )
               	{
               		OrbitPossition=GetPosition (speedo,0);
                  }
               else { OrbitPossition=0;}
            }
         AngleX[0]=OrbitAngleX (CheckSystem.AlphaSunOrbit,typeMap,OrbitPossition,1);
         AngleY[0]=OrbitAngleY (CheckSystem.AlphaSunOrbit,typeMap,OrbitPossition,1);
			if (CheckSystem.BetaSunType!=0)
         	{       // check if companion sun and (if yes) place it
            	if  ( speedo!=0 )
               	{
               		OrbitPossition=GetPosition (speedo,180);
                  }
               else { OrbitPossition=0;}

               AngleX[1]=OrbitAngleX (CheckSystem.BetaSunOrbit, typeMap,
                           									OrbitPossition,1);
               AngleY[1]=OrbitAngleY (CheckSystem.BetaSunOrbit, typeMap,
                           									OrbitPossition,1);
               if (AngleY[0] > AngleY[1])   // sun to place first
               	{
                  	PutSun(	MapXCenter,MapYCenter,AngleX[1],AngleY[1],typeMap,
                                             	CheckSystem.BetaSunSize,
                  										CheckSystem.BetaSunType	);
                     PutSun(	MapXCenter,MapYCenter,AngleX[0],AngleY[0],typeMap,
                  									CheckSystem.AlphaSunSize,
                                          	CheckSystem.AlphaSunType	);
                  }
               else
               	{
                  	PutSun(	MapXCenter,MapYCenter,AngleX[0],AngleY[0],typeMap,
                  										CheckSystem.AlphaSunSize,
                                                CheckSystem.AlphaSunType	);
                     PutSun(	MapXCenter,MapYCenter,AngleX[1],AngleY[1],typeMap,
                  										CheckSystem.BetaSunSize,
                                                CheckSystem.BetaSunType		);
                  }
            }
         else
         	{         // if no companion just place main sun
            	PutSun(	MapXCenter,MapYCenter,AngleX[0],AngleY[0],typeMap,
                           					CheckSystem.AlphaSunSize,
                           					CheckSystem.AlphaSunType	);
            }

                  // check orbits and place them

         for (int n=1; n<5; n++)
         	{
               //	CheckSystem.orbit[1]=orbit[1];
      			//	CheckSystem.orbitstart[1]=orbitplace[1];
               int OrbitSize; int nanualOrbit;
               if ( n==1 ){speedo=1;OrbitSize=8; nanualOrbit=40;}
               if ( n==2 ){speedo=1;OrbitSize=8; nanualOrbit=80;}
               if ( n==3 ){speedo=0;OrbitSize=8; nanualOrbit=120;}
               if ( n==4 ){speedo=0;OrbitSize=7; nanualOrbit=160;}
               if  ( speedo!=0 )
               	{
               		OrbitPossition=GetPosition (speedo,CheckSystem.orbitstart[n]);
                  }
               else { OrbitPossition=CheckSystem.orbitstart[n];}
               if ( CheckSystem.orbit[n]!=0 )  // not empty orbit
               	{
            			AngleX[0]=OrbitAngleX ( nanualOrbit ,typeMap,
                     							OrbitPossition,1);
         				AngleY[0]=OrbitAngleY ( nanualOrbit ,typeMap,
                     							OrbitPossition,1);
               		PutOrbit(MapXCenter,MapYCenter,AngleX[0],AngleY[0],
                     								typeMap,OrbitSize,CheckSystem.orbit[n]);
                     CheckSystem.posNOWy[n]=( AngleY[0]+MapYCenter);
                     CheckSystem.posNOWx[n]= (AngleX[0]+MapXCenter);
                  }
            }
   }


void SolarSystem(int Center)
{
   int px; int py;
   py=((yPos-110)+22)/MapSet; px=((xPos)+12)/MapSet;

   if (screenMap[px][py]!=0 )   // if over world/////////////////////////////////////
   	{
         //int MapXCenter; int MapYCenter;
		 //float typeMap; int xx; int yy;

         if (Center==false )
         	{                // black out smalle map
      			ZeroMemory( &ddbltfx, sizeof( ddbltfx ) );
               ddbltfx.dwSize = sizeof( ddbltfx );
         		ddbltfx.dwFillColor = dwBackground;
         		lpDDSOffScreen->Blt( &rcRectSection2, NULL,
   										NULL,
   										DDBLT_COLORFILL |
                                 DDBLT_WAIT, &ddbltfx );
               //MapXCenter=(276/2+513); MapYCenter=(276/2+313);
               //typeMap=1.0;
               //xx=513;	yy=313;
               // background
         		//SystemBackground(typeMap,xx,yy);



            }

         else
         	{                // black out large map
      			ZeroMemory( &ddbltfx, sizeof( ddbltfx ) );
               ddbltfx.dwSize = sizeof( ddbltfx );
         		ddbltfx.dwFillColor = dwBackground;
         		lpDDSOffScreen->Blt( &rcRectSection1, NULL,
   										NULL,
   										DDBLT_COLORFILL |
                                 DDBLT_WAIT, &ddbltfx );
               //MapXCenter=(480/2+6); MapYCenter=(480/2+110);
			   //typeMap=480.0/277.0;
               //xx=6;   yy=110;
               // background
         		//SystemBackground(typeMap,xx,yy);
            }

		}

}




