void border_line( LPplanet planet_creat, int scan_from, int scan_to, int change_type )
{

   int check_hex_x, check_hex_y;
   int Number_diferent;
   //int change_for_coast;
   int coast_temp [100][100];
   int nx,ny;
   int odd_even;
   int planet_number = planet_creat->number;
   int dice;

	for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ ) { coast_temp [nx][ny] =  0; }  //set to null
   }

   for (ny=0; ny< planet_size_y; ny++)
   {

	   odd_even = (ny+1) % 2;

	   for (nx=0; nx< planet_size_x; nx++ )
       {
			planet_creat->planet_matrice[nx][ny]->coast = 0;
            if (planet_creat->planet_matrice[nx][ny]->type == scan_from) //check hex only if hydro
			{
                Number_diferent=0;

                if ( planet_creat->planet_matrice[nx][ny] == NULL ) debugfile ("error....no hex \n", planet_number );

				/// check east hex
				check_hex_x = nx+1;
				if ( check_hex_x >= planet_size_x )
					 { check_hex_x = 0; }  //go round world if over
				if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][ny]->type) )
					 {
						Number_diferent++;
						//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_EAST;
					 }
				else
				/// check west hex
				check_hex_x = nx-1;
				if ( check_hex_x < 0 )
					 { check_hex_x = planet_size_x-1; }  //go round world if over
				if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][ny]->type) )
					 {
						Number_diferent++;
						//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_WEST;
					 }


				/// check north west hex
				check_hex_y = ny-1;
				if ( check_hex_y >= 0 ) //only check if not over top
				{
					 if ( odd_even == 1 )
					 {
						   if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[nx][check_hex_y]->type) )
							{
								Number_diferent++;
								//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_NORTH_WEST;
							}
					 }
					 else
					 {
						   check_hex_x = nx-1;
						   if ( check_hex_x < 0 )
							 { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) )
							 {
								Number_diferent++;
								//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_NORTH_WEST;
							 }
					 }
				}

				/// check north east hex
				check_hex_y = ny-1;
				if ( check_hex_y >= 0 ) //only check if not over top
				{
					 if ( odd_even == 0 )
					 {
						   if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[nx][check_hex_y]->type) )
							{
								Number_diferent++;
								//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_NORTH_EAST;
							}
					 }
					 else
					 {
						   check_hex_x = nx+1;
						   if ( check_hex_x >= planet_size_x )
								{ check_hex_x = 0; }  //go round world if over
						   if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) )
							{
								Number_diferent++;
								//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_NORTH_EAST;
							}
					 }
				}


				/// check South west hex
				check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
				{
					 if ( odd_even == 1 )
					 {
						   if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[nx][check_hex_y]->type) )
							{
								Number_diferent++;
								//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_SOUTH_WEST;
							}
					 }
					 else
					 {
						   check_hex_x = nx-1;
						   if ( check_hex_x < 0 )
							 { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) )
							 {
								Number_diferent++;
								//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_SOUTH_WEST;
							 }
					 }
				}

				/// check South east hex
				check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
				{
					 if ( odd_even == 0 )
					 {
						   if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[nx][check_hex_y]->type) )
							{
								Number_diferent++;
								//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_SOUTH_EAST;
							}
					 }
					 else
					 {
						   check_hex_x = nx+1;
						   if ( check_hex_x >= planet_size_x )
								{ check_hex_x = 0; }  //go round world if over
						   if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) )
							{
								Number_diferent++;
								//planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_SOUTH_EAST;
							}
					 }
				}

				if ( Number_diferent > 0 )
				{  coast_temp [nx][ny] = 1;  }
				else
				{  coast_temp [nx][ny] = 2;  }

				if ( check_hex_x < 0 ) debugfile ("error....check hex less than zero, x\n", check_hex_x );
				if ( check_hex_x >= planet_size_x ) debugfile ("error....check hex too big, x\n", check_hex_x );
			}

	   }
   }

   if ( planet_number == 0 ) debugfile ("done first planet check coast\n", planet_number );

   for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   {
		   if ( change_type  == YES_IF_BORDER )
		   {
				if ( coast_temp [nx][ny] == 1 )
				{
					coast_temp [nx][ny] = 0;
					if ( planet_creat->planet_matrice[nx][ny]->type == scan_from )
						 { planet_creat->planet_matrice[nx][ny]->type = scan_to; }
					else
						 {
							 debugfile ("posible error....coast checkink land, x\n", check_hex_x );
							 planet_creat->planet_matrice[nx][ny]->type = scan_from;
						 }
				}
		   }
		   if ( change_type  == YES_IF_NO_BORDER )
		   {
				if ( coast_temp [nx][ny] == 2 )
				{

					if ( planet_creat->planet_matrice[nx][ny]->type == scan_from )
						 { planet_creat->planet_matrice[nx][ny]->type = scan_to; }
					else
						 {
							 debugfile ("posible error....coast checkink land, x\n", check_hex_x );
							 planet_creat->planet_matrice[nx][ny]->type = scan_from;
						 }
				}
				coast_temp [nx][ny] = 0;
		   }

	   }
   }

}


////////////////////////////////////////////////////////////
void coastline( LPplanet planet_creat )
{

   int check_hex_x, check_hex_y;
   int Number_diferent;
   int change_for_coast;
   int coast_temp [100][100];
   int nx,ny;
   int odd_even;
   int planet_number = planet_creat->number;
   int dice;

    for (ny=0; ny< planet_size_y; ny++)
   {
       for (nx=0; nx< planet_size_x; nx++ ) { coast_temp [nx][ny] =  0; }  //set to null
   }

   if ( planet_number == 0 ) debugfile ("empty coast temp done\n", planet_number );

   for (ny=0; ny< planet_size_y; ny++)
   {
       //if ( planet_number ==0 ) debugfile ("Y................................\n", ny );

       odd_even = (ny+1) % 2;
       if ( planet_number == 0 && ny==0 ) debugfile ("Odd even of first line\n", odd_even );

       for (nx=0; nx< planet_size_x; nx++ )
       {
            //if ( planet_number ==0 ) debugfile ("X  \n", nx );
            // check to see which terain changing
            if (planet_creat->hydro_size < 50)
            {
                 change_for_coast=HYDRO;
            }
            else
            {
                 change_for_coast=PLAIN;
            }

            if (planet_creat->planet_matrice[nx][ny]->type != change_for_coast)
            {
                Number_diferent=0;

                if ( planet_creat->planet_matrice[nx][ny] == NULL ) debugfile ("error....no hex \n", planet_number );

                /// check east hex
                check_hex_x = nx+1;
                if ( check_hex_x >= planet_size_x )
                     { check_hex_x = 0; }  //go round world if over
                if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][ny]->type) )
                     { Number_diferent++; }

                /// check west hex
                check_hex_x = nx-1;
                if ( check_hex_x < 0 )
                     { check_hex_x = planet_size_x-1; }  //go round world if over
                if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][ny]->type) )
                     { Number_diferent++; }

                /// check north west hex
                check_hex_y = ny-1;
                if ( check_hex_y >= 0 ) //only check if not over top
                {
                     if ( odd_even == 1 )
                     {
                           if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[nx][check_hex_y]->type) )
                            { Number_diferent++; }
                     }
                     else
                     {
                           check_hex_x = nx-1;
                           if ( check_hex_x < 0 )
                             { check_hex_x = planet_size_x-1; }  //go round world if over
                           if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) )
                             { Number_diferent++; }
                     }
                }

                /// check north east hex
                check_hex_y = ny-1;
                if ( check_hex_y >= 0 ) //only check if not over top
                {
                     if ( odd_even == 0 )
                     {
                           if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[nx][check_hex_y]->type) )
                            { Number_diferent++; }
                     }
                     else
                     {
                           check_hex_x = nx+1;
                           if ( check_hex_x >= planet_size_x )
                                { check_hex_x = 0; }  //go round world if over
                           if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) )
                                { Number_diferent++; }
                     }
                }


                /// check South west hex
                check_hex_y = ny+1;
                if ( check_hex_y < planet_size_y ) //only check if not over bottom
                {
                     if ( odd_even == 1 )
                     {
                           if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[nx][check_hex_y]->type) )
                            { Number_diferent++; }
                     }
                     else
                     {
                           check_hex_x = nx-1;
                           if ( check_hex_x < 0 )
                             { check_hex_x = planet_size_x-1; }  //go round world if over
                           if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) )
                             { Number_diferent++; }
                     }
                }

                /// check South east hex
                check_hex_y = ny+1;
                if ( check_hex_y < planet_size_y ) //only check if not over bottom
                {
                     if ( odd_even == 0 )
                     {
                           if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[nx][check_hex_y]->type) )
                            { Number_diferent++; }
                     }
                     else
                     {
                           check_hex_x = nx+1;
                           if ( check_hex_x >= planet_size_x )
                                { check_hex_x = 0; }  //go round world if over
                           if ( (planet_creat->planet_matrice[nx][ny]->type) != (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) )
                                { Number_diferent++; }
                     }
                }

                dice=random(100)+1;
                if ( dice < (Number_diferent*10) )
                {  coast_temp [nx][ny] = 1;  }

                if ( check_hex_x < 0 ) debugfile ("error....check hex less than zero, x\n", check_hex_x );
                if ( check_hex_x >= planet_size_x ) debugfile ("error....check hex too big, x\n", check_hex_x );
            }

       }
   }

   if ( planet_number == 0 ) debugfile ("done first planet check coast\n", planet_number );

   for (ny=0; ny< planet_size_y; ny++)
   {
       for (nx=0; nx< planet_size_x; nx++ )
       {
           if ( coast_temp [nx][ny] == 1 )
                {
                    coast_temp [nx][ny] = 0;
                    if ( planet_creat->planet_matrice[nx][ny]->type == HYDRO )
                         { planet_creat->planet_matrice[nx][ny]->type = PLAIN; }
                    else
                         { planet_creat->planet_matrice[nx][ny]->type = HYDRO; }
                }
       }
   }

}


//////////////////////////////////////////////////
//////////////////////////////////////////////////

void coast_draw_set ( LPplanet planet_creat, int check_hex_type, int not_if_type )
{

   int check_hex_x, check_hex_y;
   //int Number_diferent;
   //int change_for_coast;
   int coast_temp [100][100];
   int nx,ny;
   int odd_even;
   int planet_number = planet_creat->number;
   int dice;

	for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ ) { coast_temp [nx][ny] =  0; }  //set to null
   }

   for (ny=0; ny< planet_size_y; ny++)
   {

	   odd_even = (ny+1) % 2;

	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			//planet_creat->planet_matrice[nx][ny]->coast = 0;
			if (planet_creat->planet_matrice[nx][ny]->type == check_hex_type) //check hex only if if_type
			{
				if ( planet_creat->planet_matrice[nx][ny] == NULL ) debugfile ("error....no hex \n", planet_number );

				/// check east hex
				check_hex_x = nx+1;
				if ( check_hex_x >= planet_size_x )
					 { check_hex_x = 0; }  //go round world if over
				if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][ny]->type))
						&&((planet_creat->planet_matrice[check_hex_x][ny]->type)
						!= not_if_type))
					 {
						planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_EAST;
					 }

				/// check west hex
				check_hex_x = nx-1;
				if ( check_hex_x < 0 )
					 { check_hex_x = planet_size_x-1; }  //go round world if over
				if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][ny]->type))
						&&((planet_creat->planet_matrice[check_hex_x][ny]->type)
						!= not_if_type))
					 {
						planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_WEST;
					 }


				/// check north west hex
				check_hex_x = nx;
				check_hex_y = ny-1;
				if ( check_hex_y >= 0 ) //only check if not over top
				{
					 if ( odd_even == 1 )
					 {
						   if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
						&&((planet_creat->planet_matrice[check_hex_x][check_hex_y]->type)
						!= not_if_type))
						{
							planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_NORTH_WEST;
						}
					 }
					 else
					 {
						   check_hex_x = nx-1;
						   if ( check_hex_x < 0 )
							 { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
						&&((planet_creat->planet_matrice[check_hex_x][check_hex_y]->type)
						!= not_if_type))
						{
							planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_NORTH_WEST;
						}
					 }
				}

				/// check north east hex
				check_hex_x = nx;
				check_hex_y = ny-1;
				if ( check_hex_y >= 0 ) //only check if not over top
				{
					 if ( odd_even == 0 )
					 {
						   if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
						&&((planet_creat->planet_matrice[check_hex_x][check_hex_y]->type)
						!= not_if_type))
						{
							planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_NORTH_EAST;
						}
					 }
					 else
					 {
						   check_hex_x = nx+1;
						   if ( check_hex_x >= planet_size_x )
								{ check_hex_x = 0; }  //go round world if over
						   if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
						&&((planet_creat->planet_matrice[check_hex_x][check_hex_y]->type)
						!= not_if_type))
						{
							planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_NORTH_EAST;
						}
					 }
				}


				/// check South west hex
				check_hex_x = nx;
				check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
				{
					 if ( odd_even == 1 )
					 {
						   if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
						&&((planet_creat->planet_matrice[check_hex_x][check_hex_y]->type)
						!= not_if_type))
						{
							planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_SOUTH_WEST;
						}
					 }
					 else
					 {
						   check_hex_x = nx-1;
						   if ( check_hex_x < 0 )
							 { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
						&&((planet_creat->planet_matrice[check_hex_x][check_hex_y]->type)
						!= not_if_type))
						{
							planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_SOUTH_WEST;
						}
					 }
				}

				/// check South east hex
				check_hex_x = nx;
				check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
				{
					 if ( odd_even == 0 )
					 {
						   if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
						&&((planet_creat->planet_matrice[check_hex_x][check_hex_y]->type)
						!= not_if_type))
						{
							planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_SOUTH_EAST;
						}
					 }
					 else
					 {
						   check_hex_x = nx+1;
						   if ( check_hex_x >= planet_size_x )
								{ check_hex_x = 0; }  //go round world if over
						   if ( ((planet_creat->planet_matrice[nx][ny]->type)
						!= (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
						&&((planet_creat->planet_matrice[check_hex_x][check_hex_y]->type)
						!= not_if_type))
						{
							planet_creat->planet_matrice[nx][ny]->coast = planet_creat->planet_matrice[nx][ny]->coast | FLAG_SOUTH_EAST;
						}
					 }
				}


				if ( check_hex_x < 0 ) debugfile ("error....check hex less than zero, x\n", check_hex_x );
				if ( check_hex_x >= planet_size_x ) debugfile ("error....check hex too big, x\n", check_hex_x );
			}

	   }
   }

   if ( planet_number == 0 ) debugfile ("done first planet check coast draw\n", planet_number );



}

