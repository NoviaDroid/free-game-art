author: Nicu Buculei
license: Public Domain
origin: http://clipart.nicubunu.ro/?gallery=rpg_map
        http://opengameart.org/users/nicubunu
