author: Daniel Cook
license CC-BY (http://www.lostgarden.com/2007/03/lost-garden-license.html)
origin: http://lunar.lostgarden.com/labels/free%20game%20graphics.html


If you use art from one of my free game art collections, please include the following attribution in a visible location along with any other credits.

  "Art Collection Title" art by Daniel Cook (Lostgarden.com) 

When possible link to blog post that discusses the original art collection. For example, the Space Cute collection would be "Space Cute" art by Daniel Cook (Lostgarden.com)

http://www.lostgarden.com/2007/05/cutegod-prototyping-challenge.html
http://www.lostgarden.com/2007/05/dancs-miraculously-flexible-game.html
http://www.lostgarden.com/2007/04/free-game-graphics-tyrian-ships-and.html
http://www.lostgarden.com/2006/07/more-free-game-graphics.html
http://www.lostgarden.com/2005/03/game-post-mortem-hard-vacuum.html
http://www.lostgarden.com/2005/03/download-complete-set-of-sweet-8-bit.html
http://www.lostgarden.com/2006/02/250-free-handdrawn-textures.html
