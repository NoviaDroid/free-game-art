This is a track I wrote with the hope that it would be used in
FreeDoom. It can be used in any level, but I'd prefer one of the
campaign maps.

Please credit the track to "Jeremy 'Mogul' Emerson". Thank you!
