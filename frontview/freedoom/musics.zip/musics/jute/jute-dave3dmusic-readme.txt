This is a collection of 42 music tracks in MIDI format created by me (jute) and submitted to FreeDoom.  I haven't renamed the files to replace music in the vanilla levels, nor have they been converted to MUS files; I hope this is okay.  I also hope that these works are useful for the project and that I have submitted them correctly.

jutemail@gmail.com