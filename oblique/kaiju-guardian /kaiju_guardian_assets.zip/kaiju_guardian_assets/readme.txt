author: virgatetomb
license: CC-BY
source: http://opengameart.org/content/kaiju-guardian-assets