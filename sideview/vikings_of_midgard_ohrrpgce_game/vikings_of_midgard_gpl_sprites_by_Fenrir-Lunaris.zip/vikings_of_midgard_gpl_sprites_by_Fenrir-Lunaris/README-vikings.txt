Vikings of Midgard
(C) Copyright 2012 Fenrir-Lunaris. this game is distributed under the
terms of the GNU General Public License.

Graphics by Fenrir-Lunaris.

� They may be used or altered for your own purposes without any need to
credit their original source (though it would be awfully nice if you
did!)

Music by Artimus Bena, Moogle1, Setu Firestorm, Cartlemmy, Jeremy
Jacobs,
Fenrir-Lunaris, & the Public Domain.

� As far as I'm aware, all the music
files in the game can be used for your own purposes as well, though the
original authors should be credited for their work.

� A few sound effects have been edited and used from the "Arfenhouse"
movies with permission from Misteroo. They are NOT in the public domain.

_____________________________________

The likenesses and depictions of many people's characters and
intellectual property have been used with permission, and are either
intended as a tribute or parody of their original works. This *IS* a
game about the O.H.R.RPG.C.E community after all!

Without exception, if a character in this game has a NAME, then it
belongs to someone, and the authors of this game stake no claim on them.
Said authors are as follows...
_____________________________________

Fenrir-Lunaris
 � Most of the main cast
Artimus Bena
 � Eldardeen, (Himself)
Moogle1
 � Rancher Sam, (Himself), Dummefaust
Gizmog
 � (Himself)
JSH357
 � OHR house, DUCK
Surlaw
 � Surlaw (Whalepunch), Bob Surlaw,      Walrusman, Dr. Mu, Musclemen,
Yuk
James Paige
 � Bob the Hamster, Vlad the Hamster
   Plips
Hiryo
 � Kouryuu, Kirin, Leo, Youji, Hiryo
Thellos
 � Vellan, Azerith, Ivory, Zidane
   Elloris, Inara, Kiri, Skadi
Smokescale Aquatos
 � Shayna, Sirius
Deam Nitrel
 � Deam (Himself)
XxSkyxX
 � Sky (Himself)
Shadowiii
 � Julia, Shadowiii (Himself)
Red Maverick Zero
 � Josh, Mr Triangle, Slither, That
   horrible flying thing you fight in
   Alfheim that you DON'T want to
   know what it actuall is, 
   (Himself), Rachael
Firewulff
 � Dogero, Mi'La, Pyrus, Johan, Gahn,    Anon, Gitleh, Fedora, Shoda,
Nyx,
   Grinlow, Sword of Jade
Charbile
 � (Himself)
Misteroo
 � Housemaster, E/G Kitty, Joe,
   Woogy, My Friend Amy, Billy,
   Arfenhouse, The Jint of mah butt,
   Squiggle, PIAKCHU!!1, (Himself),
   LEYMUNAYD, GIMMEYURMUNY
Seppel
 � Seesawgunswallow
Sew
 � Sew
Ronintendo
 � Paul Roanoke, Lita  
H.P. Lovecraft
 � Cthulhu, Shub-Niggurath, Tulzcha,
   Dagon, Yog-Sothoth, Nylarlethotep,
   Azathoth, Flying Polyps, Fhtagn,
   Hounds of Tindalos
Stephen King
 � Langoliers
Spoonweaver
 � Tim-tim the mighty gnome, Boosh,
   Spaceship Funkatron, Musclemen
Siyu/Natedawg
 � Siyu (Himself)
Machu
 � (Himself)
AdrianX
 � (Himself)
Inferior Minion
 � (Himself)
Hachi Roku
 � HAIL!!
   HA HA!!
   CHOO CHOO!!
Harlock & Shizuma
 � Spellshard

~lelelelele!

