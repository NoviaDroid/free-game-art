------------------------------------------------------------
 O.H.R.RPG.C.E Game Player  (2013-04-10 beelzebufo version)
------------------------------------------------------------
Official Hamster Republic RPG Construction Engine

---
This package contains the files you need to play OHRRPGCE games in .RPG
format.

To learn how to use the OHRRPGCE, please visit
http://HamsterRepublic.com/ohrrpgce/

If you have questions, read the FAQ at
http://hamsterrepublic.com/ohrrpgce/F.A.Q.html

---
DISTRIBUTION INFO

GAME.EXE is a part of the OHRRPGCE, which is free software under the GPL
License. See LICENSE.txt for details. If you want to get the source code,
just visit: http://HamsterRepublic.com/ohrrpgce/Source.html

---
WHERE TO FIND GAMES?

You can start at http://HamsterRepublic.com/ohrrpgce/ where there are lots
of links to OHRRPGCE related sites with downloadable games, or you can
search the internet for the word OHRRPGCE with your favorite search engine

---
BUG TESTING INFO

We appreciate bug-reports. If you find a bug, you can report it at:
http://HamsterRepublic.com/bugzilla/ or e-mail it to:
ohrrpgce-bugs@HamsterRepublic.com

---
Have fun playing!

                                            James Paige
                                            Hamster Republic Productions
                                            http://HamsterRepublic.com/
